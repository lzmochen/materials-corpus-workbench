"""Storage and request context for the local corpus workbench."""

import hashlib
import json
import secrets
import sqlite3
from datetime import datetime, timezone


TABLES = frozenset({'evaluation_profiles', 'resources', 'batches', 'samples', 'annotations', 'benchmarks', 'feedback', 'jobs',
                    'releases', 'runs', 'extractions', 'extraction_configs', 'distillations', 'evaluation_runs',
                    'guide_standards', 'guide_outputs', 'multimodal_pairs', 'contrast_experiments',
                    'quality_checks', 'benchmark_blueprints', 'intake_batches', 'corpus_collections', 'workflow_recipes', 'supply_views', 'supply_nodes', 'supply_requests'})
ROLES = frozenset({'admin', 'operator', 'annotator', 'expert', 'lead'})


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def fail(status, message):
    raise ApiError(status, message)


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def connect(database):
    conn = sqlite3.connect(str(database), timeout=20, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def ensure_document_tables(conn):
    for table in sorted(TABLES):
        conn.execute(f'CREATE TABLE IF NOT EXISTS {table} (id TEXT PRIMARY KEY, payload TEXT NOT NULL)')


def initialize(conn):
    conn.execute('PRAGMA journal_mode = WAL')
    ensure_document_tables(conn)
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS blobs (sha256 TEXT PRIMARY KEY, content BLOB NOT NULL);
        CREATE TABLE IF NOT EXISTS users (
          username TEXT PRIMARY KEY, display TEXT NOT NULL, role TEXT NOT NULL,
          salt TEXT NOT NULL, password_hash TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, username TEXT NOT NULL REFERENCES users(username),
          expires INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_log (
          seq INTEGER PRIMARY KEY, at TEXT NOT NULL, actor TEXT NOT NULL, role TEXT NOT NULL,
          action TEXT NOT NULL, target TEXT NOT NULL, detail TEXT NOT NULL
        );
    ''')


def password_hash(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), 600_000).hex()


def put_user(conn, username, display, role, password):
    salt = secrets.token_hex(16)
    conn.execute('INSERT INTO users VALUES (?,?,?,?,?)', (username, display, role, salt, password_hash(password, salt)))


class Context:
    def __init__(self, conn, user):
        self.db = conn
        self.user = user

    @staticmethod
    def table(name):
        if name not in TABLES:
            raise ValueError('Unknown storage table')
        return name

    def all(self, table):
        rows = self.db.execute(f'SELECT payload FROM {self.table(table)} ORDER BY rowid DESC')
        return [json.loads(row['payload']) for row in rows]

    def get(self, table, record_id):
        row = self.db.execute(f'SELECT payload FROM {self.table(table)} WHERE id = ?', (record_id,)).fetchone()
        return json.loads(row['payload']) if row else None

    def require(self, table, record_id):
        record = self.get(table, record_id)
        if record is None:
            fail(404, '业务记录不存在。')
        return record

    def put(self, table, record):
        self.db.execute(f'''INSERT INTO {self.table(table)} (id,payload) VALUES (?,?)
            ON CONFLICT(id) DO UPDATE SET payload = excluded.payload''',
            (record['id'], json.dumps(record, ensure_ascii=False, separators=(',', ':'), allow_nan=False)))
        return record

    @staticmethod
    def new_id(prefix):
        return f'{prefix}-{secrets.token_hex(6).upper()}'

    def allow(self, *roles):
        if self.user['role'] not in roles:
            fail(403, '当前账号没有执行此操作的权限。')

    def audit(self, action, target, detail=''):
        if not isinstance(detail, str):
            detail = json.dumps(detail, ensure_ascii=False)
        self.db.execute('INSERT INTO audit_log (at,actor,role,action,target,detail) VALUES (?,?,?,?,?,?)',
                        (now(), self.user['username'], self.user['role'], str(action), str(target), detail[:2000]))

    def store_blob(self, raw):
        digest = hashlib.sha256(raw).hexdigest()
        self.db.execute('INSERT OR IGNORE INTO blobs VALUES (?,?)', (digest, raw))
        return digest

    def read_blob(self, sha256):
        row = self.db.execute('SELECT content FROM blobs WHERE sha256 = ?', (sha256,)).fetchone()
        if row is None:
            fail(404, '源文件未找到。')
        return row['content']

    def enqueue(self, kind, payload):
        job_id = self.new_id('JOB')
        self.put('jobs', {'id':job_id, 'kind':kind, 'payload':payload, 'status':'queued', 'attempts':0,
                          'createdAt':now(), 'createdBy':self.user['username']})
        return job_id
