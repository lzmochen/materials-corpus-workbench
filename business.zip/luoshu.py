"""Structured knowledge extraction, source verification and training-set production."""
import re
import unicodedata

import production
from core import fail, now


TEMPLATES = {
    'source': ('按原文字段抽取', []),
    'materials': ('材料综合属性', ['材料牌号', '材料名称', '材质', '化学成分', '组织', '热处理', '淬火', '回火', '硬度', '强度', '伸长率', '冲击功']),
    'process': ('材料制备与热处理工艺', ['工艺', '热处理', '淬火', '回火', '退火', '保温', '冷却', '轧制', '时效', '温度', '压力', '气氛']),
    'properties': ('材料性能与测试', ['硬度', '强度', '冲击功', '韧性', '伸长率', '延伸率', '模量', '密度', '导电率', '电阻率', '测试方法', '测试条件']),
    'custom': ('自定义属性抽取', []),
}
ENGINE = '本地字段匹配与原文定位'
REVIEWERS = ('operator', 'expert', 'lead', 'admin')
MAX_KNOWLEDGE = production.MAX_CANDIDATES
KEY_VALUES = re.compile(r'(?:^|[\n|；;，,])\s*([^：:=\n|；;,，]{1,60}?)\s*[：:=]\s*([^\n|；;,，]{1,1000})')
SOURCE_KEYS = {'原文定位','证据项','试样','样品','试件','编号','样品编号','试样编号','id','sample','sampleid','序号','doi','url'}


def normalized(text):
    return unicodedata.normalize('NFKC', text).casefold().replace(' ', '')


def discover_fields(blocks):
    """Use column labels or written field/value pairs from this source version."""
    found = {}
    for block in blocks:
        labels = block.get('fields', {}).keys() or (m[1].strip() for m in KEY_VALUES.finditer(block['text']))
        for name in labels:
            key = normalized(name)
            if not key or key in SOURCE_KEYS or key in ('http','https') or len(name) > 60:
                continue
            found.setdefault(key, name)
    if found:
        return list(found.values())
    # Paragraphs may express numerical results as a sentence rather than a column.
    prose_fields = list(dict.fromkeys(field for _, fields in TEMPLATES.values() for field in fields))
    for block in blocks:
        for field, _, _ in source_attributes(block, prose_fields):
            if normalized(field) not in SOURCE_KEYS:
                found.setdefault(normalized(field), field)
    return list(found.values())


def template_fields(data, template, blocks=()):
    if template == 'source':
        return discover_fields(blocks)
    if 'fields' not in data:
        if template == 'custom':
            fail(400, '请配置需要抽取的字段')
        return TEMPLATES[template][1].copy()
    fields = data['fields']
    if not isinstance(fields, list) or not 1 <= len(fields) <= 40:
        fail(400, '请选择 1–40 个抽取字段')
    result = []
    for field in fields:
        name = production.value({'字段名称': field}, '字段名称', 60)
        if any(normalized(existing) == normalized(name) for existing in result):
            fail(400, '配置中含有重复字段')
        result.append(name)
    return result


def matches(label, fields):
    name = normalized(label)
    return any(normalized(field) in name for field in fields)


def source_attributes(block, fields):
    """Prefer parsed table cells. Keep exact value offsets for rule quality checks."""
    text = block['text']
    captured = set()
    for label, value in block.get('fields', {}).items():
        if not matches(label, fields):
            continue
        # A number can occur in several columns of the same row.
        cell = re.search(r'(?:^|\s*\|\s*)' + re.escape(label) + r'\s*[：:=]\s*' + re.escape(value), text)
        if cell:
            offset = cell.end() - len(value)
        else:
            label_pos = text.find(label)
            offset = text.find(value, label_pos + len(label)) if label_pos >= 0 else -1
        if offset >= 0:
            captured.add(normalized(label))
            yield label, value, offset

    # A custom field can be present in raw text even if the parser did not
    # identify it as a predefined material attribute.
    for match in KEY_VALUES.finditer(text):
        label = match[1].strip()
        value = match[2].strip()
        if value and normalized(label) not in captured and matches(label, fields):
            yield label, value, match.start(2) + len(match[2]) - len(match[2].lstrip())

    # Capture explicit numeric readings in prose or OCR text. Bare mentions
    # of an attribute do not produce a fact.
    for field in fields:
        pattern = re.escape(field) + r'\s*(?:实测为|测得为|测得|为|达|约为|为约)\s*([+−-]?\d+(?:\.\d+)?(?:\s*[～~–至-]\s*\d+(?:\.\d+)?)?(?:[ \t]*(?:MPa|GPa|kPa|HRC|HBW?|HV|J/cm²|S/m|g/cm³|℃|°C|K|h|min|%|J))?)'
        for match in re.finditer(pattern, text, re.I):
            yield field, match[1], match.start(1)


def extract_records(blocks, fields):
    records = []
    seen = set()
    for block in blocks:
        subject = next((v for k,v in block.get('fields', {}).items()
                        if re.search(r'试样|样品|试件|编号|^sample$|^id$', k, re.I)
                        and v in block['text'] and len(v) <= 150), block['location'])
        if subject == block['location']:
            evidence_type = block.get('fields', {}).get('证据项', '')
            if evidence_type and len(evidence_type) <= 150 and evidence_type in block['text']:
                subject = evidence_type
        for field, value, start in source_attributes(block, fields):
            identity = (block['id'], normalized(field), start, value)
            if identity in seen:
                continue
            seen.add(identity)
            if len(records) >= MAX_KNOWLEDGE:
                fail(422, f'匹配结果超过 {MAX_KNOWLEDGE} 条，请缩小抽取字段或拆分源文件')
            records.append({
                'id': f'K{len(records)+1:04}', 'subject': subject, 'field': field, 'value': value,
                'sourceField': field, 'sourceValue': value, 'sourceStart': start,
                'start': start, 'end': start + len(value), 'blockId': block['id'],
                'evidence': block['text'], 'location': block['location'], 'status': 'pending',
            })
    return records


def save(ctx, task):
    records = task['records']
    counts = {state: sum(r['status'] == state for r in records) for state in ('pending', 'approved', 'rejected')}
    task['counts'] = dict(counts, total=len(records))
    task['status'] = 'generated' if task.get('batchId') else 'pending' if counts['pending'] else 'reviewed'
    task['revision'] = task.get('revision', 0) + 1
    task['updatedAt'] = now()
    return ctx.put('extractions', task)


def extraction_input(ctx, data):
    ctx.allow(*production.OPERATORS)
    resource = ctx.require('resources', production.value(data, 'resourceId', 80))
    production.resource_access(ctx, resource)
    version = production.resolve_version(resource, production.value(data, 'versionId', 80))
    if version['status'] != 'approved':
        fail(409, '请先核准源文件版本')
    template = production.choice(data, 'template', TEMPLATES, 'source')
    return resource, version, template, template_fields(data, template, version['blocks'])


def match_preview(version, fields, template):
    rows = extract_records(version['blocks'], fields) if fields else []
    alternatives = [] if rows or template == 'source' else discover_fields(version['blocks'])
    block = next(iter(version['blocks']), {})
    return {
        'count': len(rows), 'fields': fields, 'sourceBlocks': len(version['blocks']),
        'examples': [{'label': row['field'], 'answer': row['value'], 'location': row['location']} for row in rows[:3]],
        'alternatives': alternatives[:12],
        'sourceExcerpt': {'location': block.get('location', ''), 'text': block.get('text', '')[:350]} if not rows else None,
    }


def create(ctx, data, workflow_id=None):
    resource, version, template, fields = extraction_input(ctx, data)
    template_name = production.value(data, 'templateLabel', 100, False) or TEMPLATES[template][0]
    title = production.value(data, 'title', 180, False) or f'{resource["title"]} · {template_name}'
    for task in ctx.all('extractions'):
        if task.get('workflowId') == workflow_id and (task['versionId'], task['template'], task['fields'], task['templateName'], task['title']) == (version['id'], template, fields, template_name, title):
            return task
    records = extract_records(version['blocks'], fields)
    if not records:
        available = discover_fields(version['blocks']) if template != 'source' else []
        if available:
            fail(422, '所选字段未命中。此版本可按原文字段抽取：' + '、'.join(available[:8]))
        fail(422, '此版本没有可定位的字段取值。请查看原文，选择含有属性及实测值的已核准版本。')
    task = {
        'id': ctx.new_id('EXT'), 'title': title, 'resourceId': resource['id'], 'resourceTitle': resource['title'],
        'versionId': version['id'], 'filename': version['filename'], 'sha256': version['sha256'],
        'split': resource['split'], 'template': template, 'templateName': template_name, 'fields': fields,
        'engine': ENGINE, 'records': records, 'createdBy': ctx.user['username'], 'createdAt': now(),
    }
    if workflow_id:
        task['workflowId'] = workflow_id
    save(ctx, task)
    ctx.audit('执行结构化属性抽取', task['id'], f'{version["id"]} · {template_name} · {len(records)} 条')
    return task


def check_revision(task, data):
    revision = data.get('revision')
    if type(revision) is not int or revision != task['revision']:
        fail(409, '抽取记录已更新，请刷新后重新提交')


def review(ctx, task, data):
    ctx.allow(*REVIEWERS)
    if task.get('batchId'):
        fail(409, '已生成语料的核查快照不能修改')
    check_revision(task, data)
    record_id = production.value(data, 'recordId', 80)
    record = next((r for r in task['records'] if r['id'] == record_id), None)
    if record is None:
        fail(404, '知识条目不存在')
    decision = production.choice(data, 'decision', ('save', 'approve', 'reject'))
    note = production.value(data, 'note', 1200, False)
    if decision != 'reject':
        edited = {key: production.value({key: data.get(key, record[key])}, key, limit)
                  for key, limit in [('field', 100), ('value', 2000), ('subject', 150)]}
        subject = edited['subject']
        if subject != record['location'] and subject not in record['evidence']:
            fail(422, '知识对象须能在原文中定位')
        position = record['sourceValue'].find(edited['value'])
        if position >= 0:
            start = record['sourceStart'] + position
        else:
            start = record['evidence'].find(edited['value'])
            if start < 0:
                fail(422, '请从关联原文中选取实际属性值')
            if record['evidence'].find(edited['value'], start + 1) >= 0:
                fail(422, '修订值在此证据块出现多次，请补充单位或上下文以确定位置')
        record.update(edited, start=start, end=start + len(edited['value']))
    record.update(status={'save':'pending', 'approve':'approved', 'reject':'rejected'}[decision],
                  note=note, reviewer=ctx.user['username'], reviewedAt=now())
    save(ctx, task)
    ctx.audit({'save':'修订知识条目', 'approve':'核查通过知识条目', 'reject':'退回知识条目'}[decision],
              task['id'], f'{record_id} · {task["versionId"]}/{record["blockId"]} · {record["field"]} · {note}')
    return task


def expected_span(rule, blocks):
    """Rebuild the approved answer from the versioned evidence used by batch QA."""
    start, end = rule.get('start'), rule.get('end')
    if len(blocks) != 1 or blocks[0]['id'] != rule.get('blockId'):
        return None
    text = blocks[0]['text']
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text):
        return None
    return text[start:end]


def generate(ctx, task, data):
    ctx.allow(*production.OPERATORS)
    resource, version = production.training_source(ctx, task)
    if task.get('batchId'):
        return {'extraction': task, 'batch': ctx.require('batches', task['batchId'])}
    check_revision(task, data)
    if any(r['status'] == 'pending' for r in task['records']):
        fail(409, '请先完成本次抽取的全部知识核查')
    approved = [r for r in task['records'] if r['status'] == 'approved']
    if not approved:
        fail(409, '请先核查并通过至少一条知识')
    title = production.value(data, 'title', 180, False) or (task['title'][:170] + ' · 知识问答')
    batch = production.new_batch(ctx, {'title':title}, resource, version, 'local', 'luoshu-knowledge', len(approved))
    batch.update(extractionId=task['id'], extractionRevision=task['revision'], engine=ENGINE)
    blocks = {block['id']: block for block in version['blocks']}
    samples = []
    for record in approved:
        block = blocks.get(record['blockId'])
        rule = {'type':'extract-span', 'blockId':record['blockId'], 'start':record['start'], 'end':record['end']}
        if block is None or expected_span(rule, [block]) != record['value'] or block['text'] != record['evidence']:
            fail(409, '核查快照与源版本不一致，请重新核对原文')
        subject = record['subject']
        where = record['location'] if subject == record['location'] else f'{subject}（{record["location"]}）'
        question = f'{where}记录的{record["field"]}是什么？'
        sample = production.save_candidate(ctx, batch, question, record['value'], [block], rule=rule)
        sample.update(extractionId=task['id'], knowledgeId=record['id'])
        ctx.put('samples', sample)
        samples.append(sample)
    production.write_batch(ctx, batch, samples, 'generated')
    checked = production.batch_quality(ctx, batch)
    task['batchId'] = batch['id']
    save(ctx, task)
    ctx.audit('核查知识生成问答', task['id'], f'{batch["id"]} · {len(samples)} 条 · {version["id"]}')
    return {'extraction':task, 'batch':checked['batch']}


def visible_tasks(ctx):
    return [task for task in ctx.all('extractions')
            if task['split'] != 'holdout' or ctx.user['role'] in REVIEWERS]


def dispatch(ctx, method, parts, data):
    if parts == ['extractions','preview'] and method == 'POST':
        _, version, template, fields = extraction_input(ctx, data)
        return match_preview(version, fields, template)
    if parts == ['templates'] and method == 'GET':
        return [{'id':key, 'name':name, 'fields':fields} for key,(name,fields) in TEMPLATES.items()]
    if parts == ['knowledge'] and method == 'GET':
        return [dict(record, extractionId=task['id'], extractionTitle=task['title'],
                     resourceId=task['resourceId'], versionId=task['versionId'], filename=task['filename'],
                     split=task['split'], templateName=task['templateName'])
                for task in visible_tasks(ctx) for record in task['records'] if record['status'] == 'approved']
    if parts == ['extractions']:
        if method == 'GET':
            return [{k:v for k,v in task.items() if k != 'records'} for task in visible_tasks(ctx)]
        if method == 'POST':
            return create(ctx, data)
    if parts[:1] == ['extractions'] and len(parts) in (2, 3):
        task = ctx.require('extractions', parts[1])
        production.resource_access(ctx, ctx.require('resources', task['resourceId']))
        if method == 'GET' and len(parts) == 2:
            return task
        if method == 'POST' and len(parts) == 3:
            if parts[2] == 'review':
                return review(ctx, task, data)
            if parts[2] == 'generate':
                return generate(ctx, task, data)
    if parts[:1] in (['templates'], ['knowledge'], ['extractions']):
        fail(405, '请求方法或操作不支持')
    return None


def handle(ctx, method, path, data):
    if path.startswith('/api/luoshu/'):
        return dispatch(ctx, method, path.removeprefix('/api/luoshu/').strip('/').split('/'), data)
    return None
