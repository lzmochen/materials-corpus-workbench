"""Reusable field configurations and authorized drawing previews."""

import base64
import json
import shutil
import subprocess
import re
from pathlib import Path

from core import fail, now
from production import OPERATORS, resolve_version, resource_access


def _text(value, limit, label, required=True):
    if not isinstance(value, str) or len(value.strip()) > limit or (required and not value.strip()):
        fail(400, f'{label}无效。')
    return value.strip()


def normalized(data):
    name = _text(data.get('name'), 80, '模板名称')
    result = {'name': name, 'description': _text(data.get('description', ''), 500, '说明', False)}
    for key, maximum, limit in [('fields', 32, 60), ('disabledFields', 32, 60), ('tags', 8, 32)]:
        entries = data.get(key, [])
        if not isinstance(entries, list) or len(entries) > maximum:
            fail(400, '配置项数量超限或格式错误。')
        result[key] = [_text(entry, limit, '配置项') for entry in entries]
    all_fields = result['fields'] + result['disabledFields']
    if not result['fields'] or len(all_fields) > 32:
        fail(400, '请启用至少一个字段，字段总数限 32 个。')
    if len({x.casefold() for x in all_fields}) != len(all_fields):
        fail(400, '模板字段名称重复。')
    return result


def handle(ctx, method, path, data):
    preview = re.fullmatch(r'/api/luoshu/preview/([A-Za-z0-9-]+)/([A-Za-z0-9-]+)', path)
    if preview and method == 'GET':
        resource = ctx.require('resources', preview[1])
        resource_access(ctx, resource)
        version = resolve_version(resource, preview[2])
        mime = {'.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg',
                '.webp':'image/webp', '.bmp':'image/bmp'}.get(Path(version['filename']).suffix.lower())
        if not mime:
            fail(400, '此文件没有图纸预览。')
        return {'mime':mime, 'filename':version['filename'], 'contentBase64':base64.b64encode(ctx.read_blob(version['sha256'])).decode('ascii'),
                'blocks':version.get('blocks', [])}
    if path == '/api/luoshu/configs/import-preview' and method == 'POST':
        ctx.allow(*OPERATORS)
        raw = data.get('yaml')
        if not isinstance(raw, str) or not 0 < len(raw.encode('utf-8')) <= 65536:
            fail(400, 'YAML 文件须在 64 KiB 以内。')
        ruby = shutil.which('ruby')
        if not ruby:
            fail(503, '本机缺少 YAML 读取组件 Ruby/Psych。')
        # The document is read from stdin. Psych disallows object classes and aliases.
        try:
            parsed = subprocess.run([ruby, '--disable-gems', '-rpsych', '-rjson', '-e',
                'v=Psych.safe_load(STDIN.read); print JSON.generate(v)'], input=raw,
                text=True, capture_output=True, timeout=4, check=True)
            value = json.loads(parsed.stdout)
        except (ValueError, OSError, subprocess.SubprocessError):
            fail(400, 'YAML 格式无效，请检查模板文件。')
        if not isinstance(value, dict) or 'name' not in value or 'fields' not in value:
            fail(400, '模板文件缺少 name 或 fields。')
        return normalized(value)
    route = re.fullmatch(r'/api/luoshu/configs(?:/([A-Za-z0-9-]+))?', path)
    if not route:
        return None
    config_id = route[1]
    previous = ctx.require('extraction_configs', config_id) if config_id else None
    if method == 'GET':
        return previous if previous else ctx.all('extraction_configs')
    ctx.allow(*OPERATORS)
    if method != 'POST':
        fail(405, '请求方法不支持。')
    values = normalized(data)
    if previous and data.get('revision') != previous['revision']:
        fail(409, '模板已由其他人修改，请重新打开。')
    if any(item['id'] != config_id and item['name'].casefold() == values['name'].casefold()
           for item in ctx.all('extraction_configs')):
        fail(409, '模板名称已存在。')
    record = {**values, 'id': config_id or ctx.new_id('TPL'),
              'revision': previous['revision'] + 1 if previous else 1,
              'updatedAt': now(), 'updatedBy': ctx.user['username']}
    ctx.put('extraction_configs', record)
    ctx.audit('更新抽取模板' if previous else '新建抽取模板', record['id'], record['name'])
    return record
