"""Immutable, approved scoring profiles for benchmark evaluation reports."""
import re
from core import fail, now

DOMAINS = ('基础概念理解', '标准技术规则识别', '科学计算', '推理能力', '多模态理解')
DEFAULT_ID = 'PROFILE-MATERIALS-V1'
BASE = {
    'id': DEFAULT_ID, 'title': '材料领域五项能力', 'version': 1, 'parentId': None, 'status': 'published',
    'familyId': DEFAULT_ID, 'reason': '五项能力等权汇总，各题规则单独配置。',
    'createdBy': '平台预置', 'publishedBy': '平台预置', 'threshold': 60,
    'weights': dict.fromkeys(DOMAINS, 20)
}
ROOT = '/api/evaluation-profiles'


def get_profile(ctx, key):
    if key == DEFAULT_ID:
        return BASE
    if not isinstance(key, str) or len(key) > 64:
        fail(400, '指标版本无效')
    return ctx.require('evaluation_profiles', key)


def published(ctx, key):
    p = get_profile(ctx, key)
    if p['status'] != 'published':
        fail(409, '请选择已发布的指标版本')
    return p


def text_field(data, field, length, label):
    value = data.get(field)
    if not isinstance(value, str) or not 1 <= len(value.strip()) <= length:
        fail(400, f'{label}须为1至{length}字')
    return value.strip()


def create(ctx, data, draft=None):
    ctx.allow('operator', 'lead', 'admin')
    if draft:
        if draft['status'] != 'draft':
            fail(409, '已发布版本已冻结，请基于该版本编制新版本')
        if draft['createdBy'] != ctx.user['username']:
            fail(403, '仅编制人可修改待审批草案')
        if data.get('revision') != draft.get('revision'):
            fail(409, '草案已更新，请重新打开')
    previous = published(ctx, draft['parentId'] if draft else data.get('parentId', DEFAULT_ID))
    weights = data.get('weights')
    if (not isinstance(weights, dict) or set(weights) != set(DOMAINS) or
            any(type(w) is not int or not 0 <= w <= 100 for w in weights.values()) or sum(weights.values()) != 100):
        fail(400, '五个能力域的权重须为0至100的整数，总和须为100')
    threshold = data.get('threshold')
    if type(threshold) is not int or not 0 <= threshold <= 100:
        fail(400, '通过线须为0至100的整数')
    title = text_field(data, 'title', 80, '名称')
    reason = text_field(data, 'reason', 400, '适用范围及修订说明')
    if draft:
        draft.update(title=title, reason=reason, weights=weights, threshold=threshold, revision=ctx.new_id('REV'))
        ctx.put('evaluation_profiles', draft)
        ctx.audit('metrics.revise', draft['id'], title)
        return draft
    key = ctx.new_id('MET')
    family = previous['familyId'] if previous['id'] != DEFAULT_ID else key
    history = [p for p in ctx.all('evaluation_profiles') if p['familyId'] == family]
    if history and (any(p['status'] == 'draft' for p in history) or
                    previous['version'] != max(p['version'] for p in history)):
        fail(409, '该方案已有更新版本，请打开最新版本')
    p = {'id': key, 'familyId': family, 'version': 1 + max((p['version'] for p in history), default=0),
         'parentId': previous['id'], 'title': title, 'revision': ctx.new_id('REV'),
         'reason': reason, 'status': 'draft',
         'weights': {name: weights[name] for name in DOMAINS}, 'threshold': threshold,
         'createdBy': ctx.user['username'], 'createdAt': now()}
    ctx.put('evaluation_profiles', p)
    ctx.audit('metrics.draft', key, previous['id'])
    return p


def aggregate(profile, dimensions):
    active = [d for d in dimensions if d['count'] and profile['weights'][d['topic']]]
    coverage = sum(profile['weights'][d['topic']] for d in active)
    means = [round(sum(d['means'][i]*profile['weights'][d['topic']] for d in active)/100, 2)
             for i in range(2)] if coverage == 100 else None
    return {'coveredWeight': coverage, 'means': means,
            'pass': [v >= profile['threshold'] for v in means] if means is not None else None}


def handle(ctx, method, path, data):
    if path == ROOT and method == 'GET':
        rows = ctx.all('evaluation_profiles')
        if ctx.user['role'] not in ('operator', 'lead', 'admin'):
            rows = [p for p in rows if p['status'] == 'published']
        return {'profiles': rows+[BASE], 'domains': DOMAINS}
    if path == ROOT and method == 'POST':
        return create(ctx, data)
    revision = re.fullmatch(ROOT + r'/([^/]+)/revise', path)
    if revision and method == 'POST':
        return create(ctx, data, get_profile(ctx, revision[1]))
    match = re.fullmatch(ROOT + r'/([^/]+)/publish', path)
    if match and method == 'POST':
        ctx.allow('lead', 'admin')
        p = get_profile(ctx, match[1])
        if p['status'] == 'published':
            return p
        if p['createdBy'] == ctx.user['username']:
            fail(403, '请由另一位评测负责人或平台管理员复核后发布')
        if data.get('revision') != p.get('revision'):
            fail(409, '草案内容已更新，请重新打开并核对后审批')
        p.update(status='published', publishedBy=ctx.user['username'], publishedAt=now())
        ctx.put('evaluation_profiles', p)
        ctx.audit('metrics.publish', p['id'], p['title'])
        return p
    return None
