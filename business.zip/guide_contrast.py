"""Small-sample, local image-to-text contrastive training with frozen feature extractors."""

import base64
import hashlib
import json
import math
import random
import re
import struct
import subprocess
import tempfile
import unicodedata
from pathlib import Path

from core import fail, now
from production import resolve_version

ENGINE = 'pixel-text-infonce/1'
DIM = 48
SIDE = 8
TEMP = 0.35
SIPS = '/usr/bin/sips'
EDITORS = ('operator',)


def unit(vector):
    length = math.sqrt(sum(v*v for v in vector))
    return [v/length for v in vector] if length else list(vector)


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def text_features(sentence):
    chars = [c for c in unicodedata.normalize('NFKC', sentence).casefold() if c.isalnum()]
    if not chars:
        fail(422, '配对证据缺少可编码文字')
    vector = [0] * DIM
    for token in chars + [a+b for a, b in zip(chars, chars[1:])]:
        slot = int.from_bytes(hashlib.blake2s(token.encode(), digest_size=4).digest(),'big') % DIM
        vector[slot] += 1
    return unit(vector)


def image_features(raw, extension):
    if not Path(SIPS).is_file():
        fail(422, '本机缺少 macOS 图像解码工具，无法提取像素特征')
    if extension not in ('.png', '.jpg', '.jpeg') or not raw.startswith(
            b'\x89PNG\r\n\x1a\n' if extension == '.png' else b'\xff\xd8\xff'):
        fail(422, '配对图像不是有效的 PNG 或 JPEG 原件')
    with tempfile.TemporaryDirectory(prefix='materials-pixels-') as folder:
        source, output = Path(folder)/('image'+extension), Path(folder)/'small.bmp'
        source.write_bytes(raw)
        try:
            meta = subprocess.run([SIPS, '-g','pixelWidth','-g','pixelHeight',str(source)],
                                  capture_output=True, timeout=4, check=True)
            dims = re.findall(rb'pixel(?:Width|Height):\s*(\d+)', meta.stdout)
            if len(dims) != 2 or any(int(x) < 1 for x in dims) or int(dims[0])*int(dims[1]) > 16000000:
                fail(422, '请选择有效且不超过 1600 万像素的图像')
            subprocess.run([SIPS,'-z',str(SIDE),str(SIDE),'-s','format','bmp',str(source),'--out',str(output)],
                           capture_output=True, timeout=5, check=True)
            bmp = output.read_bytes()
        except (OSError, subprocess.SubprocessError):
            fail(422, '本机图像缩放或解码失败，请重新导出图像')
    if len(bmp) < 54 or bmp[:2] != b'BM':
        fail(422, '本机图像解码结果无效')
    offset = struct.unpack_from('<I',bmp,10)[0]
    width, height, planes, bits, compression = struct.unpack_from('<iiHHI',bmp,18)
    if (width,abs(height),planes) != (SIDE,SIDE,1) or bits not in (24,32) or compression not in (0,3):
        fail(422, '本机图像解码返回了不支持的像素排列')
    if compression == 3 and struct.unpack_from('<III',bmp,54) != (0xff0000,0xff00,0xff):
        fail(422, '本机图像解码返回了不支持的颜色通道')
    channels = bits // 8
    stride = (width*channels+3)//4*4
    if offset + stride*SIDE > len(bmp):
        fail(422, '图像解码结果不完整')
    values = []
    for y in range(SIDE):
        base = offset + (y if height < 0 else SIDE-1-y)*stride
        for x in range(SIDE):
            blue, green, red = bmp[base+x*channels:base+x*channels+3]
            values.extend([red/255, green/255, blue/255])
    return values


def probs(row):
    peak = max(row)
    scaled = [math.exp(v-peak) for v in row]
    total = sum(scaled)
    return [v/total for v in scaled], peak+math.log(total)


def top_index(row):
    best = max(row)
    winners = [i for i, value in enumerate(row) if abs(value-best) < 1e-10]
    return winners[0] if len(winners)==1 else None


def measure(logits):
    n = len(logits)
    columns = list(zip(*logits))
    rows = [probs(row) for row in logits]
    cols = [probs(col) for col in columns]
    loss = sum(rows[i][1]+cols[i][1]-2*logits[i][i] for i in range(n))/(2*n)
    i2t, t2i = [top_index(row) for row in logits], [top_index(col) for col in columns]
    metrics = {'loss':round(loss,7), 'imageHits':sum(i==v for i,v in enumerate(i2t)),
               'textHits':sum(i==v for i,v in enumerate(t2i)), 'count':n}
    return metrics, i2t, t2i, rows, cols


def train(images, texts, epochs, rate, seed):
    n, width = len(images), len(images[0])
    mean = [sum(col)/n for col in zip(*images)]
    features = [unit([x-m for x,m in zip(image,mean)]) for image in images]
    generator = random.Random(seed)
    initial = [[generator.uniform(-0.04,0.04) for _ in range(width)] for _ in range(DIM)]
    base = [[dot(row, x) for row in initial] for x in features]
    gram = [[dot(x,y) for y in features] for x in features]
    # Each full-batch SGD update to W is a sum of outer products with the fixed input features.
    coeff = [[0.0]*DIM for _ in features]
    curve = []
    for step in range(epochs+1):
        projected = [[base[i][k] + sum(gram[i][j]*coeff[j][k] for j in range(n))
                      for k in range(DIM)] for i in range(n)]
        logits = [[dot(p,t)/TEMP for t in texts] for p in projected]
        metrics, i2t, t2i, rows, cols = measure(logits)
        if step == 0 or step == epochs or step % max(1,epochs//8) == 0:
            curve.append(dict(epoch=step, **metrics))
        if step == epochs:
            break
        for i in range(n):
            deriv = [(rows[i][0][j] + cols[j][0][i] - 2*(i==j))/(2*n*TEMP) for j in range(n)]
            for k in range(DIM):
                coeff[i][k] -= rate*sum(deriv[j]*texts[j][k] for j in range(n))
    weights = [initial[k][l] + sum(coeff[i][k]*features[i][l] for i in range(n))
               for k in range(DIM) for l in range(width)]
    model = {'imageSide':SIDE,'imageNormalization':'row-major RGB / 255; subtract imageMean then L2',
             'imageMean':mean,'textNormalization':'NFKC casefold; alnum unigrams and bigrams; blake2s-4 big endian mod 48; count L2',
             'textDimension':DIM, 'temperature':TEMP, 'weightShape':[DIM,width],
             'weightEncoding':'row-major little-endian float32 base64',
             'weights':base64.b64encode(struct.pack('<'+'f'*len(weights),*weights)).decode()}
    return curve, i2t, t2i, model


def parameters(data):
    ids, epochs, rate, seed = (data.get('pairIds'),data.get('epochs',30),
                               data.get('learningRate',0.1),data.get('seed',17))
    if not isinstance(ids,list) or not 2<=len(ids)<=8 or not all(isinstance(i,str) for i in ids) or len(set(ids)) != len(ids):
        fail(422, '请选择 2–8 组互不重复的训练配对')
    if type(epochs) is not int or not 1<=epochs<=80 or type(seed) is not int or not 0<=seed<=65535:
        fail(422, '训练轮数须为 1–80 的整数，随机种子须为 0–65535 的整数')
    if type(rate) not in (int,float) or not 0.001<=rate<=0.3:
        fail(422, '学习率须在 0.001–0.3 之间')
    return sorted(ids), epochs, float(rate), seed


def run(ctx, data):
    ctx.allow(*EDITORS)
    ids, epochs, rate, seed = parameters(data)
    pairs = [ctx.require('multimodal_pairs',i) for i in ids]
    bad_hashes = {v[key] for r in ctx.all('resources') if r.get('split')=='holdout'
                  for v in r['versions'] for key in ('sha256','contentDigest') if v.get(key)}
    image_hashes, text_keys, input_hashes, payloads = set(), set(), set(), []
    for pair in pairs:
        refs = {}
        for side in ('image','text'):
            src = pair[side]
            res = ctx.require('resources',src['resourceId'])
            version = resolve_version(res,src['versionId'])
            if res.get('split') != 'train' or version.get('sha256') != src['sha256'] or (
                    version['sha256'] in bad_hashes or version.get('contentDigest') in bad_hashes):
                fail(409,'配对来源已变更或与留出材料重合')
            refs[side] = version
        evidence = pair['evidence']
        block = next((b for b in refs['text'].get('blocks',[]) if b['id']==evidence['blockId']),None)
        if refs['text'].get('status') != 'approved' or not block or block['text'] != evidence['text']:
            fail(409,'配对的文本版本或证据块已变更')
        img_hash = refs['image']['sha256']
        text_key = ''.join(unicodedata.normalize('NFKC',block['text']).casefold().split())
        if img_hash in image_hashes or text_key in text_keys:
            fail(422,'每个训练配对须使用不同的原图和不同的文本证据')
        image_hashes.add(img_hash);text_keys.add(text_key)
        encoded = pair['caption']+'\n'+block['text']
        input_hash = hashlib.sha256(encoded.encode()).hexdigest()
        if input_hash in input_hashes:
            fail(422,'配对中的文本输入重复')
        input_hashes.add(input_hash)
        payloads.append((img_hash,Path(refs['image']['filename']).suffix.lower(),encoded))
    fingerprint = hashlib.sha256(json.dumps([ENGINE,ids,epochs,rate,seed],sort_keys=True).encode()).hexdigest()
    existing = ctx.db.execute("SELECT id FROM contrast_experiments WHERE json_extract(payload,'$.fingerprint')=?",(fingerprint,)).fetchone()
    if existing:
        return ctx.require('contrast_experiments',existing['id'])
    images,texts,total = [],[],0
    for digest,extension,encoded in payloads:
        raw = ctx.read_blob(digest)
        total += len(raw)
        if len(raw) > 4*1024**2 or total > 16*1024**2:
            fail(413,'单张图像限 4 MiB，本次图像合计限 16 MiB')
        images.append(image_features(raw,extension))
        texts.append(text_features(encoded))
    if len({tuple(x) for x in images}) != len(images) or len({tuple(t) for t in texts}) != len(texts):
        fail(422,'缩放图像或编码文本存在相同特征，请更换配对样本')
    curve, i2t, t2i, model = train(images,texts,epochs,rate,seed)
    feature_snapshot = {
        'imageEncoding': '8x8 row-major RGB, unsigned 8-bit, base64',
        'textInput': 'caption + newline + evidence.text',
        'samples': [{'pairId': pair['id'],
                     'rgb8': base64.b64encode(bytes(round(v*255) for v in image)).decode(),
                     'textVector': text} for pair, image, text in zip(pairs, images, texts)],
    }
    record = {'id':ctx.new_id('CEX'),'fingerprint':fingerprint,'engine':ENGINE,'createdAt':now(),
              'createdBy':ctx.user['username'],'epochs':epochs,'learningRate':rate,'seed':seed,
              'pairs':pairs,'features':feature_snapshot,'curve':curve,'imageToText':i2t,'textToImage':t2i,'model':model}
    ctx.put('contrast_experiments',record)
    ctx.audit('运行图文对比训练',record['id'],{'pairCount':len(ids),'epochs':epochs})
    return record


def handle(ctx,method,path,data):
    if path=='/api/contrast-experiments':
        if method=='POST':
            return run(ctx,data)
        if method=='GET':
            return [dict(row) for row in ctx.db.execute("""
                SELECT id,json_extract(payload,'$.createdAt') AS createdAt,
                    json_array_length(payload,'$.pairs') AS pairCount,json_extract(payload,'$.epochs') AS epochs
                FROM contrast_experiments ORDER BY rowid DESC""")]
    match = re.fullmatch(r'/api/contrast-experiments/(CEX-[A-F0-9]+)',path)
    if match and method=='GET':
        return ctx.require('contrast_experiments',match[1])
    return None
