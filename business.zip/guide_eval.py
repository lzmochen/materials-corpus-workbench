"""Reproducible rule-based evaluations on isolated materials benchmark items."""

import hashlib
import json
import math
import re
import unicodedata
from collections import defaultdict
from decimal import Decimal, InvalidOperation

from core import fail, now
from expert import anchors, assert_holdout

TOPICS = ('基础概念理解', '标准技术规则识别', '科学计算')
EDITORS = ('operator', 'lead', 'admin')
ENGINE = 'materials-rules/1'
NUMBER = r'[+-]?(?:(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.[0-9]+)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?'
ROUTE = re.compile(r'/api/benchmarks/([^/]+)/auto-evaluation(?:/([^/]+))?')


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def norm(text):
    return unicodedata.normalize('NFKC', text).replace('−', '-')


def phrase(text):
    return ''.join(norm(text).casefold().split())


def word_list(value, required=False):
    if not isinstance(value, list) or len(value) > 20 or (required and not value):
        fail(400, '请为每组要点填写 1–20 项，排除词可留空')
    clean = []
    for word in value:
        if not isinstance(word, str) or not word.strip() or len(word.strip()) > 100:
            fail(400, '每个要点或排除词须为 1–100 字')
        clean.append(word.strip())
    if len(clean) != len({phrase(word) for word in clean}):
        fail(400, '同一组中的要点或排除词重复')
    return clean


def checked_rule(raw):
    if not isinstance(raw, dict) or raw.get('topic') not in TOPICS:
        fail(400, '请选择基础概念、标准技术规则或科学计算专题')
    mode = raw.get('mode')
    rule = {'topic': raw['topic'], 'mode': mode}
    if mode == 'keywords':
        rule.update(keywords=word_list(raw.get('keywords'), True),
                    forbidden=word_list(raw.get('forbidden', [])))
        if {phrase(s) for s in rule['keywords']} & {phrase(s) for s in rule['forbidden']}:
            fail(400, '要点与排除词不能相同')
    elif mode == 'numeric':
        for key in ('expected', 'tolerance'):
            value = raw.get(key)
            if type(value) not in (float, int) or abs(value) > 1e100 or not math.isfinite(value):
                fail(400, '参考值及绝对容差须为有限数值')
            rule[key] = value
        if rule['tolerance'] < 0:
            fail(400, '绝对容差不能小于零')
        unit = raw.get('unit', '')
        if not isinstance(unit, str) or len(unit) > 32 or any(ord(c) < 32 for c in unit):
            fail(400, '单位最多 32 字，须与作答单位一致')
        rule['unit'] = unit.strip()
    elif mode != 'exact':
        fail(400, '不支持该计分方法')
    return rule


def default_rule(item):
    if item.get('autoRule'):
        return checked_rule(item['autoRule'])
    category = item['category']
    if any(word in category for word in ('计算', '数值', '换算')):
        topic = TOPICS[2]
    elif any(word in category for word in ('标准', '规则', '规范')):
        topic = TOPICS[1]
    else:
        topic = TOPICS[0]
    return {'mode': 'exact', 'topic': topic}


def evaluate_answer(answer, reference, rule):
    mode = rule['mode']
    if mode == 'exact':
        matched = phrase(answer) == phrase(reference)
        return {'score': 100 if matched else 0, 'reason': '与参考答案一致' if matched else '与参考答案文字不一致'}
    if mode == 'keywords':
        text = phrase(answer)
        matched = [word for word in rule['keywords'] if phrase(word) in text]
        missing = [word for word in rule['keywords'] if word not in matched]
        forbidden = [word for word in rule['forbidden'] if phrase(word) in text]
        score = 0 if forbidden else round(100 * len(matched) / len(rule['keywords']), 1)
        reason = '；'.join(part for part in ('命中 ' + '、'.join(matched) if matched else '无要点命中',
                         '缺少 ' + '、'.join(missing) if missing else '',
                         '命中排除词 ' + '、'.join(forbidden) if forbidden else '') if part)
        return {'score': score, 'reason': reason, 'matched': matched, 'missing': missing, 'forbidden': forbidden}
    unit = norm(rule['unit'])
    # Reject a suffix of a larger number and quantities expressed in a different unit.
    prefix = r'(?<![A-Za-z0-9_.+\-])(?<![0-9],)'
    suffix = (r'\s*' + re.escape(unit) + r'(?![A-Za-z0-9_/^%·°])'
              if unit else r'(?![A-Za-z0-9_.])')
    values = list(re.finditer(prefix + '(' + NUMBER + ')' + suffix, norm(answer)))
    if not values:
        return {'score': 0, 'reason': '没有符合单位要求的数值' if unit else '没有可识别的数值'}
    value = values[-1].group(1)
    try:
        number = Decimal(value.replace(',', ''))
        if abs(number.adjusted()) > 1000:
            raise InvalidOperation()
        deviation = abs(number - Decimal(str(rule['expected'])))
        matched = deviation <= Decimal(str(rule['tolerance']))
    except (InvalidOperation, OverflowError):
        return {'score': 0, 'reason': '数值超出可核算范围'}
    return {'score': 100 if matched else 0, 'value': value,
            'reason': f'取值 {value} {rule["unit"]}，绝对偏差 {deviation:g}，允许 {rule["tolerance"]}'}


def source_revision(benchmark):
    return digest([{'item': item['id'], 'question': item['question'], 'answer': item['answer'],
                    'candidates': item['candidates'], 'source': item['versionId'], 'evidence': item['evidence'],
                    'defaultRule': default_rule(item)} for item in benchmark['items']])


def require_access(ctx, benchmark, write=False):
    if ctx.user['role'] in EDITORS:
        return
    if not write and ctx.user['role'] == 'expert' and benchmark['status'] == 'published':
        return
    fail(403, '自动评测由数据管理员或负责人运行，专家在基准发布后可查阅结果')


def history(ctx, benchmark_id):
    # Read only summaries of this benchmark's runs; datasets and reports can grow independently.
    rows = ctx.db.execute("""
        SELECT id, json_extract(payload,'$.createdAt') AS createdAt,
            json_extract(payload,'$.createdBy') AS createdBy, json_extract(payload,'$.title') AS title,
            json_extract(payload,'$.benchmarkVersion') AS benchmarkVersion,
            json_array_length(payload,'$.items') AS itemCount
        FROM evaluation_runs WHERE json_extract(payload,'$.benchmarkId') = ? ORDER BY rowid DESC
    """, (benchmark_id,))
    return [dict(row) for row in rows]


def config(ctx, benchmark):
    require_access(ctx, benchmark)
    revision = source_revision(benchmark)
    runs = history(ctx, benchmark['id'])
    previous = ctx.require('evaluation_runs', runs[0]['id']) if runs else {}
    previous_rules = {item['itemId']: item['rule'] for item in previous.get('items', [])} if previous.get('revision') == revision else {}
    return {'benchmarkId': benchmark['id'], 'benchmarkTitle': benchmark['title'], 'benchmarkVersion': benchmark.get('version'), 'revision': revision,
            'canRun': ctx.user['role'] in EDITORS, 'runs': runs, 'topics': TOPICS,
            'items': [{'itemId': item['id'], 'question': item['question'], 'reference': item['answer'],
                       'answers': [c['answer'] for c in item['candidates']],
                       'rule': previous_rules.get(item['id'], default_rule(item))}
                      for item in benchmark['items']]}


def run_evaluation(ctx, benchmark, data):
    require_access(ctx, benchmark, write=True)
    revision = source_revision(benchmark)
    if data.get('revision') != revision:
        fail(409, '基准题目已变更，请重新打开自动评测')
    title = data.get('title')
    if not isinstance(title, str) or not 1 <= len(title.strip()) <= 120:
        fail(400, '评测名称须为 1–120 字')
    title = title.strip()
    inputs = data.get('items')
    if not isinstance(inputs, list) or not inputs or len(inputs) != len(benchmark['items']):
        fail(400, '请为基准中的每一道题提交规则和两份答案')
    items = {item['id']: item for item in benchmark['items']}
    results, totals, seen = [], defaultdict(lambda: [[], []]), set()
    for entry in inputs:
        if not isinstance(entry, dict) or not isinstance(entry.get('itemId'), str):
            fail(400, '评测题格式有误')
        source = items.get(entry['itemId'])
        if not source or source['id'] in seen:
            fail(400, '评测题重复或不属于当前基准')
        seen.add(source['id'])
        rule = checked_rule(entry.get('rule'))
        answers = entry.get('answers')
        if not isinstance(answers, list) or len(answers) != 2 or any(
                not isinstance(s, str) or not 1 <= len(s.strip()) <= 6000 for s in answers):
            fail(400, '每题须提供两份 1–6000 字的待测答案')
        answers = [s.strip() for s in answers]
        _, version = assert_holdout(ctx, source['resourceId'], source['versionId'], source['question'])
        evidence = anchors(version, source['blockIds'])
        scores = [evaluate_answer(answer, source['answer'], rule) for answer in answers]
        for index, score in enumerate(scores):
            totals[rule['topic']][index].append(score['score'])
        results.append({'itemId': source['id'], 'question': source['question'], 'reference': source['answer'],
                        'resourceId': source['resourceId'], 'resourceTitle': source['resourceTitle'],
                        'versionId': source['versionId'], 'evidence': evidence, 'rule': rule,
                        'answers': answers, 'scores': scores})
    key = digest([ENGINE, benchmark['id'], revision, title,
                  sorted(((i['itemId'], i['rule'], i['answers']) for i in results), key=lambda row: row[0])])
    existing = ctx.db.execute("SELECT id FROM evaluation_runs WHERE json_extract(payload,'$.key') = ?", (key,)).fetchone()
    if existing:
        return ctx.require('evaluation_runs', existing['id'])
    metrics = [{'topic': topic, 'count': len(totals[topic][0]),
                'means': [round(sum(group) / len(group), 1) if group else None for group in totals[topic]]}
               for topic in TOPICS]
    record = {'id': ctx.new_id('EVL'), 'key': key, 'engine': ENGINE, 'revision': revision,
              'benchmarkId': benchmark['id'], 'benchmarkTitle': benchmark['title'],
              'benchmarkVersion': benchmark.get('version'), 'benchmarkStatus': benchmark['status'],
              'title': title, 'createdAt': now(), 'createdBy': ctx.user['username'],
              'items': results, 'dimensions': metrics}
    ctx.put('evaluation_runs', record)
    ctx.audit('benchmark.auto-evaluate', record['id'], benchmark['id'])
    return record


def regression_comparison(ctx, ticket, benchmark, before_id, after_id):
    if before_id == after_id:
        fail(409, '基线与复测必须使用两份不同的已保存报告')
    frozen = benchmark.get('frozen') or {}
    item = next((i for i in frozen.get('items', []) if i['id'] == ticket['itemId']), None)
    if not item or frozen.get('version') != ticket['benchmarkVersion']:
        fail(409, '工单题目或冻结基准版本不匹配')
    reports, questions, sequence = [], [], []
    for run_id in (before_id, after_id):
        row = ctx.db.execute('SELECT rowid, payload FROM evaluation_runs WHERE id = ?', (run_id,)).fetchone()
        if not row:
            fail(404, '所选评测报告不存在')
        report = json.loads(row['payload'])
        if report['benchmarkId'] != ticket['benchmarkId'] or report.get('benchmarkVersion') != frozen['version']:
            fail(409, '请选择同一已发布基准版本的报告')
        question = next((q for q in report['items'] if q['itemId'] == item['id']), None)
        if (not question or any(question.get(key) != item.get(key) for key in ('resourceId', 'versionId', 'question', 'evidence'))
                or question.get('reference') != item['answer']):
            fail(409, '评测题目、原文版本、证据或参考答案与工单冻结快照不一致')
        reports.append(report)
        questions.append(question)
        sequence.append(row['rowid'])
    if sequence[0] >= sequence[1]:
        fail(409, '复测报告必须晚于基线报告')
    if reports[1]['createdAt'] < ticket['createdAt']:
        fail(409, '请选择本工单创建后运行的复测报告')
    if reports[1]['createdAt'] == ticket['createdAt']:
        marks = ctx.db.execute("""SELECT
            max(CASE WHEN action='feedback.create' AND target=? THEN seq END),
            max(CASE WHEN action='benchmark.auto-evaluate' AND target=? THEN seq END)
            FROM audit_log WHERE target IN (?,?)""",
            (ticket['id'], after_id, ticket['id'], after_id)).fetchone()
        if marks[0] is not None and (marks[1] is None or marks[1] < marks[0]):
            fail(409, '请选择本工单创建后运行的复测报告')
    if reports[0]['engine'] != reports[1]['engine'] or questions[0]['rule'] != questions[1]['rule']:
        fail(409, '两次评测的引擎或计分规则不同，请使用相同的专题、计分方法和参数重新评测')
    if ticket.get('regressionRule') and questions[0]['rule'] != checked_rule(ticket['regressionRule']):
        fail(409, '所选报告的计分规则与本工单登记的规则不一致')
    deltas = [round(end['score'] - start['score'], 2) for start, end in zip(questions[0]['scores'], questions[1]['scores'])]
    views = [dict(id=run['id'], title=run['title'], createdAt=run['createdAt'], createdBy=run['createdBy'],
                  answers=q['answers'], scores=q['scores']) for run, q in zip(reports, questions)]
    return {'benchmarkVersion': frozen['version'], 'itemId': item['id'], 'question': item['question'],
            'reference': item['answer'], 'resourceId': item['resourceId'], 'resourceTitle': questions[0]['resourceTitle'],
            'versionId': item['versionId'], 'evidence': item['evidence'], 'rule': questions[0]['rule'],
            'engine': reports[0]['engine'], 'reports': views, 'deltas': deltas}


def handle(ctx, method, path, data):
    match = ROUTE.fullmatch(path)
    if not match:
        return None
    benchmark_id, run_id = match.groups()
    benchmark = ctx.require('benchmarks', benchmark_id)
    if run_id and method == 'GET':
        require_access(ctx, benchmark)
        run = ctx.require('evaluation_runs', run_id)
        if run['benchmarkId'] != benchmark['id']:
            fail(404, '此基准下没有该评测记录')
        return run
    if not run_id and method == 'GET':
        return config(ctx, benchmark)
    if not run_id and method == 'POST':
        return run_evaluation(ctx, benchmark, data)
    return None
