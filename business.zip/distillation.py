"""Select quality-checked training samples and freeze their source evidence."""

import hashlib
import json
import re
from collections import deque

from core import fail, now
from corpus_topics import FAMILIES
from production import evidence_blocks, sample_key

WRITERS = ('operator',)
READERS = (*WRITERS, 'expert', 'annotator')


def digest(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def config(data):
    ids = data.get('batchIds')
    if not isinstance(ids, list) or not 1 <= len(ids) <= 100 or not all(isinstance(i, str) and i for i in ids):
        fail(422, '请选择 1–100 个批次')
    score, limit, dedup = data.get('minScore'), data.get('limit'), data.get('deduplicate')
    if type(score) is not int or not 0 <= score <= 100 or type(limit) is not int or not 1 <= limit <= 10000:
        fail(422, '最低规则分为 0–100，数量上限为 1–10000')
    if type(dedup) is not bool:
        fail(422, '请指定是否去重')
    order = data.get('selectionOrder', 'batch')
    if order not in ('batch', 'family'):
        fail(422, '请选择有效的取样顺序')
    result = dict(batchIds=sorted(set(ids)), minScore=score, limit=limit, deduplicate=dedup)
    if order == 'family':
        result['selectionOrder'] = order
    return result


def exclusion(sample, quality, resource, version, batch, score):
    if not resource or resource.get('split') != 'train':
        return '来源不在训练分区'
    if not version or version.get('status') != 'approved':
        return '源版本未核准'
    if (sample.get('batchId'), sample.get('resourceId'), sample.get('versionId')) != (batch['id'], resource['id'], version['id']):
        return '样本来源与批次不一致'
    if not quality:
        return '尚未执行规则质检'
    if sample.get('mode') == 'teacher' and sample.get('status') == 'candidate':
        return '教师候选待专家复核'
    if sample.get('status') != 'passed' or not quality.get('eligible'):
        return '样本未通过质检'
    if sample.get('mode') == 'teacher' and (sample.get('review') or {}).get('decision') != 'pass':
        return '缺少教师样本复核结论'
    if quality.get('score') is None or quality['score'] < score:
        return '低于最低规则分'
    if not evidence_blocks(sample, resource, version):
        return '原文证据无法核对'
    return ''


def preview(ctx, cfg):
    groups = {}
    for family in (*FAMILIES, '待归类'):
        groups[family] = dict(family=family, candidates=0, eligible=0, selected=0)
    rows, items, sources, eligible = [], [], set(), []
    for bid in cfg['batchIds']:
        batch = ctx.require('batches', bid)
        resource = ctx.get('resources', batch['resourceId'])
        version = next((v for v in (resource or {}).get('versions', []) if v['id'] == batch['versionId']), None)
        source = (batch['resourceId'], batch['versionId'])
        sources.add(source)
        meta = resource or {}
        family = meta.get('materialFamily') or meta.get('category', '').split('/')[0].strip()
        if family not in FAMILIES:
            family = '待归类'
        for sid in batch['sampleIds']:
            sample = ctx.require('samples', sid)
            quality = sample.get('quality') or {}
            reason = exclusion(sample, quality, resource, version, batch, cfg['minScore'])
            row = dict(sampleId=sid, batchId=bid, question=sample['question'], family=family,
                       score=quality.get('score'), included=False, reason=reason)
            rows.append(row)
            groups[family]['candidates'] += 1
            if not reason:
                groups[family]['eligible'] += 1
                eligible.append((row, sample))

    # A duplicate consumes no turn in a material family. The original order is
    # preserved within each group, including the default single queue.
    queues = {name: deque() for name in groups} if cfg.get('selectionOrder') == 'family' else {'all': deque()}
    for row, sample in eligible:
        key = row['family'] if cfg.get('selectionOrder') == 'family' else 'all'
        queues[key].append((row, sample))
    seen, admitted_sources = set(), set()
    active = deque(q for q in queues.values() if q)
    while active:
        queue = active.popleft()
        while queue:
            row, sample = queue.popleft()
            key = sample_key(sample)
            if cfg['deduplicate'] and key in seen:
                row['reason'] = '与已纳入问答重复'
            elif len(items) >= cfg['limit']:
                row['reason'] = '已达到数量上限'
            else:
                seen.add(key)
                row.update(included=True, reason='符合选集条件')
                groups[row['family']]['selected'] += 1
                admitted_sources.add((sample['resourceId'], sample['versionId']))
                items.append({k: sample.get(k) for k in ('id', 'batchId', 'resourceId', 'versionId', 'question',
                              'answer', 'mode', 'teacher', 'evidence', 'quality', 'review')})
                break
        if queue:
            active.append(queue)
    coverage = {'families': [g for name, g in groups.items() if name in FAMILIES or g['candidates']],
                'covered': sum(bool(groups[name]['selected']) for name in FAMILIES),
                'sourceVersions': len(admitted_sources)}
    result = dict(config=cfg, sourceCount=len(sources), total=len(rows), count=len(items),
                  rows=rows, items=items, coverage=coverage)
    result['previewHash'] = digest(result)
    return result


def handle(ctx, method, path, data):
    if not (path == '/api/distillations' or path.startswith('/api/distillations/')):
        return None
    ctx.allow(*READERS)
    if path == '/api/distillations' and method == 'GET':
        return [{k: r[k] for k in ('id', 'title', 'count', 'sourceCount', 'createdAt', 'createdBy')}
                for r in ctx.all('distillations')]
    if method == 'POST' and path in ('/api/distillations/preview', '/api/distillations'):
        ctx.allow(*WRITERS)
        cfg = config(data)
        if path.endswith('/preview'):
            return preview(ctx, cfg)
        title, token = data.get('title'), data.get('previewHash')
        if not isinstance(title, str) or not 1 <= len(title.strip()) <= 120 or not isinstance(token, str) or not re.fullmatch('[a-f0-9]{64}', token):
            fail(422, '请输入选集名称并完成预览')
        title = title.strip()
        ident = 'DST-' + digest([ctx.user['username'], title, cfg, token])[:24].upper()
        existing = ctx.get('distillations', ident)
        if existing:
            return existing
        result = preview(ctx, cfg)
        if result['previewHash'] != token:
            fail(409, '来源记录已变化，请重新预览')
        if not result['count']:
            fail(422, '没有符合条件的样本')
        result.update(id=ident, title=title, createdAt=now(), createdBy=ctx.user['username'])
        ctx.put('distillations', result)
        ctx.audit('保存蒸馏选集', ident, f"{title} · {result['count']} 条")
        return result
    target = re.fullmatch(r'/api/distillations/(DST-[A-F0-9]{24})(/export)?', path)
    if target and method == 'GET':
        record = ctx.require('distillations', target[1])
        if target[2]:
            ctx.allow('operator', 'annotator')
            content = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in record['items'])
            return dict(filename=record['id'] + '.jsonl', content=content)
        return record
    fail(405, '不支持此项选集操作')
