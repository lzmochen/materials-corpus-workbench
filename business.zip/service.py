"""Versioned data delivery, external training registry, and comparable run results."""

import hashlib
import json
import math
import re
from collections import Counter

from core import fail, now
from quality_work import release_conflicts
from release_comparison import compare as compare_release
import supply_work


def phrase(data, key, label, limit=200, required=True):
    value = data.get(key, '')
    if not isinstance(value, str) or len(value.strip()) > limit or (required and not value.strip()):
        fail(400, f'请填写有效的{label}（最多 {limit} 字）。')
    return value.strip()


def release_sources(ctx, record):
    if record['kind'] == 'benchmark':
        source = ctx.require('benchmarks', record['benchmarkId'])
        issues = [] if source['status'] == 'published' else ['基准尚未发布']
        return [{'id': source['id'], 'title': source['title'], 'status': source['status'], 'issues': issues}]
    sources = []
    batches = [ctx.require('batches', batch_id) for batch_id in record['batchIds']]
    pairs = {(batch['resourceId'], batch['versionId']) for batch in batches}
    conflicts = release_conflicts(ctx, pairs)
    for batch in batches:
        batch_id = batch['id']
        counts = batch.get('counts') or {}
        sample_ids = batch['sampleIds']
        actual = {}
        if sample_ids:
            placeholders = ','.join('?' for _ in sample_ids)
            actual = dict(ctx.db.execute(f"""SELECT json_extract(payload,'$.status'), count(*)
                FROM samples WHERE id IN ({placeholders}) GROUP BY 1""", sample_ids))
        issues = []
        if batch['status'] != 'reviewed':
            issues.append('批次尚未完成质检')
        if actual.get('candidate'):
            issues.append(f"{actual['candidate']} 条候选样本待处理")
        if not actual.get('passed'):
            issues.append('通过样本为 0 条')
        if sum(actual.values()) != len(sample_ids):
            issues.append('批次有样本记录缺失')
        elif any(key in counts and counts[key] != actual.get(key, 0) for key in ('candidate', 'passed')):
            issues.append('批次统计与样本状态不一致，请重新质检')
        if ctx.require('resources', batch['resourceId'])['split'] != 'train':
            issues.append('评测留出资料不能用于训练')
        blocked = [row for row in conflicts if any(
            v['resourceId'] == batch['resourceId'] and v['versionId'] == batch['versionId']
            for v in row['blockedVersions'])]
        if blocked:
            issues.append(f"当前原文版本有 {len(blocked)} 项跨源超差尚未放行")
        sources.append({'id': batch_id, 'title': batch['title'], 'status': batch['status'],
                        'issues': issues, 'qualityConflicts': blocked})
    return sources


def snapshot(ctx, record):
    for source in release_sources(ctx, record):
        if source['issues']:
            fail(409, f"{source['title']}（{source['id']}）：" + '，'.join(source['issues']))
    if record['kind'] == 'benchmark':
        benchmark = ctx.require('benchmarks', record['benchmarkId'])
        result = {'benchmarkId':benchmark['id'], 'benchmarkVersion':benchmark.get('version'), 'items':[{
            key:item.get(key) for key in ('id','resourceId','versionId','evidence','question','answer','category','rubric','result')
        } for item in benchmark['items']]}
        if benchmark.get('frozen', {}).get('blueprint'):
            result['blueprint'] = benchmark['frozen']['blueprint']
            result['items'] = benchmark['frozen']['items']
        return result
    records = []
    seen = set()
    annotations = {item['sampleId']:item for item in ctx.all('annotations') if item['status'] == 'approved'}
    formats = Counter()
    for batch_id in record['batchIds']:
        batch = ctx.require('batches', batch_id)
        batch_samples = [ctx.require('samples', sample_id) for sample_id in batch['sampleIds']]
        for sample in batch_samples:
            if sample['status'] != 'passed':
                continue
            key = (' '.join(sample['question'].lower().split()), ' '.join(sample['answer'].lower().split()))
            if key in seen:
                continue
            seen.add(key)
            export = {key:sample.get(key) for key in ('id','resourceId','versionId','batchId','question','answer','evidence','quality','teacher','mode')}
            if sample.get('extractionId'):
                export.update(extractionId=sample['extractionId'], knowledgeId=sample['knowledgeId'])
                rule = sample.get('rule') or {}
                if rule.get('type') == 'extract-span':
                    export['rule'] = {key: rule[key] for key in ('type', 'blockId', 'start', 'end')}
            export['messages'] = [{'role':'user','content':sample['question']},{'role':'assistant','content':sample['answer']}]
            if sample['id'] in annotations:
                annotation = annotations[sample['id']]
                export['reasoning'] = {'annotationId':annotation['id'],'steps':annotation['steps']}
                if annotation.get('materialCriteria'):
                    export['reasoning']['materialCriteria'] = annotation['materialCriteria']
            formats['cot' if 'reasoning' in export else 'qa'] += 1
            records.append(export)
    if not records:
        fail(409, '选择的批次没有可发布样本。')
    return {'items':records, 'formatCounts':dict(formats)}


def view(record):
    return {key:value for key,value in record.items() if key != 'snapshot'}


def new_release(ctx, data):
    ctx.allow('expert' if data.get('kind') == 'benchmark' else 'operator')
    title = phrase(data, 'title', '发布名称', 100)
    kind = data.get('kind')
    if kind not in ('training','benchmark'):
        fail(400, '请选择训练集或评测集。')
    release_id = ctx.new_id('REL')
    previous_id = phrase(data, 'previousId','上个版本编号', 40, False)
    previous = ctx.require('releases', previous_id) if previous_id else None
    if previous and (previous['kind'] != kind or previous['status'] != 'published'):
        fail(409, '只能续订已发布的同类版本。')
    family = previous['family'] if previous else release_id
    if previous:
        releases = [item for item in ctx.all('releases') if item['family'] == family]
        if previous_id != max(releases, key=lambda item:item['sequence'])['id']:
            fail(409, '已有更新的版本计划，请使用最新版本。')
    record = {'id':release_id,'family':family,'title':title,'kind':kind,'status':'draft','sequence':previous['sequence']+1 if previous else 1,
              'previousId':previous_id,'owner':ctx.user['username'],'createdAt':now(),'usage':phrase(data,'usage','用途',500,False)}
    if kind == 'training':
        batch_ids = data.get('batchIds', [])
        if not isinstance(batch_ids,list) or not 1 <= len(batch_ids) <= 25 or any(not isinstance(x,str) for x in batch_ids):
            fail(400, '请选择 1–25 个训练数据批次。')
        record['batchIds'] = list(dict.fromkeys(batch_ids))
        for batch_id in record['batchIds']:
            ctx.require('batches',batch_id)
    else:
        record['benchmarkId'] = phrase(data,'benchmarkId','评测基准编号',40)
        ctx.require('benchmarks',record['benchmarkId'])
    record['version'] = f"v{record['sequence']}.0"
    ctx.put('releases',record)
    ctx.audit('release.created',record['id'],record['version'])
    return view(record)


def new_run(ctx,data):
    ctx.allow('operator')
    train = ctx.require('releases', phrase(data,'releaseId','训练集编号',40))
    benchmark = ctx.require('releases', phrase(data,'benchmarkReleaseId','评测集编号',40))
    if (train['kind'], train['status'], benchmark['kind'], benchmark['status']) != ('training','published','benchmark','published'):
        fail(409, '仅能登记使用已发布训练集及评测集的任务。')
    external_id = phrase(data,'externalId','外部任务编号',120)
    framework = phrase(data,'framework','训练环境',120)
    if any(item['externalId'] == external_id and item['framework'] == framework for item in ctx.all('runs')):
        fail(409, '该训练环境下的外部任务编号已登记。')
    baseline_id = phrase(data,'baselineId','基线任务编号',40,False)
    model = phrase(data,'model','模型或底座版本',120)
    config = phrase(data,'config','实验配置',500,False)
    if baseline_id:
        baseline = ctx.require('runs',baseline_id)
        if baseline['benchmarkReleaseId'] != benchmark['id'] or baseline['status'] != 'completed':
            fail(409, '基线须使用同一评测集版本且已回填结果。')
        if not config or (framework, model, config) != (baseline['framework'], baseline['model'], baseline['config']):
            fail(409, '对照任务须填写与基线相同的运行环境、底座版本和实验配置。')
    record = {'id':ctx.new_id('RUN'),'title':phrase(data,'title','训练任务名称',120),'externalId':external_id,'framework':framework,
              'model':model,'config':config,
              'releaseId':train['id'],'benchmarkReleaseId':benchmark['id'],'baselineId':baseline_id,
              'status':'registered','metrics':{},'owner':ctx.user['username'],'createdAt':now()}
    record['project'] = phrase(data, 'project', '项目', 120, False)
    record['responsible'] = phrase(data, 'responsible', '任务责任人', 120, False) or ctx.user['username']
    record['purpose'] = phrase(data, 'purpose', '任务用途', 300, False)
    record['plannedUntil'] = supply_work.valid_date(data.get('plannedUntil', ''), optional=True)
    ctx.put('runs',record)
    ctx.audit('training.registered',record['id'],external_id)
    return record


def report(ctx, item, data):
    ctx.allow('operator')
    status = data.get('status')
    if item['status'] in ('completed','failed') or status not in ('running','completed','failed'):
        fail(409, '只能更新正在进行的训练任务。')
    note = phrase(data,'note','结果说明',1000,status in ('completed','failed'))
    metrics = data.get('metrics',{})
    if not isinstance(metrics,dict) or len(metrics) > 30 or (status == 'completed' and not metrics):
        fail(400, '回填完成结果时须提供 1–30 个数值指标。')
    if any(not 1 <= len(key.strip()) <= 70 or type(value) not in (int,float) or abs(value) > 10**12 or not math.isfinite(value) for key,value in metrics.items()):
        fail(400, '指标名称不能为空，数值须为有限数。')
    item.update(status=status,metrics=metrics,note=note,updatedAt=now())
    if status == 'completed' and item['baselineId']:
        baseline = ctx.require('runs',item['baselineId'])
        item['deltas'] = {key:round(value-baseline['metrics'][key],8) for key,value in metrics.items() if key in baseline['metrics']}
    ctx.put('runs',item)
    ctx.audit('training.reported',item['id'],status)
    return item


def handle(ctx, method, path, data):
    if path.startswith('/api/supply/v1/'):
        return supply_work.handle(ctx, method, path, data)
    if path == '/api/releases':
        if method == 'GET':
            return [view(record) for record in ctx.all('releases')]
        if method == 'POST':
            return new_release(ctx,data)
    release = re.fullmatch(r'/api/releases/(REL-[A-F0-9]+)(?:/(publish|export|comparison))?',path)
    if release:
        item = ctx.require('releases',release[1])
        operation = release[2]
        if operation == 'comparison' and method == 'GET':
            return compare_release(ctx, item, snapshot)
        if not operation and method == 'GET':
            details = view(item)
            child = ctx.db.execute("SELECT id FROM releases WHERE json_extract(payload,'$.previousId') = ? LIMIT 1",
                                   (item['id'],)).fetchone()
            details['nextId'] = child['id'] if child else None
            if item['status'] == 'draft':
                details['sources'] = release_sources(ctx, item)
            return details
        if operation == 'publish' and method == 'POST':
            ctx.allow('expert' if item['kind'] == 'benchmark' else 'operator')
            if item['status'] != 'draft':
                fail(409, '当前版本已冻结。')
            record_snapshot = snapshot(ctx,item)
            item.update(status='published',publishedAt=now(),publishedBy=ctx.user['username'],snapshot=record_snapshot,
                        itemCount=len(record_snapshot['items']), formatCounts=record_snapshot.get('formatCounts'))
            ctx.put('releases',item)
            ctx.audit('release.published',item['id'],item['version'])
            return view(item)
        if operation == 'export' and method == 'POST':
            ctx.allow('operator')
            if item['status'] != 'published':
                fail(409, '草稿版本须发布后才能交付。')
            recipient = phrase(data,'recipient','接收方',120)
            target = f"{item['id']}-{item['version']}"
            ctx.audit('release.delivered',item['id'],recipient)
            manifest = {key:item.get(key) for key in ('id','title','kind','version','previousId','itemCount','usage','formatCounts','publishedAt','publishedBy')}
            payload = item['snapshot']['items']
            sources = {}
            for row in payload:
                key = (row['resourceId'], row['versionId'])
                if key not in sources:
                    resource = ctx.require('resources', row['resourceId'])
                    version = next(v for v in resource['versions'] if v['id'] == row['versionId'])
                    sources[key] = {'resourceId':key[0],'versionId':key[1],'sha256':version['sha256'],'filename':version['filename']}
            manifest['sources'] = list(sources.values())
            if item['kind'] == 'training':
                quality_scores = [row['quality']['score'] for row in payload if row.get('quality') and row['quality'].get('score') is not None]
                manifest['quality'] = {'scoredItems':len(quality_scores), 'meanRuleScore':round(sum(quality_scores)/len(quality_scores),2) if quality_scores else None}
                filename = f'{target}.jsonl'
                content = '\n'.join(json.dumps(row,ensure_ascii=False) for row in payload)+'\n'
            else:
                filename = f'{target}.json'
                content = json.dumps({'manifest':manifest,**item['snapshot']},ensure_ascii=False,indent=2)
            return {'filename':filename,'content':content,'manifest':{**manifest,'contentSha256':hashlib.sha256(content.encode()).hexdigest()}}
    if path == '/api/runs':
        if method == 'GET':
            return ctx.all('runs')
        if method == 'POST':
            return new_run(ctx,data)
    run = re.fullmatch(r'/api/runs/(RUN-[A-F0-9]+)(/report)?',path)
    if run:
        item = ctx.require('runs',run[1])
        if method == 'GET' and not run[2]:
            return item
        if method == 'POST' and run[2]:
            return report(ctx,item,data)
    return None
