"""Catalog vocabulary and image–text training pairs for materials corpora."""

import base64
import csv
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

from core import fail, now
from production import resolve_version, value


FAMILIES = ('金属材料', '无机非金属材料', '高分子材料', '复合材料')
TOPICS = ('基础概念理解', '标准技术规则识别', '科学计算')
FORMATS = {'.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg'}


def catalog_fields(data):
    out = {}
    for field, options in [('materialFamily', FAMILIES), ('topic', TOPICS)]:
        item = data.get(field, '')
        if item and item not in options:
            fail(422, '请选择有效的材料门类和语料专题')
        if item:
            out[field] = item
    return out


def training_version(ctx, data, prefix):
    resource = ctx.require('resources', value(data, prefix + 'ResourceId', 80))
    if resource['split'] != 'train':
        fail(422, '图文语料只接受训练分区资源')
    version = resolve_version(resource, value(data, prefix + 'VersionId', 80))
    return resource, version


def make_pair(ctx, data):
    ctx.allow('operator', 'annotator', 'lead', 'admin')
    image, iv = training_version(ctx, data, 'image')
    document, tv = training_version(ctx, data, 'text')
    ext = Path(iv['filename']).suffix.lower()
    if ext not in FORMATS or Path(tv['filename']).suffix.lower() in FORMATS or tv['status'] != 'approved':
        fail(422, '请选择图像原件及已核准的文本或表格版本')
    raw = ctx.read_blob(iv['sha256'])
    signature = b'\x89PNG\r\n\x1a\n' if ext == '.png' else b'\xff\xd8\xff'
    if not raw.startswith(signature):
        fail(422, '图像原件格式与扩展名不符')
    if data.get('confirmed') is not True:
        fail(422, '请核对原图与所选证据的对应关系')
    block_id = value(data, 'blockId', 100)
    block = next((b for b in tv['blocks'] if b['id'] == block_id), None)
    if not block:
        fail(422, '引用的证据块不在当前文本版本中')
    caption = value(data, 'caption', 1400)
    key = json.dumps([iv['sha256'], tv['id'], block_id, caption], ensure_ascii=False)
    record_id = 'PAIR-' + hashlib.sha256(key.encode()).hexdigest()[:20].upper()
    prior = ctx.get('multimodal_pairs', record_id)
    if prior:
        return prior
    def source(resource, version):
        return {'resourceId': resource['id'], 'versionId': version['id'], 'sha256': version['sha256'],
                'filename': version['filename'], 'title': resource['title'], 'source': resource['source'],
                'license': resource['license'], 'provenance': resource.get('provenance', '')}
    pair = {'id': record_id, 'createdBy': ctx.user['username'], 'createdAt': now(),
            'materialFamily': document.get('materialFamily') or document['category'].split('/')[0].strip(),
            'topic': document.get('topic', ''), 'image': source(image, iv), 'text': source(document, tv),
            'evidence': {'blockId': block_id, 'location': block['location'], 'text': block['text']},
            'caption': caption}
    ctx.put('multimodal_pairs', pair)
    ctx.audit('登记图文配对', record_id, [image['id'], document['id'], block_id])
    return pair


def export_pairs(ctx, data):
    ids = data.get('pairIds')
    if not isinstance(ids, list) or not 1 <= len(ids) <= 200 or not all(isinstance(k, str) for k in ids) or len(set(ids)) != len(ids):
        fail(422, '请选择 1–200 个不重复的配对记录')
    items = [ctx.require('multimodal_pairs', item) for item in ids]
    output = io.BytesIO()
    manifest, images, byte_count = [], set(), 0
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as package:
        for item in items:
            img = item['image']
            name = 'images/' + img['sha256'] + Path(img['filename']).suffix.lower()
            if name not in images:
                raw = ctx.read_blob(img['sha256'])
                byte_count += len(raw)
                if byte_count > 24 * 1024 * 1024:
                    fail(413, '所选图像合计超过 24 MiB，请分批导出')
                package.writestr(name, raw)
                images.add(name)
            manifest.append(json.dumps(dict(item, imagePath=name), ensure_ascii=False))
        package.writestr('pairs.jsonl', '\n'.join(manifest) + '\n')
    ctx.audit('导出图文语料包', items[0]['id'], {'pairs': ids})
    return {'filename': '材料图文语料包.zip', 'contentBase64': base64.b64encode(output.getvalue()).decode('ascii')}


def handle(ctx, method, path, data):
    if method == 'GET' and path == '/api/training-practice-files':
        return practice_files()
    if path == '/api/multimodal-pairs':
        if method == 'GET':
            return ctx.all('multimodal_pairs')
        if method == 'POST':
            return make_pair(ctx, data)
    match_pair = re.fullmatch(r'/api/multimodal-pairs/(PAIR-[A-F0-9]+)', path)
    if method == 'GET' and match_pair:
        return ctx.require('multimodal_pairs', match_pair[1])
    if path == '/api/multimodal-pairs/export' and method == 'POST':
        return export_pairs(ctx, data)
    match = re.fullmatch(r'/api/resources/([A-Z0-9-]+)/classification', path)
    if match and method == 'POST':
        ctx.allow('operator', 'lead', 'admin')
        record = ctx.require('resources', match[1])
        fields = catalog_fields(data)
        if len(fields) != 2:
            fail(422, '请填写材料门类和专题')
        revision = record.get('classificationRevision', 0)
        if type(data.get('revision')) is not int or data['revision'] != revision:
            fail(409, '分类已更新，请重新打开资源核对')
        record.update(**fields, classificationRevision=revision + 1)
        ctx.put('resources', record)
        ctx.audit('更新资源分类', record['id'], fields)
        return record
    return None


def practice_files():
    from guide_seed import FILES, FOLDER
    from guide_charts import CHARTS
    from reference_materials import reference_tables
    inventory = io.StringIO()
    rows = csv.writer(inventory)
    rows.writerow(['文件', '材料门类', '专题', '用途', '来源', '配套训练资源'])
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for key, family, branch, topic, filename, split in FILES:
            if split != 'train':
                continue
            path = FOLDER / filename
            archive.writestr('训练资料/' + filename, path.read_bytes())
            rows.writerow(['训练资料/' + filename, family + ' / ' + branch, topic, '训练', '合成', ''])
            candidate = FOLDER / '教师候选' / (path.stem + '-候选.jsonl')
            if candidate.is_file():
                archive.writestr('教师候选/' + candidate.name, candidate.read_bytes())
                rows.writerow(['教师候选/' + candidate.name, family, topic, '教师候选导入', '合成', filename])
        families = {f[0]: f[1] for f in FILES}
        for key, source_name, chart_name, *_ in CHARTS:
            label = '图表/' + chart_name
            archive.writestr(label, (FOLDER / chart_name).read_bytes())
            rows.writerow([label, families[key], '科学计算', '图文配对', '合成', source_name])
        for family, subgroup, title, _, content in reference_tables():
            label = '公开参考/' + title + '.csv'
            archive.writestr(label, content)
            rows.writerow([label, family + ' / ' + subgroup, '科学计算', '训练', 'NIST，逐行附原表链接', ''])
        archive.writestr('文件清单.csv', inventory.getvalue().encode('utf-8-sig'))
    return {'filename': '课题一训练操作材料.zip', 'contentBase64': base64.b64encode(output.getvalue()).decode('ascii')}


def seed_pore_pair(ctx):
    from core import Context
    from guide_seed import FOLDER
    marker = 'cp11-illustrated-pair-v1'
    if ctx.db.execute('SELECT 1 FROM meeting_seed WHERE id=?', (marker,)).fetchone():
        return
    bundled = {r.get('seedKey'): r for r in ctx.all('resources') if r.get('provenance') == 'synthetic'}
    image, doc = bundled.get('ceramic-pore-image'), bundled.get('ceramic-concept')
    if image and doc:
        def bundled_version(resource, filename):
            digest = hashlib.sha256((FOLDER / filename).read_bytes()).hexdigest()
            return next((v for v in resource['versions'] if v['filename'] == filename and v['sha256'] == digest), None)
        iv = bundled_version(image, 'CP-11-截面孔隙示意图.png')
        tv = bundled_version(doc, '氧化铝开口孔观察记录.txt')
        block = next((b for b in (tv or {}).get('blocks', []) if 'A 的轮廓直接连到试样外表面' in b['text']), None)
        if iv and block and tv['status'] == 'approved':
            importer = Context(ctx.db, {'username': '配套样本导入', 'role': 'operator'})
            make_pair(importer, {'imageResourceId': image['id'], 'imageVersionId': iv['id'],
                'textResourceId': doc['id'], 'textVersionId': tv['id'], 'blockId': block['id'],
                'caption': 'CP-11 示意图 A 区与左侧外表面相通，对应观察记录中的开口孔。', 'confirmed': True})
    ctx.db.execute('INSERT INTO meeting_seed VALUES (?)', (marker,))
