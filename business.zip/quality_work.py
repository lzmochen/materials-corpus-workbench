"""Version-bound, inspectable quality checks on training data and source measurements."""
import base64
from collections import defaultdict
from decimal import Decimal
import hashlib
import json
import re
import unicodedata

from core import fail, now
import production as prod

BASE = '/api/quality-work'
READ = ('operator', 'annotator', 'expert')
REVIEW = ('operator', 'expert')
DECISIONS = ('采用原始记录', '采用对照记录', '保留差异待复测', '待补证', '经复核允许双方采用')
STATES = ('consistent', 'conflict', 'context', 'missing', 'ambiguous', 'insufficient')
# Factors are exact conversions into the canonical unit for the chosen property.
PRESSURE = {'Pa': '0.000001', 'kPa': '0.001', 'MPa': '1', 'GPa': '1000', 'N/mm2': '1'}
DENSITY = {'g/cm3': '1', 'kg/m3': '0.001', 'g/mL': '1'}
PROPERTIES = {
    '屈服强度': ('MPa', PRESSURE), '抗拉强度': ('MPa', PRESSURE), '弯曲强度': ('MPa', PRESSURE),
    '弯曲模量': ('MPa', PRESSURE), '弹性模量': ('MPa', PRESSURE),
    '密度': ('g/cm³', DENSITY), '体积密度': ('g/cm³', DENSITY),
    '洛氏硬度 HRC': ('HRC', {'HRC': '1'}), '维氏硬度 HV': ('HV', {'HV': '1'}),
}
ID_KEYS = ('试样', '试样编号', '样品', '样品编号', '试件编号', '样本编号', 'sample', 'sampleid')
MATERIAL_KEYS = ('材料', '材料牌号', '牌号', '材质')
EMPTY_VALUES = {'', '-', '—', '/', 'n/a', 'na', 'unknown', '未知', '缺失', '未记录', '未填写', '无记录'}
CONTEXT_KEYS = {'试验温度(°C)': '温度(°C)', '测量温度(°C)': '温度(°C)', '测试温度(°C)': '温度(°C)',
                '热处理状态': '状态', '材料状态': '状态'}
EXAMPLES = [
    ('铝板拉伸原始记录（核查练习）', '试样,材料牌号,状态,温度(℃),屈服强度(MPa)\nQAL-01,AA5754,H22,23,158\nQAL-02,AA5754,H22,23,165\nQAL-03,AA5754,H22,23,162\nQAL-04,AA5754,H22,23,160\n'),
    ('铝板拉伸转录记录（核查练习）', '试样,材料牌号,状态,试验温度(°C),屈服强度(GPa)\nQAL-01,AA5754,H22,23,0.158\nQAL-02,AA5754,H22,23,0.169\nQAL-03,AA5754,H22,80,0.162\n'),
]


def norm(value):
    return unicodedata.normalize('NFKC', str(value)).strip()


def read_field(label):
    match = re.fullmatch(r'(.+?)(?:\s*\(([^()]*)\))?', norm(label))
    if not match:
        return '', ''
    name, unit = match[1].strip(), (match[2] or '').strip()
    if name == '硬度':
        name = {'HRC': '洛氏硬度 HRC', 'HV': '维氏硬度 HV'}.get(unit, '')
    return name, unit


def version_ref(resource, version):
    return dict(resourceId=resource['id'], versionId=version['id'], title=resource['title'],
                filename=version['filename'], number=version['number'], sha256=version.get('sha256', ''))


def version_metrics(version):
    properties = {read_field(key)[0] for block in version.get('blocks', []) for key in block.get('fields', {})}
    return sorted(properties & PROPERTIES.keys())


def public_index(ctx):
    resources = [r for r in ctx.all('resources') if r.get('split') == 'train']
    versions = []
    for r in resources:
        for v in reversed(r['versions']):
            metrics = version_metrics(v) if v['status'] == 'approved' else []
            if metrics:
                versions.append(dict(**version_ref(r, v), metrics=metrics, catalogTier=r.get('catalogTier'), researchCase=r.get('researchCase')))
    training = {r['id']:r for r in resources}
    batches = [dict(id=b['id'], title=b['title'], count=len(b['sampleIds']), status=b['status'],
                    resourceId=b['resourceId'], researchCase=training[b['resourceId']].get('researchCase'),
                    catalogTier=b.get('catalogTier'))
               for b in ctx.all('batches') if b['resourceId'] in training]
    runs = [dict(id=r['id'], title=r['title'], at=r['at'], counts=r['counts'], reviewed=len(r.get('decisions', {})))
            for r in ctx.all('quality_checks')]
    return dict(versions=versions, batches=batches, runs=runs, units={k: v[0] for k, v in PROPERTIES.items()})


def batch_report(ctx, bid):
    batch = ctx.require('batches', bid)
    resource = ctx.require('resources', batch['resourceId'])
    if resource['split'] != 'train':
        fail(403, '仅核对训练语料批次')
    version = prod.resolve_version(resource, batch['versionId'])
    samples = prod.get_samples(ctx, batch)
    dimensions = {key: {'applicable': 0, 'passed': 0} for key in prod.DIMENSIONS}
    checked = 0
    for sample in samples:
        quality = sample.get('quality') or {}
        if quality:
            checked += 1
        for name in dimensions:
            score = (quality.get('dimensions') or {}).get(name)
            if score is not None:
                dimensions[name]['applicable'] += 1
                dimensions[name]['passed'] += int(score == 100)
    return dict(title=batch['title'], id=bid, source=version_ref(resource, version), dimensions=dimensions,
                total=len(samples), checked=checked, samples=samples, status=batch['status'])


def cfg_decimal(raw):
    if not isinstance(raw, (float, int, str)) or isinstance(raw, bool) or not re.fullmatch(r'\d{1,9}(?:\.\d{1,9})?', str(raw)):
        fail(422, '绝对容差应为非负数，小数位不超过9位')
    return Decimal(str(raw))


def identified(value):
    text = norm(value)
    return '' if text.casefold() in EMPTY_VALUES else text


def conditions(fields, measured):
    """Keep all other metadata conservatively, excluding identifiers and measured properties."""
    result = {}
    for key, value in fields.items():
        name = norm(key)
        if name == measured or name.lower() in ID_KEYS or name in MATERIAL_KEYS or read_field(name)[0] in PROPERTIES:
            continue
        if name in ('来源链接', '页码', '行号', '记录编号', '备注'):
            continue
        normalized = identified(value)
        if re.fullmatch(r'[+-]?\d+(?:\.\d+)?', normalized):
            normalized = prod.formatted_decimal(Decimal(normalized))
        canonical = CONTEXT_KEYS.get(name, name)
        if canonical in result and result[canonical] != normalized:
            result[canonical] = ''
        else:
            result[canonical] = normalized
    return result


def source_readings(resource, version, metric, side):
    readings = defaultdict(list)
    for block in version.get('blocks', []):
        fields = block.get('fields', {})
        for label, value in fields.items():
            name, header_unit = read_field(label)
            if name != metric:
                continue
            ident = next((identified(v) for k, v in fields.items() if norm(k).lower() in ID_KEYS and identified(v)), '')
            material = next((identified(v) for k, v in fields.items() if norm(k) in MATERIAL_KEYS and identified(v)), '')
            val = prod.parse_number(norm(value), label)
            number = None
            unit = norm(val[1]).replace(' ', '') if val else header_unit
            field_unit = norm(header_unit).replace(' ', '')
            if val and unit in PROPERTIES[metric][1] and (not field_unit or field_unit == unit):
                number = prod.formatted_decimal(val[0] * Decimal(PROPERTIES[metric][1][unit]))
            key = ('sample', ident) if ident else (side, block['id'])
            readings[key].append(dict(blockId=block['id'], location=block['location'], text=block['text'], sample=ident,
                field=label, raw=value, unit=unit, standard=number, material=material, conditions=conditions(fields, norm(label))))
    return readings


def has_test_conditions(row):
    fields = row['conditions']
    return (bool(fields) and all(fields.values())
            and any(re.search(r'温度|湿度|热处理|淬火|回火|状态|保温|烧结|加载|应变|试验方法|测试方法|压头|载荷|跨厚比|调湿|取样方向', key)
                    for key in fields))


def compare(left, right, tolerance):
    if len(left) > 1 or len(right) > 1:
        return 'ambiguous', '同一资料中有多条同试样、同指标记录，需先确定配对。', None
    if any(not r['sample'] for r in left + right):
        return 'insufficient', '缺少试样编号，无法建立跨资料对应关系。', None
    if not left or not right:
        return 'missing', '仅在一份资料中找到此试样的该项读数。', None
    a, b = left[0], right[0]
    if not a['material'] or not b['material'] or not has_test_conditions(a) or not has_test_conditions(b):
        return 'insufficient', '材料标识或可核对的试验条件缺失。', None
    if (a['material'], a['conditions']) != (b['material'], b['conditions']):
        return 'context', '两份记录的材料或试验条件不同，不能直接判定读数冲突。', None
    if a['standard'] is None or b['standard'] is None:
        return 'insufficient', '数值、单位或表头与单元格口径无法核实。', None
    delta = abs(Decimal(a['standard']) - Decimal(b['standard']))
    state = 'consistent' if delta <= tolerance else 'conflict'
    reason = '绝对差在容差内。' if state == 'consistent' else '绝对差超出设定容差。'
    return state, reason, prod.formatted_decimal(delta)


def fingerprint(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True).encode()).hexdigest()


def prepare(ctx, data):
    metric = data.get('metric')
    if not isinstance(metric, str) or metric not in PROPERTIES:
        fail(422, '请选择有效的核查指标')
    tolerance = cfg_decimal(data.get('tolerance'))
    rr, vv = [], []
    for side in ('left', 'right'):
        r, v = prod.training_source(ctx, dict(resourceId=data.get(side+'Id'), versionId=prod.value(data, side+'Version', 80)))
        rr.append(r); vv.append(v)
    if rr[0]['id'] == rr[1]['id'] or vv[0]['sha256'] == vv[1]['sha256']:
        fail(422, '请选择两份不同来源文件进行对照')
    left, right = [source_readings(r,v,metric,side) for r,v,side in zip(rr,vv,('left','right'))]
    if not left or not right:
        fail(422, '两份版本都须有选定指标的结构化原文记录')
    rows = []
    counts = dict.fromkeys(STATES, 0)
    for key in sorted(left.keys() | right.keys()):
        a, b = left.get(key, []), right.get(key, [])
        state, reason, delta = compare(a, b, tolerance)
        rows.append(dict(key=fingerprint(key)[:24], sample=(a or b)[0]['sample'] or '缺少试样编号',
                         left=a, right=b, state=state, reason=reason, delta=delta))
        counts[state] += 1
    a, b = [version_ref(r, v) for r, v in zip(rr, vv)]
    normalized = prod.formatted_decimal(tolerance)
    identity = fingerprint([a['versionId'], b['versionId'], metric, normalized])
    return dict(id='QC-'+identity[:20].upper(), title=metric+' · '+rr[0]['title']+' / '+rr[1]['title'],
                metric=metric, unit=PROPERTIES[metric][0], tolerance=normalized, left=a, right=b,
                rows=rows, counts=counts, decisions={}, rulesVersion='1.0')


def save_check(ctx, data):
    run = prepare(ctx, data)
    prior = ctx.get('quality_checks', run['id'])
    if prior:
        return prior
    run.update(at=now(), by=ctx.user['username'])
    ctx.put('quality_checks', run)
    ctx.audit('生成跨源一致性核查单', run['id'], run['title'])
    return run


def import_example(ctx, data):
    ctx.allow(*prod.OPERATORS)
    if data.get('confirmed') is not True:
        fail(422, '请核对两份合成资料后确认登记和核准')
    resources = ctx.all('resources')
    params = dict(metric='屈服强度', tolerance='1')
    for side, (title, csv_text) in zip(('left','right'), EXAMPLES):
        raw = csv_text.encode()
        digest = hashlib.sha256(raw).hexdigest()
        existing = next(((r,v) for r in resources if r.get('split') == 'train' and r.get('source') == '质量核查合成资料'
                         for v in r.get('versions',[]) if v.get('sha256') == digest and v.get('status') == 'approved'), None)
        if existing:
            resource, version = existing
        else:
            resource = prod.register_resource(ctx, dict(title=title, filename=title+'.csv', source='质量核查合成资料',
                license='课题讨论练习', category='铝合金', topic='科学计算', materialFamily='金属材料', split='train',
                notes='用于核对转录差异和测量条件，读数为合成数据。', contentBase64=base64.b64encode(raw).decode()))
            version = prod.resolve_version(resource)
            prod.update_resource(ctx, resource, version, 'parsing')
            prod.run_parse(ctx, dict(resourceId=resource['id'], versionId=version['id'], template='auto'))
            resource = ctx.require('resources', resource['id'])
            prod.approve_resource(ctx, resource, dict(versionId=version['id'], note='经办人已在导入页核对合成原表'))
        params[side+'Id'] = resource['id']
        params[side+'Version'] = version['id']
    return save_check(ctx, params)


def adjudicate(ctx, run, data):
    ctx.allow(*REVIEW)
    row_id = prod.value(data, 'rowKey', 48)
    item = next((r for r in run['rows'] if r['key'] == row_id), None)
    if not item:
        fail(404, '核查条目不存在')
    decision = prod.choice(data, 'decision', DECISIONS)
    note = prod.value(data, 'note', 1200)
    if (decision == DECISIONS[0] and not item['left']) or (decision == DECISIONS[1] and not item['right']):
        fail(422, '该侧缺少原始读数，请调整处置意见')
    release_confirmed = data.get('confirmRelease') is True
    if release_confirmed:
        ctx.allow('expert')
        if item['state'] != 'conflict' or decision not in (DECISIONS[0], DECISIONS[1], DECISIONS[4]):
            fail(422, '放行复核须选择采信资料或允许双方采用')
    if decision == DECISIONS[4] and not release_confirmed:
        fail(422, '允许双方采用须由评审专家确认放行依据')
    history = run.setdefault('decisions', {}).setdefault(row_id, [])
    revision = data.get('revision')
    if type(revision) is not int or revision != len(history):
        fail(409, '该行已有新处置，请重新打开核查记录')
    history.append(dict(decision=decision, note=note, releaseConfirmed=release_confirmed, by=ctx.user['username'], at=now()))
    ctx.put('quality_checks', run)
    ctx.audit('处置跨源核查条目', run['id'], item['sample']+' · '+decision+' · '+note)
    return run


def row_disposition(run, row):
    history = (run.get('decisions') or {}).get(row['key']) or []
    last = history[-1] if history else {}
    decision = last.get('decision')
    has_basis = bool((last.get('note') or '').strip())
    if row['state'] != 'conflict':
        resolved = row['state'] == 'consistent' or (decision in DECISIONS[:2] and has_basis)
        return dict(blockedSides=[], needsAction=not resolved, reason='')

    allowed = set()
    if last.get('releaseConfirmed') is True and has_basis:
        allowed = {DECISIONS[0]: {'left'}, DECISIONS[1]: {'right'},
                   DECISIONS[4]: {'left', 'right'}}.get(decision, set())
    blocked = [side for side in ('left', 'right') if side not in allowed]
    if allowed:
        reason = '复核采信另一份资料，此版须订正' if blocked else '双方版本已有放行复核依据'
    elif decision in DECISIONS[:2]:
        reason = '已登记采信意见，尚待评审专家确认放行'
    else:
        reason = decision or '读数超差，尚无放行依据'
    return dict(blockedSides=blocked, needsAction=bool(blocked), reason=reason)


def run_view(run):
    # Derive workflow state from each row's most recent decision for old and new records alike.
    return dict(run, decisions=run.get('decisions') or {},
                rows=[dict(row, disposition=row_disposition(run, row)) for row in run['rows']])


def release_conflicts(ctx, version_pairs):
    """List only known, comparable, out-of-tolerance readings affecting the supplied versions."""
    if not version_pairs:
        return []
    blockers = []
    for run in ctx.all('quality_checks'):
        affected = {side for side in ('left', 'right')
                    if (run[side]['resourceId'], run[side]['versionId']) in version_pairs}
        if not affected:
            continue
        for row in run['rows']:
            if row['state'] != 'conflict':
                continue
            control = row_disposition(run, row)
            blocked = [side for side in control['blockedSides'] if side in affected]
            if blocked:
                blockers.append(dict(runId=run['id'], rowKey=row['key'], sample=row['sample'], metric=run['metric'],
                    unit=run['unit'], delta=row['delta'], tolerance=run['tolerance'], reason=control['reason'],
                    blockedVersions=[{k:run[side][k] for k in ('resourceId','versionId','title','number')} for side in blocked]))
    return blockers


def handle(ctx, method, path, data):
    if path != BASE and not path.startswith(BASE+'/'):
        return None
    ctx.allow(*READ)
    if path == BASE and method == 'GET':
        return public_index(ctx)
    if path == BASE+'/example':
        if method == 'GET':
            return [dict(title=n, text=c) for n,c in EXAMPLES]
        if method == 'POST':
            return run_view(import_example(ctx, data))
    if path == BASE+'/runs' and method == 'POST':
        ctx.allow(*prod.OPERATORS)
        return run_view(save_check(ctx, data))
    target = re.fullmatch(BASE+r'/samples/([\w-]+)', path)
    if target and method == 'GET':
        sample = ctx.require('samples', target[1])
        resource = ctx.require('resources', sample['resourceId'])
        if resource['split'] != 'train':
            fail(403, '仅核对训练样本')
        version = prod.resolve_version(resource, sample['versionId'])
        blocks = prod.evidence_blocks(sample, resource, version)
        return dict(sample=sample, source=version_ref(resource, version),
                    evidence=blocks, expected=prod.expected_answer(sample, blocks) if sample.get('mode') != 'teacher' else None)
    target = re.fullmatch(BASE+r'/batches/([\w-]+)', path)
    if target and method == 'GET':
        return batch_report(ctx, target[1])
    target = re.fullmatch(BASE+r'/runs/(QC-[A-F0-9]{20})(/decisions)?', path)
    if target:
        run = ctx.require('quality_checks', target[1])
        if not target[2] and method == 'GET':
            return run_view(run)
        if target[2] and method == 'POST':
            return run_view(adjudicate(ctx, run, data))
    fail(405, '不支持此项质量核查操作')
