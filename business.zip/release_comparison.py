"""Compare release snapshots by stable item ID and explicitly paired external runs."""

from core import fail


DIMENSIONS = {
    'accuracy': '准确性', 'completeness': '完整性', 'consistency': '一致性',
    'diversity': '多样性', 'format': '规范性', 'traceability': '可追溯性',
}
FIELD_NAMES = {
    'question': '问题', 'answer': '答案', 'resourceId': '来源资料', 'versionId': '原文版本',
    'batchId': '加工批次', 'evidence': '证据', 'quality': '质检结果', 'reasoning': 'CoT 标注',
    'teacher': '教师来源', 'mode': '生成方式', 'category': '分类', 'rubric': '评分标准',
    'result': '评审结果', 'rule': '生成规则', 'knowledgeId': '知识条目', 'extractionId': '抽取记录',
    'blueprintCandidateId': '蓝图候选', 'questionType': '题型', 'materialFamily': '材料门类',
    'topic': '专题', 'candidates': '候选回答', 'autoRule': '评分规则',
}


def indexed_items(snapshot):
    items = snapshot.get('items')
    if not isinstance(items, list):
        fail(409, '此版本缺少可核对的样本快照。')
    indexed = {}
    for item in items:
        key = item.get('id')
        if not key or key in indexed:
            fail(409, '此版本包含缺失或重复的样本编号，无法按编号对比。')
        indexed[key] = item
    return indexed


def business_fields(item):
    # Messages mirror question/answer. Inspection dates alone do not revise content.
    result = {key: value for key, value in item.items() if key not in ('id', 'messages') and value is not None}
    if isinstance(result.get('quality'), dict):
        result['quality'] = {k: v for k, v in result['quality'].items() if k != 'checkedAt'}
    return result


def dimension_stats(items, key):
    scores = []
    for item in items.values():
        value = ((item.get('quality') or {}).get('dimensions') or {}).get(key)
        if type(value) in (int, float):
            scores.append(value)
    return {'n': len(scores), 'mean': round(sum(scores) / len(scores), 2) if scores else None}


def paired_results(ctx, previous, current):
    if not previous or current['kind'] != 'training' or current['status'] != 'published':
        return []
    runs = {r['id']: r for r in ctx.all('runs') if r['status'] == 'completed'}
    results = []
    for run in runs.values():
        if run.get('releaseId') != current['id']:
            continue
        base = runs.get(run.get('baselineId'))
        if not base or base['releaseId'] != previous['id'] or not run.get('config'):
            continue
        if any(base.get(key) != run.get(key) for key in ('benchmarkReleaseId', 'framework', 'model', 'config')):
            continue
        for key in sorted(base['metrics'].keys() & run['metrics'].keys()):
            before, after = base['metrics'][key], run['metrics'][key]
            results.append({'metric': key, 'before': before, 'after': after, 'delta': round(after - before, 8),
                            'baseline': base['externalId'], 'run': run['externalId'],
                            'benchmarkReleaseId': run['benchmarkReleaseId'], 'model': run['model'],
                            'framework': run['framework'], 'config': run['config']})
    return results


def compare(ctx, record, build_snapshot):
    ctx.allow('operator')
    previous = ctx.require('releases', record['previousId']) if record.get('previousId') else None
    if previous and (previous['status'] != 'published' or previous['family'] != record['family']
                     or previous['kind'] != record['kind']):
        fail(409, '前一版本未冻结或不属于同一版本链。')
    old = indexed_items(previous.get('snapshot') or {}) if previous else {}
    current_snapshot = build_snapshot(ctx, record) if record['status'] == 'draft' else record.get('snapshot') or {}
    new = indexed_items(current_snapshot)
    counts = dict(added=0, removed=0, revised=0, unchanged=0)
    changes = []
    for item_id in sorted(old.keys() | new.keys()):
        before = business_fields(old[item_id]) if item_id in old else {}
        after = business_fields(new[item_id]) if item_id in new else {}
        if item_id not in old:
            kind = 'added'
        elif item_id not in new:
            kind = 'removed'
        else:
            kind = 'unchanged' if before == after else 'revised'
        counts[kind] += 1
        if kind == 'unchanged':
            continue
        entry = after or before
        fields = []
        if kind == 'revised':
            fields = [{'field': FIELD_NAMES.get(k, k), 'before': before.get(k), 'after': after.get(k)}
                      for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)]
        changes.append({'id': item_id, 'change': kind, 'question': entry.get('question', ''),
                        'versionId': entry.get('versionId'), 'fields': fields})
    quality = []
    if record['kind'] == 'training':
        for key, label in DIMENSIONS.items():
            a, b = dimension_stats(old, key), dimension_stats(new, key)
            delta = round(b['mean'] - a['mean'], 2) if a['n'] and b['n'] else None
            quality.append({'label': label, 'before': a, 'after': b, 'delta': delta})
    def identity(release):
        return {k: release.get(k) for k in ('id', 'title', 'kind', 'version', 'status')}
    return {'previous': identity(previous) if previous else None, 'current': identity(record),
            'beforeCount': len(old), 'afterCount': len(new), 'counts': counts, 'changes': changes,
            'quality': quality, 'experiments': paired_results(ctx, previous, record)}
