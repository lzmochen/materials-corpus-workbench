"""Read drawing text locally with macOS Vision; coordinates use the image's top left."""
import json
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

from core import fail


IMAGE_FORMATS = {'.png', '.jpg', '.jpeg'}
_build_lock = threading.Lock()
_build_dir = None


def _vision_helper():
    global _build_dir
    if sys.platform != 'darwin':
        fail(422, '图纸文字识别需要 macOS Vision，请提供含文本的 PDF 或 UTF-8 文本')
    with _build_lock:
        if _build_dir is None:
            _build_dir = tempfile.TemporaryDirectory(prefix='materials-drawing-ocr-')
        executable = Path(_build_dir.name) / 'drawing-vision'
        if executable.is_file():
            return executable
        compiled = executable.with_suffix('.building')
        source = Path(__file__).with_name('drawing_vision.m')
        command = ['/usr/bin/xcrun', 'clang', '-fobjc-arc', '-framework', 'Foundation',
                   '-framework', 'ImageIO', '-framework', 'CoreGraphics', '-framework', 'Vision',
                   str(source), '-o', str(compiled)]
        try:
            result = subprocess.run(command, capture_output=True, timeout=45)
        except (OSError, subprocess.TimeoutExpired):
            fail(422, '本机 OCR 初始化失败，请检查 macOS 命令行开发工具')
        if result.returncode:
            fail(422, '本机 OCR 初始化失败，请检查 macOS 命令行开发工具及 Vision 框架')
        compiled.replace(executable)
        return executable


def recognize(raw, extension):
    signature = b'\x89PNG\r\n\x1a\n' if extension == '.png' else b'\xff\xd8\xff'
    if not raw.startswith(signature):
        fail(422, '图片内容与扩展名不符，请重新导出 PNG 或 JPEG 原件')
    helper = _vision_helper()
    try:
        result = subprocess.run([str(helper)], input=raw, capture_output=True, timeout=55)
    except subprocess.TimeoutExpired:
        fail(422, '图纸文字识别超时，请分区裁剪原图后重试')
    except OSError:
        fail(422, '本机 Vision 文字识别工具启动失败')
    if result.returncode:
        detail = result.stderr.decode('utf-8', errors='replace').strip().splitlines()
        fail(422, detail[-1][:160] if result.returncode == 1 and detail else '图片解码或本机文字识别失败')
    try:
        lines = json.loads(result.stdout)
    except (ValueError, UnicodeError):
        fail(422, '本机 Vision 文字识别结果读取失败')
    if not lines:
        fail(422, '未识别到图纸文字，请上传文字清晰的原图，或裁剪标题栏和技术要求后重试')
    return sorted(lines, key=lambda line: (line['bbox']['y'], line['bbox']['x']))


def drawing_blocks(raw, extension, fields_for, max_blocks, max_text):
    lines = recognize(raw, extension)
    if len(lines) > max_blocks:
        fail(422, f'图纸文字超过 {max_blocks} 行，请分区裁剪原图后重试')
    blocks = []
    for index, line in enumerate(lines, 1):
        text = line['text'].strip()
        if len(text) > max_text:
            fail(422, f'图纸第 {index} 行文字超过 {max_text} 字符，请分区裁剪后重试')
        blocks.append({'id': f'B{index:04d}', 'location': f'图纸第 {index} 行',
                       'text': text, 'fields': fields_for(text), 'bbox': line['bbox'],
                       'confidence': line['confidence'], 'ocrEngine': 'macOS Vision'})
    return blocks
