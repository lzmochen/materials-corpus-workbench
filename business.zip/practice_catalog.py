"""Move untouched meeting fixtures out of the main catalogue without changing their histories."""

import hashlib
import json
from pathlib import Path
import re

from core import Context, TABLES

TIER = 'archived-practice'
MIGRATION = 'research-replaces-basic-fixtures-v1'
IDENTIFIER = re.compile(r'\b(?:RES|VER|BAT|QA|ANN|EXT|REC|BEN|QST|JOB|PAIR|REV|KNW|EVD|KR|TPL)-[A-F0-9]{9,40}\b')
TIMESTAMP = re.compile(r'\b\d{4}-\d{2}-\d{2}T\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)')
SIGNED_TABLES = ('resources','batches','samples','annotations','extractions','benchmarks','jobs','multimodal_pairs')


def record_signature(record):
    # Identifiers and event times vary by installation. Editorial text, file bytes,
    # anchored evidence, reviews, procedure status, revision count and actors do not.
    text=json.dumps(record,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    text=IDENTIFIER.sub(lambda m:m.group().split('-')[0]+'-ID', text)
    text=TIMESTAMP.sub('event-time',text)
    return hashlib.sha256(text.encode()).hexdigest()


def linked_ids(record):
    return set(IDENTIFIER.findall(json.dumps(record,ensure_ascii=False))) - {record['id']}


def retire_practice(db, fresh_meeting=False):
    db.execute('CREATE TABLE IF NOT EXISTS catalog_migrations (id TEXT PRIMARY KEY)')
    if db.execute('SELECT 1 FROM catalog_migrations WHERE id=?',(MIGRATION,)).fetchone():
        return
    signature_file=Path(__file__).with_name('practice_fingerprints.json')
    reference=json.loads(signature_file.read_text())
    ctx=Context(db,{'username':'catalog-migration','display':'课程目录维护','role':'operator'})
    records={table:ctx.all(table) for table in TABLES}
    signed={table:set(ref.values()) for table,ref in reference['records'].items()}
    for table,values in reference.get('alternateSignatures',{}).items():
        signed.setdefault(table,set()).update(values)
    roots={}
    for record in records['resources']:
        trusted=(record['id'] in reference['resourceIds'] or record.get('seedKey') in reference['seedKeys'] or fresh_meeting)
        if trusted and record_signature(record) in signed.get('resources',{}):
            roots[record['id']]={record['id']}
    # Expand references through batches, samples and work orders; later user-owned
    # work, frozen releases, feedback, and multi-source data also protect their inputs.
    related=[]
    for table in TABLES:
        if table!='resources':
            related.extend((table,r,linked_ids(r)) for r in records[table])
    changed=True
    while changed:
        changed=False
        for _,record,links in related:
            linked=set().union(*(roots[k] for k in links if k in roots))
            old=roots.get(record['id'],set())
            if not linked<=old:
                roots[record['id']]=old|linked
                changed=True
    candidates=[]
    protected=set()
    seen={}
    for table,rows in records.items():
        for record in rows:
            sources=roots.get(record['id'])
            if not sources:
                continue
            sig=record_signature(record)
            expected=reference['publishedSignatures'].get(record['id'])
            exact=json.dumps(record,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
            if sig not in signed.get(table,{}) or (expected and hashlib.sha256(exact).hexdigest()!=expected):
                protected.update(sources)
                continue
            # A visitor can deliberately reproduce an identical task. In ambiguous
            # cases retain both the copy and the source in the main workspace.
            key=(table,sig,tuple(sorted(sources)))
            if key in seen:
                protected.update(sources|seen[key])
            seen[key]=sources
            candidates.append((table,record,sources))
    for table,record,sources in candidates:
        if not sources & protected:
            record['catalogTier']=TIER
            ctx.put(table,record)
    db.execute('INSERT INTO catalog_migrations VALUES (?)',(MIGRATION,))
