"""Version-bound knowledge extraction and training corpus preparation runs."""
from itertools import islice
import re

import luoshu
import production
from core import fail, now

BASE = '/api/pipeline-work'
READERS = ('operator', 'annotator', 'expert', 'lead', 'admin')
RECIPES = {'extract': '知识抽取与问答合成', 'facts': '原文事实合成', 'compare': '定量比较合成'}
EXTRACT_TEMPLATES = ('properties', 'materials', 'process')


def approved_sources(resources):
    return [
        {'resourceId': resource['id'], 'title': resource['title'], 'versionId': v['id'],
         'number': v['number'], 'filename': v['filename'], 'blocks': v['blockCount'],
         'catalogTier':resource.get('catalogTier'), 'researchCase':resource.get('researchCase')}
        for resource in resources if resource['split'] == 'train'
        for v in reversed(resource['versions']) if v['status'] == 'approved' and v.get('blocks')
    ]


def run_state(task, batch):
    if batch:
        return {'queued': 'queued', 'generated': 'quality', 'failed': 'failed', 'reviewed': 'finished'}.get(batch['status'], 'queued')
    if task['counts']['pending']:
        return 'review'
    return 'generation' if task['counts']['approved'] else 'excluded'


def summary(task, batch, source):
    record = task or batch
    return {'id': record['id'], 'title': record['title'], 'sourceTitle': source['title'],
            'resourceId':source['id'], 'researchCase':source.get('researchCase'), 'catalogTier':record.get('catalogTier'),
            'recipe': 'extract' if task else batch['template'], 'state': run_state(task, batch),
            'createdAt': record['createdAt'], 'createdBy': record['createdBy'],
            'updatedAt': max(r.get('updatedAt', r['createdAt']) for r in (task, batch) if r)}


def overview(ctx):
    resources = {item['id']: item for item in ctx.all('resources') if item['split'] == 'train'}
    batches = {b['id']: b for b in ctx.all('batches') if b['resourceId'] in resources}
    runs = [summary(t, batches.get(t.get('batchId')), resources[t['resourceId']])
            for t in ctx.all('extractions') if t['resourceId'] in resources]
    runs.extend(summary(None, b, resources[b['resourceId']]) for b in batches.values()
                if b['template'] in production.GENERATION_TEMPLATES and not b.get('extractionId'))
    runs.sort(key=lambda r: r['updatedAt'], reverse=True)
    return {'runs': runs, 'sources': approved_sources(resources.values())}


def config(ctx, data):
    if not isinstance(data.get('versionId'), str) or not data['versionId'].strip():
        fail(400, '请选择明确的源版本')
    resource, version = production.training_source(ctx, data)
    recipe = production.choice(data, 'recipe', RECIPES)
    template = production.choice(data, 'template', EXTRACT_TEMPLATES, 'properties') if recipe == 'extract' else recipe
    fields = luoshu.template_fields(data, template) if recipe == 'extract' else []
    limit = production.candidate_limit(data) if recipe != 'extract' else None
    return resource, version, recipe, template, fields, limit


def preview(cfg):
    _, version, recipe, template, fields, limit = cfg
    if recipe == 'extract':
        rows = luoshu.extract_records(version['blocks'], fields)
        examples = [{'label': r['subject'] + ' · ' + r['field'], 'answer': r['value'], 'location': r['location']} for r in rows[:3]]
    else:
        stream = production.comparison_candidates if recipe == 'compare' else production.fact_candidates
        rows = list(islice(stream(version['blocks']), limit))
        examples = [{'label': q, 'answer': answer, 'location': '、'.join(b['location'] for b in blocks)}
                    for q, answer, blocks, _ in rows[:3]]
    return {'count': len(rows), 'examples': examples, 'fields': fields, 'sourceBlocks': len(version['blocks'])}


def start(ctx, data):
    ctx.allow(*production.OPERATORS)
    cfg = config(ctx, data)
    resource, version, recipe, template, fields, limit = cfg
    title = production.value(data, 'title', 150)
    params = {'title': title, 'resourceId': resource['id'], 'versionId': version['id'], 'template': template}
    if recipe == 'extract':
        task = luoshu.create(ctx, dict(params, fields=fields))
        return {'id': task['id']}
    for batch in ctx.all('batches'):
        if all(batch.get(k) == v for k, v in params.items()) and batch.get('maxCandidates') == limit:
            return {'id': batch['id']}
    if not preview(cfg)['count']:
        fail(422, '本版本没有匹配的候选，请更换制备方式或源版本')
    result = production.queue_generation(ctx, dict(params, maxCandidates=limit))
    return {'id': result['batch']['id']}


def resolve(ctx, run_id):
    if run_id.startswith('EXT-'):
        task = ctx.require('extractions', run_id)
        batch = ctx.require('batches', task['batchId']) if task.get('batchId') else None
    else:
        task, batch = None, ctx.require('batches', run_id)
        if batch['template'] not in production.GENERATION_TEMPLATES or batch.get('extractionId'):
            fail(404, '该批次不属于此制备路径')
    record = task or batch
    source = ctx.require('resources', record['resourceId'])
    if source['split'] != 'train':
        fail(403, '制备管线仅处理训练分区资料')
    version = production.resolve_version(source, record['versionId'])
    return task, batch, source, version


def detail(ctx, resolved):
    task, batch, source, version = resolved
    result = summary(task, batch, source)
    result.update(source={'id': source['id'], 'title': source['title'], 'versionId': version['id'],
                          'number': version['number'], 'filename': version['filename'], 'sha256': version['sha256'],
                          'blockCount': version['blockCount'], 'status': version['status']},
                  extraction=task, batch=batch, samples=production.get_samples(ctx, batch) if batch else [])
    if batch and batch.get('jobId'):
        job = ctx.get('jobs', batch['jobId'])
        if job:
            result['job'] = {key: job.get(key) for key in ('id', 'status', 'attempts', 'createdAt', 'error')}
    return result


def advance(ctx, resolved, action, data):
    task, batch, _, _ = resolved
    if action == 'review' and task:
        ctx.allow(*luoshu.REVIEWERS)
        record = next((r for r in task['records'] if r['id'] == data.get('recordId')), {})
        target = {'approve': 'approved', 'reject': 'rejected'}.get(data.get('decision'))
        if not target:
            fail(400, '请选择通过或剔除')
        note = production.value(data, 'note', 1200, required=target == 'rejected')
        if (target != record.get('status') or record.get('reviewer') != ctx.user['username']
                or note != record.get('note')):
            luoshu.review(ctx, task, {'recordId': data.get('recordId'), 'decision': data['decision'],
                                      'revision': data.get('revision'), 'note': note})
    elif action == 'generate' and task:
        luoshu.generate(ctx, task, {'revision': data.get('revision')})
    elif action == 'quality' and batch:
        ctx.allow(*production.OPERATORS)
        if batch['status'] != 'reviewed':
            production.batch_quality(ctx, batch)
    elif action == 'retry' and batch and not task:
        ctx.allow(*production.OPERATORS)
        if batch['status'] == 'failed':
            production.training_source(ctx, batch)
            if batch['sampleIds']:
                fail(409, '批次已有产出，请核对批次后重新制备')
            batch.update(status='queued', error='', updatedAt=now(),
                         jobId=ctx.enqueue('generate', {'batchId': batch['id']}))
            ctx.put('batches', batch)
            ctx.audit('重试制备管线', batch['id'], batch['jobId'])
    else:
        fail(405, '此管线不支持该操作')
    return {'id': (task or batch)['id']}


def handle(ctx, method, path, data):
    if path != BASE and not path.startswith(BASE + '/'):
        return None
    ctx.allow(*READERS)
    if path == BASE:
        if method == 'GET':
            return overview(ctx)
        if method == 'POST':
            return start(ctx, data)
    if path == BASE + '/preview' and method == 'POST':
        ctx.allow(*production.OPERATORS)
        return preview(config(ctx, data))
    route = re.fullmatch(r'/(EXT-[A-Za-z0-9-]+|BAT-[A-Za-z0-9-]+)(?:/(review|generate|quality|retry))?', path[len(BASE):])
    if route:
        resolved = resolve(ctx, route[1])
        if method == 'GET' and not route[2]:
            return detail(ctx, resolved)
        if method == 'POST' and route[2]:
            return advance(ctx, resolved, route[2], data)
    fail(405, '请求方法或制备环节无效')
