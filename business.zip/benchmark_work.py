"""Design and prepare evidence-bound benchmark drafts for the existing expert review queue."""
import hashlib
import re
import unicodedata
from collections import Counter
from decimal import Decimal

import expert
import guide_eval
import production
from core import fail, now
from corpus_topics import FAMILIES, TOPICS

TABLE = 'benchmark_blueprints'
BASE = '/api/benchmark-work'
WRITERS = expert.BENCHMARK_EDITORS
DEFAULT = {
    'title': '四门类材料能力评测',
    'objective': '核查模型对材料性能差值、试样处置边界和热分析证据的判读能力。',
    'targets': [
        {'family': FAMILIES[0], 'topic': TOPICS[2], 'quota': 1},
        {'family': FAMILIES[1], 'topic': TOPICS[1], 'quota': 1},
        {'family': FAMILIES[2], 'topic': TOPICS[0], 'quota': 1},
        {'family': FAMILIES[3], 'topic': TOPICS[2], 'quota': 1},
    ],
}
NUMBER = r'[+-]?\d+(?:\.\d+)?'


def cell(record):
    return record['family'], record['topic']


def definition(data):
    targets = []
    for row in expert.entries(data.get('targets'), '配额', 1, 12):
        family, topic, quota = row.get('family'), row.get('topic'), row.get('quota')
        if family not in FAMILIES or topic not in TOPICS or type(quota) is not int or not 1 <= quota <= 50:
            fail(422, '每个配额需选择有效门类、专题，并填写 1–50 的整数题量')
        targets.append({'family': family, 'topic': topic, 'quota': quota})
    if len(set(map(cell, targets))) != len(targets) or sum(row['quota'] for row in targets) > 50:
        fail(422, '同一门类与专题只填一次，每套基准合计不超过 50 题')
    return {'title': expert.field(data, 'title', 120), 'objective': expert.field(data, 'objective', 900),
            'targets': targets}


def stable_id(*parts):
    return hashlib.sha256('\n'.join(parts).encode()).hexdigest()[:22].upper()


def evidence_key(text):
    # Keep decimal separators, inequalities, signs and unit symbols meaningful.
    text = unicodedata.normalize('NFKC', text).replace('−', '-')
    return ''.join(text.split())


def training_index(ctx, except_benchmark=None):
    digests, excerpts = set(), set()
    for resource in ctx.all('resources'):
        if resource.get('split') == 'train':
            for version in resource['versions']:
                digests.update(d for d in (version.get('sha256'), version.get('contentDigest')) if d)
                for block in version.get('blocks', []):
                    content = evidence_key(block['text'])
                    if len(content) >= 18:
                        excerpts.add(content)
    train = {expert.normalized(s['question']) for s in ctx.all('samples') if s['status'] != 'rejected'}
    bank = {expert.normalized(i['question']) for b in ctx.all('benchmarks')
            if b['id'] != except_benchmark for i in b['items']}
    return digests, excerpts, train, bank


def overlap(lookup, version, blocks, question):
    digests, excerpts, train, bank = lookup
    if not version.get('sha256') or not blocks:
        return '缺少来源摘要或证据'
    if version['sha256'] in digests or version.get('contentDigest') in digests:
        return '来源与训练版本重复'
    if any(evidence_key(b['text']) in excerpts for b in blocks):
        return '证据与训练原文重复'
    key = expert.normalized(question)
    if key in train:
        return '题干与训练样本重复'
    if key in bank:
        return '已有基准使用同题'
    return ''


def numeric_items(blocks):
    for _, _, pair, derivation in production.comparison_candidates(blocks):
        label = derivation['label']
        first, second = pair
        left, unit = production.parse_number(first['fields'][label], label)
        right, unit2 = production.parse_number(second['fields'][label], label)
        if not unit or unit != unit2 or left == right:
            continue
        subj1, subj2 = production.row_label(first), production.row_label(second)
        higher = subj1 if left > right else subj2
        other = subj2 if left > right else subj1
        diff = production.formatted_decimal(abs(left - right))
        # The distractor confuses half-range with the requested difference.
        question = f'根据留出试验中{subj1}与{subj2}的{label}原始记录，指出读数较高的一项，并计算两项读数的绝对差。'
        answer = f'{subj1}为 {production.formatted_decimal(left)} {unit}，{subj2}为 {production.formatted_decimal(right)} {unit}。较高的是{higher}，绝对差为 {diff} {unit}。'
        half_range = production.formatted_decimal(abs(left - right) / 2)
        wrong = f'较高的是{other}，两项读数的绝对差为 {half_range} {unit}。'
        rubric = [('试样与比较方向', 4, f'读取两个试样及其对应原值，指出较高的是{higher}。'),
                  ('差值与单位', 6, f'按两条原值相减并取绝对值，结果为 {diff} {unit}。')]
        yield ('定量比较', question, answer, wrong, pair, rubric,
               {'mode': 'numeric', 'expected': float(abs(left - right)), 'tolerance': 0, 'unit': unit})
        mean = (left + right) / 2
        rendered_mean = production.formatted_decimal(mean)
        average_q = f'选取{subj1}与{subj2}的{label}两条记录，求这两个读数的算术平均值，并注明单位。'
        average_a = f'将 {production.formatted_decimal(left)} {unit} 与 {production.formatted_decimal(right)} {unit} 相加后除以 2，这两条记录的均值为 {rendered_mean} {unit}。'
        alternate = left if mean != left else right
        average_wrong = f'直接取单项读数，两条记录的均值为 {production.formatted_decimal(alternate)} {unit}。'
        average_rubric = [('读数与范围', 4, '识别两处原值，仅计算这两条记录的均值。'),
                          ('运算与单位', 6, f'两值相加除以 2，结果为 {rendered_mean} {unit}。')]
        yield ('均值计算', average_q, average_a, average_wrong, pair, average_rubric,
               {'mode': 'numeric', 'expected': float(mean), 'tolerance': 0, 'unit': unit})


def threshold_items(blocks):
    # Accept only an explicit inclusive/exclusive pair with its own decisions and the same threshold.
    rule_re = re.compile(rf'(?P<label>[\u4e00-\u9fff]{{2,10}})不超过\s*(?P<limit>{NUMBER})\s*(?P<unit>%|MPa)\s*的试样(?P<low>放行|接收|复测)\s*[；;，,]\s*高于\s*(?P<limit2>{NUMBER})\s*(?P<unit2>%|MPa)\s*的试样(?:必须|应)?(?P<high>复测|放行|接收)')
    for rule_block in blocks:
        match = rule_re.search(rule_block['text'])
        if not match:
            continue
        label, limit, unit, low, limit2, unit2, high = match.groups()
        if Decimal(limit) != Decimal(limit2) or unit != unit2 or low == high:
            continue
        sample_re = re.compile(rf'试样\s*([A-Za-z0-9][A-Za-z0-9_-]{{0,39}})\s*[：:]\s*{re.escape(label)}\s*({NUMBER})\s*{re.escape(unit)}(?![A-Za-z])')
        for sample in blocks:
            if sample['id'] == rule_block['id']:
                continue
            for name, num in sample_re.findall(sample['text']):
                lower = Decimal(num) <= Decimal(limit)
                right, wrong = (low, high) if lower else (high, low)
                relation = '不超过' if lower else '高于'
                question = f'在本批{label}处置单中，试样 {name} 应采取什么处理？请援引其读数、界限及适用范围。'
                answer = f'{name} 的{label}为 {num} {unit}，{relation} {limit} {unit}。按本批约定应{right}。'
                distractor = f'{name} 的{label}为 {num} {unit}，按本批约定应{wrong}。'
                rubric = [('限值与证据', 4, f'指出记录值 {num} {unit} 和边界 {limit} {unit}。'),
                          ('处置与适用范围', 6, f'仅就本批约定判定{right}，正确处理等号归属。')]
                yield ('规则适用', question, answer, distractor, [rule_block, sample], rubric,
                       {'mode': 'keywords', 'keywords': [name, relation, right], 'forbidden': []})


def concept_items(blocks):
    # Requires both the stated interpretation and an explicitly contrasted observation in this source.
    for finding in blocks:
        summary = re.search(r'(?:本批)?判读摘要[：:]\s*([^。]{4,160}。)(.{4,190}?。)', finding['text'])
        if not summary:
            continue
        for obs in blocks:
            if obs['id'] == finding['id']:
                continue
            contrast = re.search(r'观察对象是([^，。]{2,60})，不是([^，。]{2,60})', obs['text'])
            target = re.search(r'试样\s*([A-Za-z0-9][A-Za-z0-9_-]{0,39})(?![A-Za-z0-9_-])', obs['text'])
            if not contrast or not target:
                continue
            name = target.group(1)
            positive, negative = contrast.groups()
            question = f'试样 {name} 的记录将哪一项作为观察对象？引用判读摘要说明其物理含义和处理方法。'
            answer = f'观察的是{positive}。{summary.group(1)}{summary.group(2)}'
            wrong = f'应以{negative}为观察对象，据此作出判读。'
            rubric = [('观察对象', 4, f'根据观测段指出对象为{positive}。'),
                      ('判读与处理', 6, summary.group(1) + summary.group(2))]
            yield ('概念判读', question, answer, wrong, [obs, finding], rubric,
                   {'mode': 'keywords', 'keywords': [positive, summary.group(1).rstrip('。')], 'forbidden': []})


MAKERS = dict(zip(TOPICS, (concept_items, threshold_items, numeric_items)))


def candidate(resource, version, parts):
    kind, question, answer, wrong, blocks, rubric, rule = parts
    key = stable_id(resource['id'], version['id'], kind, question)
    choices = [answer, wrong] if int(key[-2:], 16) % 2 else [wrong, answer]
    return {
        'id': key, 'kind': kind, 'family': resource['materialFamily'], 'topic': resource['topic'],
        'resourceTitle': resource['title'], 'resourceId': resource['id'], 'versionId': version['id'],
        'question': question, 'answer': answer, 'candidates': [{'answer': c} for c in choices],
        'category': resource['topic'], 'blockIds': [b['id'] for b in blocks],
        'evidence': expert.anchors(version, [b['id'] for b in blocks]),
        'rubric': [{'name': n, 'max': m, 'description': d} for n, m, d in rubric],
        'autoRule': dict(rule, topic=resource['topic']),
    }


def pool(ctx, plan):
    from research_case import holdout_parts
    wanted = {cell(t) for t in plan['targets']}
    lookup = training_index(ctx, plan.get('benchmarkId'))
    rows, exclusions, seen = [], [], set()
    for resource in sorted(ctx.all('resources'), key=lambda r: (r['title'], r['id'])):
        if resource.get('catalogTier') == 'archived-practice' or resource['split'] != 'holdout' or (resource.get('materialFamily'), resource.get('topic')) not in wanted:
            continue
        version = next((v for v in resource['versions'] if v['id'] == resource.get('activeVersion')), {})
        skipped = Counter()
        if version.get('status') != 'approved':
            skipped['当前版本尚未核准'] += 1
        else:
            found = False
            for parts in holdout_parts(resource, version) or MAKERS[resource['topic']](version.get('blocks', [])):
                found = True
                reason = overlap(lookup, version, parts[4], parts[1])
                key = expert.normalized(parts[1])
                if key in seen:
                    reason = '候选题干重复'
                if reason:
                    skipped[reason] += 1
                else:
                    rows.append(candidate(resource, version, parts))
                    seen.add(key)
            if not found:
                skipped['证据不满足该题型的制备条件'] += 1
        exclusions.extend({'source': resource['title'], 'reason': reason, 'count': n} for reason, n in skipped.items())
    return rows, exclusions


def list_summary(ctx, p):
    bench = ctx.get('benchmarks', p.get('benchmarkId', '')) if p.get('benchmarkId') else None
    imported = []
    if bench:
        sources = {r['id']: r for r in ctx.all('resources')}
        for item in bench['items']:
            resource = sources.get(item['resourceId'], {})
            imported.append({'family': resource.get('materialFamily'), 'topic': resource.get('topic'),
                             'versionId': item['versionId']})
    return {**p, 'status': bench['status'] if bench else 'design',
            'questionCount': len(imported), 'imported': imported}


def accessible(ctx):
    return ctx.user['role'] in WRITERS


def details(ctx, p):
    plan = list_summary(ctx, p)
    result = {'plan': plan, 'canEdit': accessible(ctx) and not p.get('benchmarkId')}
    if accessible(ctx) and not p.get('benchmarkId'):
        result['candidates'], result['exclusions'] = pool(ctx, p)
    else:
        result.update(candidates=[], exclusions=[])
    return result


def save(ctx, data, plan=None):
    ctx.allow(*WRITERS)
    spec = definition(data)
    if plan:
        editable(ctx, plan, data)
    else:
        request_key = expert.field(data, 'requestId', 80)
        key = 'BLP-' + stable_id(ctx.user['username'], request_key)
        plan = ctx.get(TABLE, key)
        if plan:
            return details(ctx, plan)
        plan = {'id': key, 'owner': ctx.user['username'], 'createdAt': now(), 'revision': 0}
    plan.update(**spec, revision=plan['revision'] + 1, updatedAt=now())
    ctx.put(TABLE, plan)
    ctx.audit('保存基准蓝图', plan['id'], {'revision': plan['revision'], 'targets': spec['targets']})
    return details(ctx, plan)


def editable(ctx, plan, data):
    ctx.allow(*WRITERS)
    if plan.get('benchmarkId'):
        fail(409, '本蓝图已制备基准，后续请在基准草稿中核对题目')
    if type(data.get('revision')) is not int or data['revision'] != plan['revision']:
        fail(409, '蓝图已更新，请刷新后重新核对配额')


def validate_linked(ctx, bench):
    spec = bench['blueprint']
    totals = Counter()
    lookup = training_index(ctx, bench['id'])
    for item in bench['items']:
        source, version = expert.get_source_version(ctx, item['resourceId'], item['versionId'], 'holdout')
        anchors = expert.anchors(version, item['blockIds'])
        reason = overlap(lookup, version, anchors, item['question'])
        if reason:
            fail(409, f'基准题的隔离核查未通过：{reason}')
        if item['category'] != source.get('topic'):
            fail(409, '题目分类需与蓝图规定的来源专题相符')
        item['materialFamily'] = source.get('materialFamily')
        item['topic'] = source.get('topic')
        totals[(item['materialFamily'], item['topic'])] += 1
    if totals != Counter({cell(t): t['quota'] for t in spec['targets']}):
        fail(409, '基准题的门类与专题分布偏离已定蓝图，请核对实际题目及来源')


def freeze_design_items(benchmark):
    """Keep item defaults separate from per-run rules and personal reviews."""
    items = []
    for item in benchmark['items']:
        entry = {key: item[key] for key in ('id', 'resourceId', 'versionId', 'evidence',
                                           'question', 'answer', 'category', 'rubric')}
        # Final scores are public. Private score sheets, names and free-text opinions stay out.
        entry['result'] = {key: item['result'][key] for key in ('kind', 'scores')}
        entry['candidates'] = [{'label': label, 'answer': row['answer']}
                               for label, row in zip(('A', 'B'), item['candidates'])]
        entry['defaultRule'] = guide_eval.default_rule(item)
        if item.get('preparationKind'):
            entry['questionType'] = item['preparationKind']
        if item.get('materialFamily') in FAMILIES and item.get('topic') in TOPICS:
            entry.update(materialFamily=item['materialFamily'], topic=item['topic'])
        items.append(entry)
    return items


def prepare(ctx, plan, data):
    ctx.allow(*WRITERS)
    ids = data.get('candidateIds')
    if (not isinstance(ids, list) or not 1 <= len(ids) <= 50 or
            not all(isinstance(k, str) for k in ids) or len(set(ids)) != len(ids)):
        fail(422, '请选择 1–50 道不重复的候选题')
    if plan.get('benchmarkId'):
        if set(ids) == set(plan['selectedIds']):
            return details(ctx, plan)
        fail(409, '本蓝图已经组卷，请打开已关联的基准')
    editable(ctx, plan, data)
    candidates, _ = pool(ctx, plan)
    by_id = {c['id']: c for c in candidates}
    if any(key not in by_id for key in ids):
        fail(409, '候选题来源或题库已变化，请重新预览')
    selected = [by_id[key] for key in ids]
    totals = Counter(map(cell, selected))
    if any(totals[cell(t)] != t['quota'] for t in plan['targets']):
        fail(422, '各门类、专题的已选题数须与蓝图配额一致')
    snapshot = {k: plan[k] for k in ('id', 'title', 'objective', 'targets', 'revision')}
    created = expert.start_benchmark(ctx, {'title': plan['title'], 'description': plan['objective']})
    bench = ctx.require('benchmarks', created['id'])
    for c in selected:
        payload = {k: c[k] for k in ('resourceId','versionId','question','answer','category','rubric','blockIds','candidates')}
        expert.set_benchmark_item(ctx, bench, payload)
        bench['items'][-1]['autoRule'] = c['autoRule']
        bench['items'][-1]['preparationKind'] = c['kind']
    bench['blueprint'] = snapshot
    validate_linked(ctx, bench)
    ctx.put('benchmarks', bench)
    plan.update(benchmarkId=bench['id'], selectedIds=ids, updatedAt=now(), revision=plan['revision']+1)
    ctx.put(TABLE, plan)
    ctx.audit('按蓝图制备基准草稿', bench['id'], {'blueprint': plan['id'], 'items': len(selected)})
    return details(ctx, plan)



def handoff_source(ctx, annotation):
    if annotation['status'] != 'approved':
        fail(409, '标注通过专家复核后才能移交评测')
    sample = ctx.require('samples', annotation['sampleId'])
    res, _ = expert.get_source_version(ctx, annotation['resourceId'], annotation['versionId'], 'train')
    if sample.get('status') != 'passed' or any(sample.get(k) != annotation[k] for k in ('resourceId', 'versionId')):
        fail(409, '标注与训练样本的来源或质检状态不一致')
    family = res.get('materialFamily') or res.get('category', '').split('/')[0].strip()
    topic = annotation.get('topic') or res.get('topic') or ''
    if not topic and re.search('差值|绝对差|算术平均', sample['question']):
        topic = '科学计算'
    return dict(annotationId=annotation['id'], sampleId=sample['id'], resourceId=res['id'],
                versionId=annotation['versionId'], resourceTitle=res['title'], question=sample['question'],
                family=family, topic=topic, batchId=sample.get('batchId'), researchCase=res.get('researchCase'))


def handoff_materials(ctx, source):
    """Only expose approved holdouts and candidate questions from their own evidence."""
    from research_case import holdout_parts
    lookup = training_index(ctx)
    materials, options = [], []
    for res in ctx.all('resources'):
        if res.get('catalogTier') == 'archived-practice':
            continue
        if res.get('researchCase') and res['researchCase'] != source.get('researchCase'):
            continue
        if res['split'] != 'holdout' or (source['topic'] and res.get('topic') and res['topic'] != source['topic']):
            continue
        version = next((v for v in res['versions'] if v['id'] == res.get('activeVersion') and v['status'] == 'approved'), None)
        if not version or not version.get('blocks') or not version.get('sha256') or any(
                d and d in lookup[0] for d in (version['sha256'], version.get('contentDigest'))):
            continue
        family = res.get('materialFamily') or res.get('category', '').split('/')[0].strip()
        topics = [res.get('topic') or source.get('topic')] if res.get('topic') or source.get('topic') else TOPICS
        materials.append(dict(id=res['id'], title=res['title'], versionId=version['id'], family=family,
                              topic=res.get('topic') or source['topic'], crossFamily=family != source['family']))
        for topic in topics:
            if topic not in MAKERS:
                continue
            prepared = holdout_parts(res, version)
            for parts in prepared or MAKERS[topic](version['blocks']):
                if overlap(lookup, version, parts[4], parts[1]):
                    continue
                row = candidate(dict(res, materialFamily=family, topic=topic), version, parts)
                row['crossFamily'] = family != source['family']
                row['matchedCase'] = bool(prepared and source.get('researchCase') == res.get('researchCase'))
                options.append(row)
    return sorted(materials, key=lambda r: (r['crossFamily'], r['title'])), sorted(
        options, key=lambda r: (r['crossFamily'], not r['matchedCase'], r['resourceTitle'], r['kind'] != '定量比较', r['kind']))


def validate_handoff(ctx, bench):
    link = bench['handoff']
    source = handoff_source(ctx, ctx.require('annotations', link['annotationId']))
    item = expert.find_item(bench, link['itemId'])
    if any(link[k] != source[k] for k in ('sampleId','resourceId','versionId')) or (
            item['resourceId'], item['versionId']) != (link['holdoutResourceId'], link['holdoutVersionId']):
        fail(409, '移交来源与留出题目的版本不一致')
    lookup = training_index(ctx, bench['id'])
    for row in bench['items']:
        _, version = expert.get_source_version(ctx, row['resourceId'], row['versionId'], 'holdout')
        reason = overlap(lookup, version, expert.anchors(version, row['blockIds']), row['question'])
        if reason:
            fail(409, '留出隔离核查失败：' + reason)


def annotation_handoff(ctx, method, annotation_id, data):
    if method == 'POST':
        ctx.allow(*WRITERS)
    source = handoff_source(ctx, ctx.require('annotations', annotation_id))
    bench = next((b for b in ctx.all('benchmarks') if b.get('handoff', {}).get('annotationId') == annotation_id), None)
    can_prepare = ctx.user['role'] in WRITERS
    def summary(bench):
        return dict(source=source, canPrepare=can_prepare, candidates=[], materials=[], benchmarkId=bench['id'],
                    benchId=bench['id'], title=bench['title'], itemId=bench['handoff']['itemId'], status=bench['status'])
    if bench:
        return summary(bench)
    materials, candidates = handoff_materials(ctx, source) if can_prepare else ([], [])
    if method == 'GET':
        return dict(source=source, canPrepare=can_prepare, candidates=candidates, materials=materials,
                    benchmarkId=None, benchId=None, itemId=None, status='unprepared')
    if data.get('confirmed') is not True:
        fail(422, '请核对留出证据、参考答案、评分标准与两份候选回答')
    manual = data.get('manualItem')
    if manual is not None:
        if not isinstance(manual, dict):
            fail(422, '手工编题内容无效')
        material = next((m for m in materials if m['id'] == manual.get('resourceId') and m['versionId'] == manual.get('versionId')), None)
        if not material:
            fail(409, '请选择当前核准的同专题独立留出版本')
        if source['topic'] and source['topic'] != manual.get('category'):
            fail(422, '评测题专题须与本次训练标注一致')
        if manual.get('category') not in TOPICS:
            fail(422, '请选择有效的评测专题')
        c = dict(manual, family=material['family'], topic=manual['category'], crossFamily=material['crossFamily'],
                 kind='手工编制', resourceTitle=material['title'])
    else:
        c = next((r for r in candidates if r['id'] == data.get('candidateId')), None)
        if not c:
            fail(409, '留出题目已变化，请重新选择')
    transfer_reason = expert.field(data, 'transferReason', 480, bool(c['crossFamily']))
    title = expert.field(data, 'title', 120)
    record = expert.start_benchmark(ctx, dict(title=title, description='训练标注能力验证 · ' + c['topic']))
    bench = ctx.require('benchmarks', record['id'])
    keys = ('resourceId','versionId','question','answer','category','rubric','blockIds','candidates')
    expert.set_benchmark_item(ctx, bench, {k: c.get(k) for k in keys})
    item = bench['items'][0]
    item.update(preparationKind=c['kind'], materialFamily=c['family'], topic=c['topic'])
    if not manual:
        item['autoRule'] = c['autoRule']
    bench['handoff'] = dict(source, itemId=item['id'], holdoutResourceId=c['resourceId'], holdoutVersionId=c['versionId'],
                            holdoutTitle=c['resourceTitle'], targetFamily=c['family'], targetTopic=c['topic'],
                            transferReason=transfer_reason, preparedBy=ctx.user['username'], preparedAt=now())
    validate_handoff(ctx, bench)
    expert.save_event(ctx, 'benchmarks', bench, '标注移交评测', source['annotationId'])
    return summary(bench)

def handle(ctx, method, path, data):
    handoff = re.fullmatch(r'/api/annotations/(ANN-[A-F0-9]+)/benchmark-handoff', path)
    if handoff and method in ('GET', 'POST'):
        return annotation_handoff(ctx, method, handoff[1], data)
    if path == BASE:
        if method == 'GET':
            return {'blueprints': [list_summary(ctx, p) for p in ctx.all(TABLE)],
                    'default': DEFAULT, 'families': FAMILIES, 'topics': TOPICS}
        if method == 'POST':
            return save(ctx, data)
    if path == BASE + '/template' and method == 'GET':
        return details(ctx, dict(DEFAULT, revision=0))
    match = re.fullmatch(r'/api/benchmark-work/(BLP-[A-F0-9]+)(/prepare)?', path)
    if match:
        plan = ctx.require(TABLE, match[1])
        if method == 'GET' and not match[2]:
            return details(ctx, plan)
        if method == 'POST':
            return prepare(ctx, plan, data) if match[2] else save(ctx, data, plan)
    return None
