"""课题一标准制修订和知识产权成果台账。写入由请求事务串行化。"""
import re
import hashlib
import json
from datetime import date, datetime, timedelta, timezone

from core import fail, now

STANDARDS = 'guide_standards'
OUTPUTS = 'guide_outputs'
WRITERS = ('operator', 'lead', 'admin')
LEADS = ('lead', 'admin')
REVIEWERS = ('expert', 'lead', 'admin', 'operator', 'annotator')
KINDS = ('专利', '软件著作权', '其他知识产权')
PREFIX = '/api/guide-registry'
REQUIREMENT = '2026年度第三批申报指南，第7.5节，课题1，第6–8页'
SEED = [
    ('STD-GUIDE-01', '材料语料元数据与原文证据标引规范', '语料标准工作组',
     '覆盖金属、无机非金属、高分子、复合材料的文本、表格与图像语料。',
     '每份资料记录材料门类、专题、来源、使用许可与版本。问答或标注引用文本段、表格行列或图像区域，同时记录源版本。'),
    ('STD-GUIDE-02', '材料基础大模型专题评测与复核规范', '评测基准工作组',
     '适用于基础概念理解、标准技术规则识别和科学计算三类留出评测题。',
     '概念题登记要点，规则题登记条款证据，计算题登记单位与容差。保存逐题自动评测结果、专家意见与基准版本。')
]


def field(data, key, label, maximum=500, optional=False):
    value = data.get(key, '')
    if not isinstance(value, str) or len(value.strip()) > maximum or (not optional and not value.strip()):
        fail(400, f'请填写有效的{label}（最多 {maximum} 字）。')
    return value.strip()


def dated(data, key, label):
    value = field(data, key, label, 10)
    try:
        day = date.fromisoformat(value)
    except ValueError:
        fail(400, f'{label}无效。')
    today = datetime.now(timezone(timedelta(hours=8))).date()
    if day.isoformat() != value or day > today:
        fail(400, f'{label}须为已发生的日期。')
    return value


def choose(data, key, choices, label):
    value = data.get(key)
    if value not in choices:
        fail(400, f'请选择有效的{label}。')
    return value


def standard_fields(data):
    mode = choose(data, 'mode', ('制定', '修订'), '制修订类型')
    return {
        'title': field(data, 'title', '标准名称', 120),
        'mode': mode,
        'supersedes': field(data, 'supersedes', '拟修订标准及版本', 180, optional=mode != '修订'),
        'owner': field(data, 'owner', '牵头单位或工作组', 100),
        'scope': field(data, 'scope', '适用范围', 1000),
        'basis': field(data, 'basis', '编制依据', 1000),
        'clauses': field(data, 'clauses', '条款或主要技术内容', 8000)
    }


def output_fields(data):
    qty = data.get('planned')
    if type(qty) is not int or not 1 <= qty <= 10000:
        fail(400, '计划件数须为 1–10000 的整数。')
    return {
        'title': field(data, 'title', '成果名称', 120),
        'kind': choose(data, 'kind', KINDS, '成果类别'),
        'owner': field(data, 'owner', '约定权利人', 180),
        'basis': field(data, 'basis', '权属约定依据', 1000),
        'planned': qty,
    }


def record_event(ctx, table, rec, action, detail=''):
    rec['revision'] += 1
    rec['updatedAt'] = now()
    rec['history'].append({'revision': rec['revision'], 'at': rec['updatedAt'],
                           'actor': ctx.user.get('display') or ctx.user['username'],
                           'username': ctx.user['username'], 'action': action, 'detail': detail})
    ctx.put(table, rec)
    ctx.audit('guide_registry.' + action, rec['id'], {'revision': rec['revision'], 'detail': detail})
    return rec


def fresh(ctx, table, details, record_id=None, example=False, request_hash=None):
    is_standard = table == STANDARDS
    rec = {
        **details, 'id': record_id or ctx.new_id('STD' if is_standard else 'IPR'), 'revision': 0,
        'history': [], 'example': example,
    }
    if request_hash:
        rec['requestHash'] = request_hash
    if is_standard:
        rec.update(stage='draft', opinions=[], publication=None)
    else:
        rec['registrations'] = []
    return record_event(ctx, table, rec, '录入标准草案' if is_standard else '建立成果计划')


def seed(ctx):
    for rid, title, owner, scope, clauses in SEED:
        if not ctx.get(STANDARDS, rid):
            fresh(ctx, STANDARDS, {'title': title, 'owner': owner, 'mode':'制定', 'supersedes':'',
                  'scope': scope, 'basis': REQUIREMENT + '；本平台材料样本及其加工流程。',
                  'clauses': clauses}, record_id=rid, example=True)


def summary(rec):
    hidden = {'clauses', 'scope', 'basis', 'history', 'opinions', 'registrations', 'requestHash'}
    row = {k:v for k, v in rec.items() if k not in hidden}
    if 'registrations' in rec:
        row['registered'] = len(rec['registrations'])
    return row


def overview(ctx):
    standards = [summary(r) for r in ctx.all(STANDARDS)]
    outputs = [summary(r) for r in ctx.all(OUTPUTS)]
    return {'standards': standards, 'outputs': outputs, 'source': REQUIREMENT,
            'target': 2, 'published': sum(bool(r['publication']) for r in standards),
            'finalized': sum(r['stage'] == 'final' for r in standards),
            'registered': sum(r['registered'] for r in outputs)}


def update_fields(ctx, table, rec, data):
    ctx.allow(*WRITERS)
    if table == STANDARDS:
        if rec['stage'] == 'final':
            fail(409, '内部定稿已锁定，如需修订请另建修订任务。')
        values = standard_fields(data)
    else:
        values = output_fields(data)
        if rec['registrations']:
            if values['kind'] != rec['kind'] or values['owner'] != rec['owner'] or values['basis'] != rec['basis']:
                fail(409, '已有凭证的成果类别、权利人与权属依据已锁定。')
            if values['planned'] < len(rec['registrations']):
                fail(400, '计划件数不能低于已登记凭证件数。')
    changes = {k: {'before':rec[k], 'after':v} for k,v in values.items() if v != rec[k]}
    if not changes:
        return rec
    rec.update(values)
    return record_event(ctx, table, rec, '更新条目', changes)


def standard_action(ctx, rec, action, data):
    stage = rec['stage']
    if action == 'consult':
        ctx.allow(*WRITERS)
        if stage != 'draft':
            fail(409, '仅内部草案可发起征求意见。')
        rec['stage'] = 'consult'
        return record_event(ctx, STANDARDS, rec, '发起征求意见', field(data, 'note', '征求意见范围或对象', 400))
    if action == 'opinion':
        ctx.allow(*REVIEWERS)
        if stage != 'consult':
            fail(409, '当前标准未开放意见征集。')
        note = field(data, 'note', '意见内容', 1000)
        rec['opinions'].append({'id':ctx.new_id('OPN'), 'note':note, 'at':now(),
                                'actor':ctx.user.get('display') or ctx.user['username'], 'resolution':None})
        return record_event(ctx, STANDARDS, rec, '提交意见', note)
    if action == 'resolve':
        ctx.allow(*WRITERS)
        if stage != 'consult':
            fail(409, '当前标准不在意见处理阶段。')
        opinion = next((o for o in rec['opinions'] if o['id'] == data.get('opinionId')), None)
        if not opinion or opinion['resolution']:
            fail(409, '意见不存在或已处理。')
        opinion['resolution'] = {'result':choose(data, 'result', ('采纳', '部分采纳', '不采纳'), '处理结论'),
                                 'note':field(data, 'note', '处理说明', 1000)}
        return record_event(ctx, STANDARDS, rec, '处理征求意见', {**opinion['resolution'], 'opinionId':opinion['id']})
    if action == 'finalize':
        ctx.allow(*LEADS)
        if stage != 'consult' or any(not o['resolution'] for o in rec['opinions']):
            fail(409, '须先发起征求意见并处理所有待办意见。')
        note = field(data, 'note', '定稿依据及意见汇总', 1000)
        rec['stage'] = 'final'
        return record_event(ctx, STANDARDS, rec, '内部定稿', note)
    if action == 'publish':
        ctx.allow(*LEADS)
        if stage != 'final' or rec['publication']:
            fail(409, '须从未登记发布的内部定稿录入发布凭证。')
        publication = {'number':field(data, 'number', '正式标准编号和年度', 120),
                       'issuer':field(data, 'issuer', '发布机构', 180),
                       'date':dated(data, 'date', '发布日期'),
                       'evidence':field(data, 'evidence', '发布公告网址或档案号', 500)}
        unique_number(ctx, STANDARDS, publication['number'])
        rec['publication'] = publication
        return record_event(ctx, STANDARDS, rec, '登记发布凭证', publication)
    return None


def unique_number(ctx, table, number):
    def normalized(s):
        return ''.join(s.split()).casefold()
    for other in ctx.all(table):
        proofs = ([other.get('publication')] if table == STANDARDS else other['registrations'])
        if any(p and normalized(p['number']) == normalized(number) for p in proofs):
            fail(409, '同一编号的凭证已登记。')


def register_output(ctx, rec, data):
    ctx.allow(*WRITERS)
    if len(rec['registrations']) >= rec['planned']:
        fail(409, '已达到计划件数，如需新增请先调整计划。')
    entry = {'number':field(data, 'number', '授权或登记编号', 120),
             'date':dated(data, 'date', '授权或登记日期'),
             'owner':field(data, 'owner', '凭证权利人', 180),
             'evidence':field(data, 'evidence', '证书档案号或公告网址', 500)}
    if entry['owner'] != rec['owner']:
        fail(400, '凭证权利人须与成果计划约定一致。')
    unique_number(ctx, OUTPUTS, entry['number'])
    rec['registrations'].append(entry)
    return record_event(ctx, OUTPUTS, rec, '登记成果凭证', entry)


def handle(ctx, method, path, data):
    if path == PREFIX and method == 'GET':
        return overview(ctx)
    match = re.fullmatch(PREFIX + r'/(standards|outputs)(?:/([A-Z0-9-]+)(?:/([a-z]+))?)?', path)
    if not match:
        return None
    collection, record_id, action = match.groups()
    table = STANDARDS if collection == 'standards' else OUTPUTS
    if not record_id:
        if method != 'POST':
            return None
        ctx.allow(*WRITERS)
        values = standard_fields(data) if table == STANDARDS else output_fields(data)
        key = data.get('requestId')
        if key is None:
            return fresh(ctx, table, values)
        if not isinstance(key, str) or not re.fullmatch(r'[a-zA-Z0-9-]{16,80}', key):
            fail(400, '创建请求标识无效。')
        digest = hashlib.sha256(f"{ctx.user['username']}|{key}".encode()).hexdigest().upper()
        rid = ('STD-' if table == STANDARDS else 'IPR-') + digest[:24]
        content = json.dumps(values, sort_keys=True, ensure_ascii=False).encode()
        request_hash = hashlib.sha256(content).hexdigest()
        existing = ctx.get(table, rid)
        if existing:
            if existing.get('requestHash') != request_hash:
                fail(409, '该次创建已完成，请返回台账查看或编辑。')
            return existing
        return fresh(ctx, table, values, rid, request_hash=request_hash)
    rec = ctx.require(table, record_id)
    if method == 'GET' and not action:
        return rec
    if method != 'POST':
        return None
    if type(data.get('revision')) is not int or data['revision'] != rec['revision']:
        fail(409, '记录已更新，请重新打开后再提交。')
    if not action:
        return update_fields(ctx, table, rec, data)
    if table == STANDARDS:
        return standard_action(ctx, rec, action, data)
    if action == 'register':
        return register_output(ctx, rec, data)
    return None
