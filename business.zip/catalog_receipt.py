"""Collection receipts and evidence-preserving, version-scoped normalized records."""
import base64
import hashlib
import json
import re

from core import fail
import production

VERSION_URL = re.compile(r'/api/resources/([\w-]+)/versions/([\w-]+)/(catalog-receipt|normalized-export)')
CHANNELS = {'file': '文件上传', 'text': '原文录入', 'batch': '批量采集', 'api': '接口接入', 'tool': '科研工具登记'}


def clean_text(value):
    return '\n'.join(line.strip(' \t\u00a0\u3000') for line in value.replace('\r\n', '\n').replace('\r', '\n').split('\n')).strip()


def normalized(version):
    for block in version.get('blocks', []):
        fields = {}
        for key, value in (block.get('fields') or {}).items():
            key = clean_text(key)
            if key in fields:
                # Preserve the original column names when normalization would collapse distinct columns.
                fields = dict(block['fields'])
                break
            fields[key] = clean_text(value) if isinstance(value, str) else value
        text = clean_text(block['text'])
        yield {'blockId': block['id'], 'location': block['location'], 'text': text, 'fields': fields,
               **{k: block[k] for k in ('bbox', 'confidence', 'ocrEngine') if k in block}}


def frozen_assets(ctx, resource, version):
    sql = """SELECT r.id, json_extract(r.payload,'$.title') title, json_extract(r.payload,'$.version') version,
             json_extract(r.payload,'$.kind') kind, json_extract(r.payload,'$.publishedAt') publishedAt,
             COUNT(*) itemCount FROM releases r, json_each(r.payload,'$.snapshot.items') i
             WHERE json_extract(r.payload,'$.status')='published' AND json_extract(i.value,'$.resourceId')=?
               AND json_extract(i.value,'$.versionId')=?
             GROUP BY r.id ORDER BY publishedAt DESC,r.id"""
    return [dict(row) for row in ctx.db.execute(sql, (resource['id'], version['id']))]


def input_history(ctx, version):
    sql = """SELECT b.id,j.key+1 AS number,json_extract(j.value,'$.status') status
             FROM intake_batches b,json_each(b.payload,'$.rows') j
             WHERE json_extract(j.value,'$.versionId')=? ORDER BY b.rowid"""
    return [dict(row) for row in ctx.db.execute(sql, (version['id'],))]


def collect_records(ctx, data):
    ctx.allow(*production.OPERATORS)
    key = production.value(data, 'requestId', 80)
    meta = production.resource_metadata(data, require_license=True)
    records = data.get('records')
    if not isinstance(records, list) or not 1 <= len(records) <= production.MAX_BLOCKS:
        fail(400, 'records 应包含 1–2000 条结构化记录')
    if any(not isinstance(row, dict) or not row or len(row) > 80 or
           any(not k.strip() for k in row) for row in records):
        fail(400, '每条记录需要 1–80 个具名字段')
    try:
        raw = ('\n'.join(json.dumps(row, ensure_ascii=False, allow_nan=False,
                                   separators=(',', ':')) for row in records)+'\n').encode('utf-8')
    except (ValueError, UnicodeError, RecursionError):
        fail(400, '记录中存在无法写入 JSONL 的值')
    if len(raw) > production.MAX_FILE_BYTES:
        fail(413, '接口记录超过 8 MiB，请分批提交')
    # Parse before registering the receipt so a malformed payload can be corrected and retried.
    for _ in production.structured_jsonl(raw.decode('utf-8')):
        pass
    filename = '接口记录.jsonl'
    digest = hashlib.sha256(raw).hexdigest()
    fields = {k: meta.get(k,'') for k in production.INTAKE_FIELD_LIMITS}
    batch = production.create_intake(ctx, {'requestId': key, 'rows': [dict(fields, filename=filename)]})
    row = production.register_intake_row(ctx, batch, 1, {
        **fields, 'filename': filename, 'fileSize': len(raw), 'contentBase64': base64.b64encode(raw).decode('ascii')
    }, channel='api')
    if row['status'] not in production.INTAKE_TERMINAL:
        fail(409, row.get('message') or '接口记录未登记')
    return {'receiptId': batch['id'], 'resourceId': row['resourceId'], 'versionId': row['versionId'],
            'sha256': digest, 'recordCount': len(records), 'status': row['status']}


def handle(ctx, method, path, data):
    if path == '/api/catalog-intake':
        if method != 'POST':
            fail(405, '请用 POST 提交采集报文')
        return collect_records(ctx, data)
    match = VERSION_URL.fullmatch(path)
    if not match:
        return None
    resource = ctx.require('resources', match[1])
    production.resource_access(ctx, resource)
    version = production.resolve_version(resource, match[2])
    operator = ctx.user['role'] in production.OPERATORS
    if match[3] == 'normalized-export':
        if method != 'POST':
            fail(405, '请用 POST 导出规范化记录')
        ctx.allow(*production.OPERATORS)
        if version['status'] != 'approved':
            fail(409, '请先核准该原文版本')
        prefix = {'resourceId': resource['id'], 'versionId': version['id'], 'source': resource['source'],
                  'sha256': version['sha256'], 'normalization': 'source-evidence-v1'}
        text = '\n'.join(json.dumps({**prefix, **row}, ensure_ascii=False) for row in normalized(version))
        ctx.audit('导出规范化原文', resource['id'], version['id'])
        return {'filename': f"{resource['id']}-v{version['number']}-规范化.jsonl", 'content': text+'\n' if text else ''}
    if method != 'GET':
        fail(405, '该版本采集记录仅可查询')
    history = input_history(ctx, version) if operator else []
    channel = CHANNELS.get(version.get('inputChannel'))
    if not channel and any(row['status'] == 'registered' for row in history):
        channel = CHANNELS['batch']
    rows = list(normalized(version))
    return {'resourceId': resource['id'], 'versionId': version['id'], 'channel': channel or '历史记录未注明',
            'batches': history, 'releases': frozen_assets(ctx, resource, version),
            'canExport': operator and version['status'] == 'approved',
            'normalized': {'rule': 'source-evidence-v1', 'total': len(rows),
                           'fields': len({k for row in rows for k in row['fields']}),
                           'located': sum(bool(row['location']) for row in rows),
                           'sample':rows[:5]}}
