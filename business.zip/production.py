"""Local corpus ingestion, evidence extraction, sample production and quality control."""
import base64
import binascii
import csv
import hashlib
import io
import json
import re
import shutil
import subprocess
import unicodedata
import zipfile
from decimal import Decimal
from pathlib import Path
from xml.etree import ElementTree

from core import ApiError, fail, now
from drawing_ocr import IMAGE_FORMATS, drawing_blocks


MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_BLOCKS = 2000
MAX_BLOCK_TEXT = 1800
MAX_CANDIDATES = 200
SUPPORTED = {'.pdf', '.docx', '.txt', '.md', '.csv', '.tsv', '.jsonl'} | IMAGE_FORMATS
OPERATORS = ('operator', 'lead', 'admin')
PARSERS = ('auto', 'materials', 'text')
GENERATION_TEMPLATES = ('facts', 'compare')
MATERIAL_LABEL = re.compile(r'牌号|材质|成分|组织|淬火|回火|热处理|硬度|强度|延伸率|保温|温度|性能|模量|试样|样品|冲击功|hardness|strength|elongation|temperature|material|sample', re.I)
MEASUREMENT_LABEL = re.compile(r'硬度|强度|延伸率|冲击功|模量|韧性|伸长率|密度|导电率|hardness|strength|elongation|modulus|density|conductivity', re.I)
NUMERIC = re.compile(r'^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d{1,2})?)\s*([%°℃℉/A-Za-z·²³0-9]*)$')
DIMENSIONS = ('accuracy', 'completeness', 'consistency', 'diversity', 'format', 'traceability')


def value(data, name, limit, required=True):
    supplied = data.get(name, '')
    if supplied is None:
        supplied = ''
    if not isinstance(supplied, str):
        fail(400, f'{name} 应为文本')
    supplied = supplied.strip()
    if required and not supplied:
        fail(400, f'请填写 {name}')
    if len(supplied) > limit:
        fail(400, f'{name} 超过 {limit} 字符')
    return supplied


def choice(data, name, options, default=None):
    selected = data.get(name, default)
    if selected not in options:
        fail(400, f'{name} 参数无效')
    return selected


def candidate_limit(data, default=40):
    selected = data.get('maxCandidates', default)
    if not isinstance(selected, int) or isinstance(selected, bool) or not 1 <= selected <= MAX_CANDIDATES:
        fail(400, f'maxCandidates 应为 1–{MAX_CANDIDATES} 之间的整数')
    return selected


def upload(data, formats):
    filename = value(data, 'filename', 180)
    if '/' in filename or '\\' in filename or any(ord(char) < 32 for char in filename):
        fail(400, '文件名包含无效字符')
    ext = Path(filename).suffix.lower()
    if ext not in formats:
        fail(400, '支持的文件格式为 ' + '、'.join(sorted(formats)))
    encoded = data.get('contentBase64')
    if not isinstance(encoded, str) or not encoded:
        fail(400, '请选择要上传的文件')
    if len(encoded) > 4 * ((MAX_FILE_BYTES + 2) // 3):
        fail(413, '文件超过 8 MiB')
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        fail(400, '文件内容编码无效')
    if not raw:
        fail(400, '文件为空')
    if len(raw) > MAX_FILE_BYTES:
        fail(413, '文件超过 8 MiB')
    return filename, raw


def resolve_version(resource, version_id=None):
    target = version_id or resource['activeVersion']
    result = next((item for item in resource['versions'] if item['id'] == target), None)
    if result is None:
        fail(404, '资源版本不存在')
    return result


def resource_access(ctx, resource):
    if resource['split'] == 'holdout':
        ctx.allow('operator', 'expert', 'lead', 'admin')


def check_split_conflict(ctx, field, digest, split, resource_id, version_id=None):
    for existing in ctx.all('resources'):
        for version in existing['versions']:
            if digest != version.get(field) or version['id'] == version_id:
                continue
            if existing['split'] != split:
                fail(409, '文件内容与另一数据分区中的资源相同，训练与评测留出须独立')
            if existing['id'] == resource_id and field == 'sha256':
                fail(409, '本资源已入库相同文件，无需重复追加版本')


def new_version(ctx, resource, filename, raw):
    digest = hashlib.sha256(raw).hexdigest()
    check_split_conflict(ctx, 'sha256', digest, resource['split'], resource['id'])
    stamp = now()
    version = {
        'id': ctx.new_id('VER'), 'number': len(resource['versions']) + 1, 'filename': filename,
        'sha256': ctx.store_blob(raw), 'size': len(raw), 'status': 'registered',
        'createdAt': stamp, 'createdBy': ctx.user['username'], 'blocks': [], 'blockCount': 0,
    }
    resource['versions'].append(version)
    resource['activeVersion'] = version['id']
    update_resource(ctx, resource, version, 'registered')
    return version


def update_resource(ctx, resource, version, status):
    stamp = now()
    version.update(status=status, updatedAt=stamp)
    resource['updatedAt'] = stamp
    if resource['activeVersion'] == version['id']:
        resource['status'] = status
    ctx.put('resources', resource)


def resource_summaries(ctx):
    return [dict(item, versions=[{key: val for key, val in version.items() if key not in ('blocks', 'contentDigest')} for version in item['versions']])
            for item in ctx.all('resources')]


def searchable(text):
    return unicodedata.normalize('NFKC', str(text)).casefold().replace('−', '-').replace('‑', '-')


def evidence_search(ctx, data):
    ctx.allow('operator', 'annotator', 'expert', 'lead', 'admin')
    terms = list(dict.fromkeys(searchable(value(data, 'query', 100)).split()))
    if not terms or len(terms) > 8:
        fail(400, '每次最多查找八个条件')
    split = choice(data, 'split', ('all', 'train', 'holdout'), 'all')
    if ctx.user['role'] == 'annotator':
        if split == 'holdout':
            fail(403, '当前岗位仅可检索训练资源')
        split = 'train'
    scope = choice(data, 'versions', ('current', 'approved'), 'current')
    offset = data.get('offset', 0)
    if type(offset) is not int or offset < 0 or offset > 1_000_000:
        fail(400, '结果起始位置无效')
    rows = ctx.db.execute('''
        SELECT r.id, json_extract(r.payload,'$.title') title, json_extract(r.payload,'$.split') split,
               json_extract(r.payload,'$.activeVersion') active_id, json_extract(v.value,'$.id') version_id,
               json_extract(v.value,'$.number') number, json_extract(b.value,'$.id') block_id,
               json_extract(b.value,'$.location') location, json_extract(b.value,'$.text') body,
               json_extract(b.value,'$.fields') fields
          FROM resources r, json_each(r.payload,'$.versions') v, json_each(v.value,'$.blocks') b
         WHERE json_extract(v.value,'$.status') = 'approved'
           AND (? = 'all' OR json_extract(r.payload,'$.split') = ?)
           AND (? = 'approved' OR json_extract(r.payload,'$.activeVersion') = json_extract(v.value,'$.id'))
         ORDER BY r.rowid DESC, CAST(v.key AS INTEGER) DESC, CAST(b.key AS INTEGER)
    ''', (split, split, scope))
    hits, total = [], 0
    # Qualified codes are token matches: MT-A2 must not select the distinct specimen MT-A20.
    patterns = []
    for term in terms:
        left = r'(?<![a-z0-9])' if re.match('[a-z0-9]', term[0]) else ''
        right = r'(?![a-z0-9])' if re.match('[a-z0-9]', term[-1]) else ''
        if term[0].isdigit():
            left = r'(?<![a-z0-9.+-])'
        if term[-1].isdigit():
            right = r'(?![a-z0-9]|\.\d)'
        patterns.append(re.compile(left + re.escape(term) + right))
    for row in rows:
        text = (row['body'] or '').strip()
        if not text or not row['block_id']:
            continue
        original = searchable(text)
        searchable_fields = []
        for key, val in (json.loads(row['fields']) if row['fields'] else {}).items():
            label = searchable(key)
            reading = searchable(val).strip()
            searchable_fields.append(label + ' ' + reading)
            # Table headers carry units, while cells carry the numerical readings.
            unit = re.search(r'\(([^()]{1,24})\)\s*$', label)
            if unit and re.fullmatch(r'[+-]?(?:\d+\.?\d*|\.\d+)', reading):
                searchable_fields.extend((reading + unit[1], label[:unit.start()] + reading + unit[1]))
        fields = '\n'.join(searchable_fields)
        matches = [pattern.search(original) for pattern in patterns]
        if not all(match or pattern.search(fields) for pattern, match in zip(patterns, matches)):
            continue
        if offset <= total < offset + 12:
            at = min((m.start() for m in matches if m), default=0)
            start = max(0, min(at - 40, len(text) - 180))
            excerpt = ('…' if start else '') + text[start:start+180] + ('…' if len(text) > start+180 else '')
            hits.append({'resourceId':row['id'], 'title':row['title'], 'split':row['split'],
                         'versionId':row['version_id'], 'version':row['number'],
                         'current':row['active_id'] == row['version_id'], 'blockId':row['block_id'],
                         'location':row['location'], 'excerpt':excerpt})
        total += 1
    return {'rows':hits, 'total':total, 'offset':offset, 'pageSize':12}


def resource_metadata(data, require_license=False):
    from corpus_topics import catalog_fields
    return {
        'title': value(data, 'title', 180), 'category': value(data, 'category', 100),
        'source': value(data, 'source', 180), 'license': value(data, 'license', 180, require_license),
        'notes': value(data, 'notes', 1000, False), 'split': choice(data, 'split', ('train', 'holdout')),
        **catalog_fields(data)
    }


def store_resource(ctx, metadata, filename, raw):
    record = dict(metadata, id=ctx.new_id('RES'), versions=[], createdAt=now(), createdBy=ctx.user['username'])
    version = new_version(ctx, record, filename, raw)
    ctx.audit('登记资源', record['id'], f'{version["id"]} · {record["split"]} · {filename}')
    return record


def register_resource(ctx, data):
    ctx.allow(*OPERATORS)
    filename, raw = upload(data, SUPPORTED)
    return store_resource(ctx, resource_metadata(data), filename, raw)


INTAKE_FIELD_LIMITS = {'title':180, 'category':100, 'source':180, 'license':180,
                       'split':10, 'materialFamily':32, 'topic':32}
INTAKE_TERMINAL = ('registered', 'reused')


def intake_fields(row):
    return {key:value(row, key, limit, False) for key, limit in INTAKE_FIELD_LIMITS.items()}


def intake_summary(batch):
    return {**{key:batch[key] for key in ('id', 'createdAt', 'createdBy', 'updatedAt')},
            'total':len(batch['rows']),
            'counts':{status:sum(row['status'] == status for row in batch['rows'])
                      for status in ('pending', 'registered', 'reused', 'failed')}}


def create_intake(ctx, data):
    token = value(data, 'requestId', 80)
    if not re.fullmatch(r'[A-Za-z0-9_-]{12,80}', token):
        fail(400, '采集请求标识无效')
    incoming = data.get('rows')
    if not isinstance(incoming, list) or not 1 <= len(incoming) <= 50:
        fail(400, '每份清单可登记 1 至 50 个文件')
    rows = []
    for i, item in enumerate(incoming, start=1):
        if not isinstance(item, dict):
            fail(400, '采集清单格式无效')
        rows.append({'number':i, 'filename':value(item, 'filename', 180), 'fields':intake_fields(item),
                     'status':'pending', 'message':''})
    key = 'IN-' + hashlib.sha256(f'{ctx.user["username"]}/{token}'.encode()).hexdigest()[:20].upper()
    fingerprint = hashlib.sha256(json.dumps(rows, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    existing = ctx.get('intake_batches', key)
    if existing:
        if existing['manifestDigest'] != fingerprint:
            fail(409, '该请求已保存另一份清单，请重新创建采集批次')
        return existing
    batch = {'id':key, 'rows':rows, 'createdBy':ctx.user['username'], 'createdAt':now(),
             'updatedAt':now(), 'manifestDigest':fingerprint}
    ctx.put('intake_batches', batch)
    ctx.audit('建立采集清单', key, f'{len(rows)} 份文件')
    return batch


def intake_file_match(ctx, metadata, digest):
    match = None
    for resource in ctx.all('resources'):
        for version in resource['versions']:
            if version['sha256'] != digest:
                continue
            if resource['split'] != metadata['split']:
                fail(409, '原文件已存在于另一数据分区，训练与评测留出须独立')
            if resource['source'] == metadata['source'] and resource.get('license','') == metadata['license']:
                match = (resource, version)
            elif match is None:
                match = False
    if match is False:
        fail(409, '相同原文件已有其他来源或使用许可，请核对登记信息')
    return match


def register_intake_row(ctx, batch, number, data):
    if not 1 <= number <= len(batch['rows']):
        fail(404, '采集清单行不存在')
    row = batch['rows'][number - 1]
    complete = row['status'] in INTAKE_TERMINAL
    try:
        fields = intake_fields(data)
        if not complete:
            row['fields'] = fields
        if data.get('filename') != row['filename']:
            fail(409, '所选文件名称与清单不符')
        if data.get('fileSize') == 0:
            fail(422, '文件为空')
        if isinstance(data.get('fileSize'), int) and data['fileSize'] > MAX_FILE_BYTES:
            fail(413, '单文件不能超过 8 MiB')
        filename, raw = upload(data, SUPPORTED)
        for field, label in [('title','资源名称'), ('category','材料子类'), ('source','资料来源'), ('license','权属或使用许可')]:
            if not fields[field]:
                fail(422, '请填写' + label)
        metadata = resource_metadata(fields, require_license=True)
        digest = hashlib.sha256(raw).hexdigest()
        if complete:
            if row['sha256'] != digest or fields != row['fields']:
                fail(409, '该行已完成，不能更换文件或修改其登记信息')
            return row
        match = intake_file_match(ctx, metadata, digest)
        if match:
            resource, version = match
            row.update(status='reused', message='同分区原件已归档，已关联现有版本')
        else:
            resource = store_resource(ctx, metadata, filename, raw)
            version = resolve_version(resource)
            row.update(status='registered', message='原件已入库')
        row.update(resourceId=resource['id'], versionId=version['id'], sha256=digest)
    except ApiError as exc:
        if complete:
            raise
        row.update(status='failed', message=str(exc))
    row['updatedAt'] = batch['updatedAt'] = now()
    ctx.put('intake_batches', batch)
    ctx.audit('采集逐件登记', batch['id'], f'{number} · {row["filename"]} · {row["message"]} · {row.get("resourceId","")}')
    return row


def intake_route(ctx, method, path, data):
    ctx.allow(*OPERATORS)
    if path == '/api/intake-batches':
        if method == 'GET':
            return [intake_summary(batch) for batch in ctx.all('intake_batches')]
        if method == 'POST':
            return create_intake(ctx, data)
    match = re.fullmatch(r'/api/intake-batches/(IN-[0-9A-F]{20})(?:/rows/([1-9][0-9]?))?', path)
    if match:
        batch = ctx.require('intake_batches', match[1])
        if method == 'GET' and not match[2]:
            return batch
        if method == 'POST' and match[2]:
            return register_intake_row(ctx, batch, int(match[2]), data)
    fail(404, '采集接口不存在')


def queue_parse(ctx, resource, data):
    ctx.allow(*OPERATORS)
    version = resolve_version(resource, data.get('versionId'))
    if version['status'] not in ('registered', 'parsed', 'failed'):
        fail(409, '当前版本无法解析。已核准版本可保留，使用新版本继续加工')
    template = choice(data, 'template', PARSERS, 'auto')
    job_id = ctx.enqueue('parse', {'resourceId': resource['id'], 'versionId': version['id'], 'template': template})
    version.update(jobId=job_id, template=template, error='', blocks=[], blockCount=0)
    version.pop('contentDigest', None)
    update_resource(ctx, resource, version, 'parsing')
    ctx.audit('提交解析任务', resource['id'], f'{job_id} · {version["id"]}')
    return {'jobId': job_id, 'resource': resource}


def approve_resource(ctx, resource, data):
    ctx.allow(*OPERATORS)
    version = resolve_version(resource, value(data, 'versionId', 80))
    if version['status'] != 'parsed' or not version['blocks']:
        fail(409, '请在复核可用证据后核准已解析版本')
    check_split_conflict(ctx, 'contentDigest', version['contentDigest'], resource['split'], resource['id'], version['id'])
    note = value(data, 'note', 1000, False)
    version.update(approval={'note': note, 'by': ctx.user['username'], 'at': now()})
    update_resource(ctx, resource, version, 'approved')
    ctx.audit('核准源文档证据', resource['id'], f'{version["id"]} · {note}')
    return resource


def read_text(raw):
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        fail(422, '文本文件需要 UTF-8 编码')


def parse_table(rows, location):
    first_line, header = next(rows, (0, []))
    names = [col.strip() for col in header]
    if not names or any(not name for name in names) or len(set(names)) != len(names) or len(names) > 80:
        fail(422, f'{location(first_line)}表头应包含 1–80 个互不重复的字段名')
    for line, cells in rows:
        if len(cells) != len(names):
            fail(422, f'{location(line)}列数与表头不一致')
        fields = {key: val.strip() for key, val in zip(names, cells) if val.strip()}
        if fields:
            text = ' | '.join(f'{key}：{val}' for key, val in fields.items())
            if len(text) > MAX_BLOCK_TEXT:
                fail(422, f'{location(line)}字段总文本超过 {MAX_BLOCK_TEXT} 字符，请拆成多行')
            yield location(line), text, fields


def delimited_rows(text, delimiter):
    stream = csv.reader(io.StringIO(text, newline=''), delimiter=delimiter, strict=True)
    try:
        for row in stream:
            if any(cell.strip() for cell in row):
                yield stream.line_num, row
    except csv.Error as error:
        fail(422, f'表格第 {stream.line_num} 行格式错误（{error}）')


def jsonl_rows(text):
    for line_number, row in enumerate(text.splitlines(), 1):
        if not row.strip():
            continue
        try:
            obj = json.loads(row)
        except (ValueError, RecursionError):
            fail(422, f'JSONL 第 {line_number} 行格式错误')
        if not isinstance(obj, dict) or not obj or len(obj) > 80:
            fail(422, f'JSONL 第 {line_number} 行需要含 1–80 个字段的 JSON 对象')
        try:
            json.dumps(obj, ensure_ascii=False, allow_nan=False).encode('utf-8')
        except (ValueError, UnicodeError, RecursionError):
            fail(422, f'JSONL 第 {line_number} 行包含无法入库的文本或非有限数值')
        yield line_number, obj


def structured_jsonl(text):
    for number, obj in jsonl_rows(text):
        fields = {key: val if isinstance(val, str) else json.dumps(val, ensure_ascii=False) for key, val in obj.items()}
        block = ' | '.join(f'{key}：{val}' for key, val in fields.items())
        if len(block) > MAX_BLOCK_TEXT:
            fail(422, f'JSONL 第 {number} 行超过 {MAX_BLOCK_TEXT} 字符，请拆行')
        yield f'JSONL 第 {number} 行', block, fields


def pdf_content(raw):
    program = shutil.which('pdftotext')
    if not program:
        fail(422, '当前主机缺少 Poppler pdftotext。可先转换为 UTF-8 文本或 CSV 再入库')
    try:
        result = subprocess.run([program, '-layout', '-enc', 'UTF-8', '-', '-'], input=raw,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=35, check=False)
    except subprocess.TimeoutExpired:
        fail(422, 'PDF 解析超时，请拆分后重试')
    if result.returncode:
        fail(422, 'PDF 读取失败。请检查文件是否损坏或受密码保护')
    if len(result.stdout) > 4 * MAX_FILE_BYTES:
        fail(422, 'PDF 文本体积超过解析上限，请拆分后重试')
    return read_text(result.stdout)


def fields_in_text(text):
    fields = {}
    for occurrence in re.finditer(r'(?:^|[\n|；;，,])\s*([^：:=\n|；;,，]{1,32})\s*[：:=]\s*([^\n|；;,，]{1,240})', text):
        key, val = (part.strip() for part in occurrence.groups())
        if MATERIAL_LABEL.search(key) and val:
            fields[key] = val
    return fields


def text_blocks(text, location, template):
    lines = text.splitlines()
    buffer = []
    start = 1
    for number, line in enumerate(lines, 1):
        piece = line.strip()
        if not piece or (buffer and sum(len(val) + 1 for val in buffer) + len(piece) > MAX_BLOCK_TEXT):
            if buffer:
                block = '\n'.join(buffer)
                yield location(start, number - 1), block, fields_in_text(block) if template != 'text' else {}
                buffer = []
        if not piece:
            continue
        if len(piece) > MAX_BLOCK_TEXT:
            for index in range(0, len(piece), MAX_BLOCK_TEXT):
                part = piece[index:index + MAX_BLOCK_TEXT]
                yield location(number, number) + f' 片段 {index // MAX_BLOCK_TEXT + 1}', part, fields_in_text(part) if template != 'text' else {}
            continue
        if not buffer:
            start = number
        buffer.append(piece)
    if buffer:
        block = '\n'.join(buffer)
        yield location(start, len(lines)), block, fields_in_text(block) if template != 'text' else {}


def docx_blocks(raw, template):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            entry = archive.getinfo('word/document.xml')
            if entry.file_size > MAX_FILE_BYTES:
                fail(422, 'DOCX 正文超过解析上限')
            document = ElementTree.fromstring(archive.read(entry))
    except (KeyError, zipfile.BadZipFile, ElementTree.ParseError, RuntimeError):
        fail(422, 'DOCX 正文读取失败')
    ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    body = document.find(ns + 'body')
    if body is None:
        fail(422, 'DOCX 缺少正文')
    paragraph_no = table_no = 0
    for item in body:
        if item.tag == ns + 'p':
            paragraph_no += 1
            text = ''.join(child.text or '' for child in item.iter(ns + 't'))
            yield from text_blocks(text, lambda start, end: f'DOCX 正文第 {paragraph_no} 段', template)
        elif item.tag == ns + 'tbl':
            table_no += 1
            rows = []
            for tr in item.findall(ns + 'tr'):
                rows.append([' '.join(child.text or '' for child in cell.iter(ns + 't')).strip()
                             for cell in tr.findall(ns + 'tc')])
            regular = len(rows) > 1 and all(rows[0]) and len(set(rows[0])) == len(rows[0]) and all(len(row) == len(rows[0]) for row in rows)
            if regular and template != 'text':
                yield from parse_table(iter(enumerate(rows, 1)), lambda n: f'DOCX 表 {table_no} 第 {n} 行')
            else:
                for number, row in enumerate(rows, 1):
                    yield from text_blocks(' | '.join(row), lambda start, end: f'DOCX 表 {table_no} 第 {number} 行', template)


def extract_version(raw, filename, template):
    ext = Path(filename).suffix.lower()
    if ext in IMAGE_FORMATS:
        fields_for = fields_in_text if template != 'text' else lambda text: {}
        return drawing_blocks(raw, ext, fields_for, MAX_BLOCKS, MAX_BLOCK_TEXT)
    if ext == '.pdf':
        text = pdf_content(raw)
        def blocks():
            for page, body in enumerate(text.split('\f'), 1):
                yield from text_blocks(body, lambda start, end: f'第 {page} 页，第 {start}–{end} 行', template)
        stream = blocks()
    elif ext == '.docx':
        stream = docx_blocks(raw, template)
    elif ext in ('.csv', '.tsv'):
        stream = parse_table(delimited_rows(read_text(raw), '\t' if ext == '.tsv' else ','), lambda line: f'表格第 {line} 行')
    elif ext == '.jsonl':
        stream = structured_jsonl(read_text(raw))
    else:
        stream = text_blocks(read_text(raw), lambda start, end: f'第 {start}–{end} 行', template)
    blocks = []
    for index, (location, text, fields) in enumerate(stream, 1):
        if index > MAX_BLOCKS:
            fail(422, f'证据块超过 {MAX_BLOCKS} 条，请拆分文件后重试')
        blocks.append({'id': f'B{index:04d}', 'text': text, 'location': location, 'fields': fields})
    if not blocks:
        fail(422, '未提取到有效文本。扫描版 PDF 需先完成 OCR')
    return blocks


def canon(text):
    normalized = unicodedata.normalize('NFKC', text).casefold()
    return ''.join(char for char in normalized if char.isalnum())


def run_parse(ctx, payload):
    resource = ctx.require('resources', payload['resourceId'])
    version = resolve_version(resource, payload['versionId'])
    if version['status'] != 'parsing':
        fail(409, '源文档状态已变更，请重新提交解析任务')
    raw = ctx.read_blob(version['sha256'])
    blocks = extract_version(raw, version['filename'], payload['template'])
    normalized_text = unicodedata.normalize('NFKC', '\n'.join(block['text'] for block in blocks)).casefold()
    digest = hashlib.sha256(''.join(normalized_text.split()).encode('utf-8')).hexdigest()
    check_split_conflict(ctx, 'contentDigest', digest, resource['split'], resource['id'], version['id'])
    version.update(blocks=blocks, contentDigest=digest, blockCount=len(blocks))
    update_resource(ctx, resource, version, 'parsed')
    ctx.audit('解析证据完成', resource['id'], f'{version["id"]} · {len(blocks)} 个证据块')
    return {'resourceId': resource['id'], 'versionId': version['id'], 'blockCount': len(blocks)}


def training_source(ctx, data):
    resource = ctx.require('resources', value(data, 'resourceId', 80))
    if resource['split'] != 'train':
        fail(409, '评测留出资源不能用于生成或导入训练数据')
    version = resolve_version(resource, data.get('versionId'))
    if version['status'] != 'approved':
        fail(409, '训练任务须绑定已核准的资源版本')
    return resource, version


def new_batch(ctx, data, resource, version, mode, template, limit):
    return {
        'id': ctx.new_id('BAT'), 'title': value(data, 'title', 180), 'resourceId': resource['id'],
        'versionId': version['id'], 'template': template, 'mode': mode, 'maxCandidates': limit, 'status': 'queued',
        'sampleIds': [], 'counts': {'candidate': 0, 'passed': 0, 'rejected': 0},
        'createdBy': ctx.user['username'], 'createdAt': now(),
    }


def queue_generation(ctx, data):
    ctx.allow(*OPERATORS)
    resource, version = training_source(ctx, data)
    template = choice(data, 'template', GENERATION_TEMPLATES, 'facts')
    batch = new_batch(ctx, data, resource, version, 'local', template, candidate_limit(data))
    batch['jobId'] = ctx.enqueue('generate', {'batchId': batch['id']})
    ctx.put('batches', batch)
    ctx.audit('提交训练样本生成', batch['id'], f'{resource["id"]} · {version["id"]} · {template}')
    return {'batch': batch, 'jobId': batch['jobId']}


def evidence_for(blocks):
    return [{'blockId': item['id'], 'location': item['location'], 'text': item['text']} for item in blocks]


def save_candidate(ctx, batch, question, answer, blocks, rule=None, teacher=None):
    sample = {
        'id': ctx.new_id('QA'), 'batchId': batch['id'], 'resourceId': batch['resourceId'],
        'versionId': batch['versionId'], 'question': question, 'answer': answer,
        'evidence': evidence_for(blocks), 'status': 'candidate', 'quality': None,
        'mode': batch['mode'], 'createdAt': now(),
    }
    if rule is not None:
        sample['rule'] = rule
    if teacher is not None:
        sample['teacher'] = teacher
    ctx.put('samples', sample)
    batch['sampleIds'].append(sample['id'])
    return sample


def write_batch(ctx, batch, samples, status=None):
    if status is not None:
        batch['status'] = status
    batch['counts'] = {choice: sum(sample['status'] == choice for sample in samples)
                       for choice in ('candidate', 'passed', 'rejected')}
    batch['updatedAt'] = now()
    ctx.put('batches', batch)


def get_samples(ctx, batch):
    return [ctx.require('samples', sample_id) for sample_id in batch['sampleIds']]


def row_label(block):
    for name, value_ in block.get('fields', {}).items():
        if re.search(r'试样|样品|编号|\bsample\b|^id$|^材料$', name, re.I) and len(value_) <= 80:
            return f'“{value_}”（{block["location"]}）'
    return block['location']


def parse_number(text, label):
    result = NUMERIC.fullmatch(unicodedata.normalize('NFKC', text.strip()))
    if not result:
        return None
    number, unit = result.groups()
    if not unit:
        header_units = re.search(r'[（(]([^（）()]{1,16})[）)]\s*$', label)
        unit = header_units.group(1) if header_units else ''
    decimal = Decimal(number)
    if abs(decimal.adjusted()) > 12 or len(decimal.as_tuple().digits) > 20:
        return None
    return decimal, unit


def formatted_decimal(number):
    result = format(number, 'f')
    return result.rstrip('0').rstrip('.') if '.' in result else result


def compare_readings(first, second, label):
    left_value = parse_number(first.get('fields', {}).get(label, ''), label)
    right_value = parse_number(second.get('fields', {}).get(label, ''), label)
    if left_value is None or right_value is None or left_value[1].casefold() != right_value[1].casefold():
        return None
    unit = ' ' + left_value[1] if left_value[1] else ''
    left, right = left_value[0], right_value[0]
    difference = formatted_decimal(abs(left - right))
    if left == right:
        result = f'两组读数相等，差值为 {difference}{unit}。'
    else:
        which = '第一处' if left > right else '第二处'
        result = f'{which}读数较高，差值为 {difference}{unit}。'
    return f'第一处为 {formatted_decimal(left)}{unit}，第二处为 {formatted_decimal(right)}{unit}。{result}结论限于所引用的两条记录。'


def comparison_candidates(blocks):
    previous = {}
    for block in blocks:
        for label, text in block.get('fields', {}).items():
            if not MEASUREMENT_LABEL.search(label) or parse_number(text, label) is None:
                continue
            if label in previous:
                first = previous[label]
                answer = compare_readings(first, block, label)
                if answer is not None:
                    question = f'比较{row_label(first)}与{row_label(block)}的{label}。哪一处读数较高，绝对差值是多少？'
                    yield question, answer, [first, block], {'type': 'compare', 'label': label}
            previous[label] = block


def fact_candidates(blocks):
    for block in blocks:
        fields = block.get('fields') or {}
        if fields:
            for label, captured in fields.items():
                if len(label) <= 80 and not re.fullmatch(r'试样|样品|编号|sample|id', label, re.I):
                    yield f'{row_label(block)}记录的{label}是什么？', captured, [block], {'type': 'field', 'label': label}
        else:
            leading = next(part for part in block['text'].splitlines() if part.strip())[:24]
            yield f'在{block["location"]}，以“{leading}”开头的证据段记载了什么？', block['text'], [block], {'type': 'quote'}


def run_generation(ctx, payload):
    batch = ctx.require('batches', payload['batchId'])
    if batch['status'] != 'queued':
        fail(409, '此批次已处理或状态已改变')
    _, version = training_source(ctx, batch)
    stream = comparison_candidates(version['blocks']) if batch['template'] == 'compare' else fact_candidates(version['blocks'])
    candidates = []
    for question, answer, blocks, rule in stream:
        candidates.append(save_candidate(ctx, batch, question, answer, blocks, rule=rule))
        if len(candidates) == batch['maxCandidates']:
            break
    if not candidates:
        if batch['template'] == 'compare':
            fail(422, '未找到单位一致的两条可比较性能读数。可尝试事实摘取模板，或核查源表性能字段')
        fail(422, '该版本没有可生成样本的有效证据')
    write_batch(ctx, batch, candidates, 'generated')
    ctx.audit('生成证据化候选样本', batch['id'], f'{len(candidates)} 条 · 本地规则')
    return {'batchId': batch['id'], 'sampleCount': len(candidates)}


def import_teacher(ctx, data):
    ctx.allow(*OPERATORS)
    resource, version = training_source(ctx, data)
    filename, raw = upload(data, {'.jsonl'})
    limit = candidate_limit(data, MAX_CANDIDATES)
    batch = new_batch(ctx, data, resource, version, 'teacher', 'teacher-import', limit)
    batch['jobId'] = None
    batch['sourceFile'] = filename
    batch['sourceHash'] = hashlib.sha256(raw).hexdigest()
    by_id = {block['id']: block for block in version['blocks']}
    parsed = []
    for line, item in jsonl_rows(read_text(raw)):
        if len(parsed) >= limit:
            fail(422, f'教师输出超过当前批次上限 {limit} 条，请拆批导入')
        block_ids = item.get('blockIds')
        valid_ids = isinstance(block_ids, list) and 1 <= len(block_ids) <= 12 and all(isinstance(block_id, str) and block_id in by_id for block_id in block_ids)
        if not valid_ids or len(set(block_ids)) != len(block_ids):
            fail(422, f'教师输出第 {line} 行 blockIds 须为本版本内 1–12 个互不重复的证据块编号')
        question = item.get('question')
        answer = item.get('answer')
        teacher = item.get('teacher', '')
        if not isinstance(question, str) or not 1 <= len(question.strip()) <= 400:
            fail(422, f'教师输出第 {line} 行 question 须为 1–400 字符的文本')
        if not isinstance(answer, str) or not 1 <= len(answer.strip()) <= 2000:
            fail(422, f'教师输出第 {line} 行 answer 须为 1–2000 字符的文本')
        if not isinstance(teacher, str) or len(teacher.strip()) > 160:
            fail(422, f'教师输出第 {line} 行 teacher 须为不超过 160 字符的来源标记')
        parsed.append((question.strip(), answer.strip(), [by_id[block_id] for block_id in block_ids], teacher.strip() or '外部教师输出'))
    if not parsed:
        fail(422, '教师输出文件中没有可导入的记录')
    candidates = [save_candidate(ctx, batch, question, answer, blocks, teacher=teacher)
                  for question, answer, blocks, teacher in parsed]
    write_batch(ctx, batch, candidates, 'generated')
    ctx.audit('导入教师候选样本', batch['id'], f'{len(candidates)} 条 · {filename}')
    return {'batch': batch, 'jobId': None}


def evidence_blocks(sample, resource, target_version):
    if resource['split'] != 'train' or target_version['id'] != sample['versionId'] or target_version['status'] != 'approved':
        return []
    by_id = {block['id']: block for block in target_version['blocks']}
    citations = sample['evidence']
    linked = [by_id.get(item['blockId']) for item in citations]
    if not linked or any(block is None for block in linked) or evidence_for(linked) != citations:
        return []
    return linked


def expected_answer(sample, blocks):
    if not blocks:
        return None
    rule = sample.get('rule', {})
    if rule.get('type') == 'extract-span':
        from luoshu import expected_span
        return expected_span(rule, blocks)
    if rule.get('type') == 'evidence-fields':
        if rule.get('blockIds') != [block['id'] for block in blocks]:
            return None
        values = [block.get('fields', {}).get(rule.get('label')) for block in blocks]
        return ''.join(values) if all(isinstance(item, str) and item for item in values) else None
    if rule.get('type') == 'quote':
        return blocks[0]['text']
    if rule.get('type') == 'field':
        return blocks[0].get('fields', {}).get(rule['label'])
    if rule.get('type') == 'compare' and len(blocks) == 2:
        return compare_readings(blocks[0], blocks[1], rule['label'])
    return None


def sample_key(sample):
    return canon(sample['question']), canon(sample['answer'])


def duplicate_lookup(ctx, batch_id):
    return {sample_key(sample): sample['id'] for sample in ctx.all('samples')
            if sample['status'] == 'passed' and sample['batchId'] != batch_id}


def inspect_sample(sample, resource, version, duplicate_of):
    grounded = evidence_blocks(sample, resource, version)
    complete = bool(sample['question'].strip() and sample['answer'].strip() and sample['evidence'])
    correctly_formatted = 1 <= len(sample['question']) <= 400 and 1 <= len(sample['answer']) <= 2000
    teacher = sample['mode'] == 'teacher'
    actual = expected_answer(sample, grounded)
    accurate = sample['answer'] == actual if not teacher else None
    dimension_vals = (accurate, complete, bool(grounded and (teacher or accurate)), not duplicate_of, correctly_formatted, bool(grounded))
    dimensions = {name: 100 if flag else None if flag is None else 0 for name, flag in zip(DIMENSIONS, dimension_vals)}
    checks = [score for score in dimensions.values() if score is not None]
    issues = []
    if not grounded:
        issues.append('证据块、原文或资源版本无法复核')
    if not complete:
        issues.append('问题、答案或引用证据不完整')
    if not correctly_formatted:
        issues.append('问答长度不符合训练格式')
    if not teacher and not accurate:
        issues.append('答案与已核准证据或重算结果不一致')
    if duplicate_of:
        issues.append(f'问答在规范化后重复，重合样本 {duplicate_of}')
    if teacher and not issues:
        issues.append('已核对证据位置与格式，语义准确性待专家确认')
    return {'score': round(sum(checks) / len(checks)), 'dimensions': dimensions, 'issues': issues,
            'eligible': all(flag for flag in dimension_vals if flag is not None), 'duplicateOf': duplicate_of,
            'requiresExpert': teacher, 'checkedAt': now()}


def batch_quality(ctx, batch):
    ctx.allow(*OPERATORS)
    if batch['status'] not in ('generated', 'reviewed'):
        fail(409, '批次候选准备完成后才能质检')
    resource, version = training_source(ctx, batch)
    samples = get_samples(ctx, batch)
    seen = duplicate_lookup(ctx, batch['id'])
    for sample in samples:
        prior = seen.get(sample_key(sample))
        if sample.get('review'):
            if sample['status'] == 'passed':
                seen[sample_key(sample)] = sample['id']
            continue
        quality = inspect_sample(sample, resource, version, prior)
        sample['quality'] = quality
        sample['status'] = ('candidate' if quality['requiresExpert'] else 'passed') if quality['eligible'] else 'rejected'
        if quality['eligible']:
            seen[sample_key(sample)] = sample['id']
        ctx.put('samples', sample)
    write_batch(ctx, batch, samples, 'reviewed')
    ctx.audit('批次质检', batch['id'], f'{batch["counts"]["passed"]} 通过 · {batch["counts"]["candidate"]} 待复核 · {batch["counts"]["rejected"]} 剔除')
    return {'batch': batch, 'samples': samples}


def review_sample(ctx, sample, data):
    if sample['mode'] == 'teacher':
        ctx.allow('expert', 'lead', 'admin')
    else:
        ctx.allow(*OPERATORS)
    batch = ctx.require('batches', sample['batchId'])
    if batch['status'] != 'reviewed':
        fail(409, '请先执行批次质检')
    note = value(data, 'note', 1200)
    decision = choice(data, 'decision', ('pass', 'reject'))
    if sample.get('review'):
        fail(409, '该样本已有人工质检结论。可使用新批次重新加工')
    samples = get_samples(ctx, batch)
    if decision == 'pass':
        if not sample.get('quality', {}).get('eligible'):
            fail(409, '样本存在结构、证据或重复问题，无法通过')
        duplicate = any(item['id'] != sample['id'] and item['status'] == 'passed' and sample_key(item) == sample_key(sample)
                        for item in ctx.all('samples'))
        if duplicate:
            fail(409, '同一问答已在另一条样本中通过，无法重复纳入')
    elif any(item.get('sampleId') == sample['id'] for item in ctx.all('annotations')):
        fail(409, '样本已用于标注，当前批次不能撤回。请使用新版本纠正')
    sample['status'] = 'passed' if decision == 'pass' else 'rejected'
    sample['review'] = {'decision': decision, 'note': note, 'by': ctx.user['username'], 'at': now()}
    ctx.put('samples', sample)
    updated = [sample if item['id'] == sample['id'] else item for item in samples]
    write_batch(ctx, batch, updated)
    ctx.audit('人工样本复核', sample['id'], f'{decision} · {note}')
    return sample


def export_batch(ctx, batch):
    ctx.allow('operator', 'annotator', 'lead', 'admin')
    samples = [item for item in get_samples(ctx, batch) if item['status'] == 'passed']
    if not samples:
        fail(409, '当前批次尚无通过质检的样本')
    output = []
    for item in samples:
        output.append(json.dumps({
            'id': item['id'], 'messages': [{'role': 'user', 'content': item['question']}, {'role': 'assistant', 'content': item['answer']}],
            'metadata': {'batchId': batch['id'], 'resourceId': item['resourceId'], 'versionId': item['versionId'],
                         'evidence': item['evidence'], 'quality': item['quality'], 'mode': item['mode'],
                         'review': item.get('review'), 'teacher': item.get('teacher')},
        }, ensure_ascii=False))
    ctx.audit('导出训练样本', batch['id'], f'{len(output)} 条 · JSONL')
    return {'filename': f'{batch["id"]}-training.jsonl', 'content': '\n'.join(output) + '\n'}


def run_job(ctx, kind, payload):
    if kind == 'parse':
        return run_parse(ctx, payload)
    if kind == 'generate':
        return run_generation(ctx, payload)
    fail(400, '不可识别的生产任务类型')


def job_failure(ctx, kind, payload, message):
    if kind == 'parse':
        resource = ctx.get('resources', payload['resourceId'])
        if resource is None:
            return
        version = resolve_version(resource, payload['versionId'])
        if version['status'] == 'parsing':
            version['error'] = message
            update_resource(ctx, resource, version, 'failed')
            ctx.audit('源文档解析失败', resource['id'], f'{version["id"]} · {message}')
    elif kind == 'generate':
        batch = ctx.get('batches', payload['batchId'])
        if batch is not None and batch['status'] == 'queued':
            batch.update(status='failed', updatedAt=now(), error=message)
            ctx.put('batches', batch)
            ctx.audit('训练样本生成失败', batch['id'], message)


def handle(ctx, method, path, data):
    if path == '/api/evidence-search':
        if method != 'POST':
            fail(405, '请求方法不支持')
        return evidence_search(ctx, data)
    if path == '/api/intake-batches' or path.startswith('/api/intake-batches/'):
        return intake_route(ctx, method, path, data)
    if path == '/api/resources':
        if method == 'GET':
            return resource_summaries(ctx)
        if method == 'POST':
            return register_resource(ctx, data)
        fail(405, '请求方法不支持')
    resource_route = re.fullmatch(r'/api/resources/([A-Za-z0-9-]+)(?:/(parse|approve|versions)(?:/([A-Za-z0-9-]+)/file)?)?', path)
    if resource_route:
        resource_id, action, version_id = resource_route.groups()
        resource = ctx.require('resources', resource_id)
        resource_access(ctx, resource)
        if method == 'GET' and action is None:
            return resource
        if method == 'GET' and action == 'versions' and version_id:
            version = resolve_version(resource, version_id)
            raw = ctx.read_blob(version['sha256'])
            ctx.audit('下载源文档', resource['id'], version['id'])
            return {'filename': version['filename'], 'contentBase64': base64.b64encode(raw).decode('ascii'), 'sha256': version['sha256']}
        if method == 'POST' and version_id is None:
            if action == 'versions':
                ctx.allow(*OPERATORS)
                version = new_version(ctx, resource, *upload(data, SUPPORTED))
                ctx.audit('追加资源版本', resource_id, f'{version["id"]} · {version["filename"]}')
                return resource
            if action == 'parse':
                return queue_parse(ctx, resource, data)
            if action == 'approve':
                return approve_resource(ctx, resource, data)
        fail(405, '请求方法不支持')
    if path == '/api/batches':
        if method == 'GET':
            return ctx.all('batches')
        if method == 'POST':
            return queue_generation(ctx, data)
        fail(405, '请求方法不支持')
    if path == '/api/batches/teacher-import':
        if method != 'POST':
            fail(405, '请求方法不支持')
        return import_teacher(ctx, data)
    batch_route = re.fullmatch(r'/api/batches/([A-Za-z0-9-]+)(?:/(quality|export))?', path)
    if batch_route:
        batch_id, action = batch_route.groups()
        batch = ctx.require('batches', batch_id)
        if method == 'GET' and action is None:
            return batch
        if method == 'GET' and action == 'export':
            return export_batch(ctx, batch)
        if method == 'POST' and action == 'quality':
            return batch_quality(ctx, batch)
        fail(405, '请求方法不支持')
    if path == '/api/samples':
        if method == 'GET':
            return ctx.all('samples')
        fail(405, '请求方法不支持')
    sample_route = re.fullmatch(r'/api/samples/([A-Za-z0-9-]+)(/review)?', path)
    if sample_route:
        sample = ctx.require('samples', sample_route[1])
        if method == 'GET' and not sample_route[2]:
            return sample
        if method == 'POST' and sample_route[2]:
            return review_sample(ctx, sample, data)
        fail(405, '请求方法不支持')
    return None
