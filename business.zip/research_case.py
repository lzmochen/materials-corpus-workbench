"""A versioned research exercise based on cited facts, provisioned only in meeting workspaces."""
import base64
import hashlib
import json

from core import Context, fail, now
import expert
import production

CASE = 'dual-phase-annealing-v1'
TRAIN = 'research-dp1000-annealing-v1'
HOLDOUT = 'research-dp1500-holdout-v1'
CONTEXT = 'research-ustb-multiphase-context-v1'
CONTEXT_TITLE = '低碳多相钢 · 成分与热处理对照'
CONTEXT_DOI = '10.13374/j.issn1001-053x.2013.05.007'
CONTEXT_URL = 'https://cje.ustb.edu.cn/cn/article/pdf/preview/'+CONTEXT_DOI+'.pdf'
CONTEXT_ROWS = [
    ('表1', '成分对照', '两组试验钢的碳质量分数分别为 0.22% 和 0.17%。'),
    ('摘要、第1.2节及图1', '试验设计', '两种成分分别采用 T1 和 T2 热处理。比较两种钢时，成分和工艺均随组别改变。'),
    ('摘要及组织分析', '组织与比较边界', '两种终态组织分别以针状和块状铁素体为基体。编者判断：这组对照不足以单独估计碳含量或热处理路线的效应。'),
    ('文献标识', '来源及整理范围', '任勇强、谢振家、尚成嘉，北京科技大学材料科学与工程学院，《低碳多相钢的组织调控与力学性能》，2013。DOI '+CONTEXT_DOI+'。本表为研究设计对照资料。')
]
TRAIN_TITLE = 'DP1000 镀锌双相钢退火组织与拉伸性能'
HOLDOUT_TITLE = 'DP1500 双相钢退火温度与强度响应'
TRAIN_DOI = '10.13374/j.issn1001-053x.2009.10.018'
HOLDOUT_DOI = '10.13258/j.cnki.nmme.20230408001'
TRAIN_URL = 'https://cje.ustb.edu.cn/cn/article/pdf/preview/10.13374/j.issn1001-053x.2009.10.018.pdf'
HOLDOUT_URL = 'https://snm.usst.edu.cn/html/2024/4/shysjs20230408001.htm'
QUESTION = '这项研究在什么退火条件下获得了怎样的组织和拉伸性能？其单一退火工况能否证明提高温度会使抗拉强度单调增加？'
TRAIN_ROWS = [
    ('图1及实验材料与方法', '工艺条件', '试验钢在 820 ℃ 保温 80 s，随后进入模拟热镀锌工序。'),
    ('图2及第2.1节', '组织观察', '作者观察到铁素体基体中分布着岛状马氏体。'),
    ('表2', '拉伸指标', '该制度下屈服强度 Re 为 598 MPa，抗拉强度 Rm 为 1022 MPa，伸长率 A50 为 9.5%。'),
    ('图1与表2的工况对应关系', '证据边界（编者判断）', '这组性能只对应一个退火温度，缺少同钢种在其他退火温度下的对照，不能据此判定强度随退火温度单调增加。'),
    ('文献标识', '来源及整理范围', '金光灿等，《1000 MPa热镀锌双相钢组织和断裂机理》，2009。DOI '+TRAIN_DOI+'。本表为编者按图表位置另行整理的事实卡。')
]
HOLDOUT_ROWS = [
    ('第1.3节、图2／图3', '对照条件', '两组钢均选 80 s 退火保温；比较的均为 240 ℃ 过时效、保温 280 s 的记录。'),
    ('表3，DP00', '抗拉强度 Rm', 'DP00 在 825 ℃ 和 850 ℃ 的 Rm 依次为 1491.6 MPa 和 1496.5 MPa。'),
    ('表3，DP03', '抗拉强度 Rm', 'DP03 在 825 ℃ 和 850 ℃ 的 Rm 依次为 1563.6 MPa 和 1537.6 MPa。'),
    ('表3所列钢号与工况', '证据边界（编者判断）', '温度响应应在同一钢号内比较。仅凭这四个观测值不能分离 Nb 的独立因果作用。'),
    ('文献标识', '来源及整理范围', '马快、李伟、马凤仓、张柯，《1500双相钢的微观组织及力学性能研究》，2024。DOI '+HOLDOUT_DOI+'。本表由编者按原论文实验条件及表3另行整理。')
]
HOLDOUT_QUESTION = '在两种钢均退火保温 80 s、过时效制度相同的条件下，退火温度从 825 ℃ 提高到 850 ℃ 时，DP00 与 DP03 的抗拉强度各如何变化？这能否支持两种钢具有相同升温趋势，或把差异单独归因于 Nb？'


CRYSTAL = 'sic-solvent-growth-v1'
CRYSTAL_TRAIN = 'research-sic-solubility-v1'
CRYSTAL_HOLDOUT = 'research-sic-growth-v1'
CRYSTAL_TRAIN_TITLE = 'Si–Cr 助溶剂的碳溶解度与热力学计算'
CRYSTAL_HOLDOUT_TITLE = '富 Cr 助溶剂中 4H-SiC 的生长与夹杂'
CRYSTAL_QUESTION = 'Si–Cr 助溶剂中，哪些碳溶解度证据来自实验，哪些结果来自热力学计算？过饱和区能否直接确定 SiC 的最高生长速率或最佳晶体质量？'
CRYSTAL_TRAIN_DOI = '10.1021/acs.cgd.5c01649'
CRYSTAL_HOLDOUT_DOI = '10.1016/j.jcrysgro.2020.125877'
CRYSTAL_TRAIN_ROWS = [
    ('研究摘要 · 试样与检测','实验观测','研究者使用两类坩埚制样，考察碳源的影响，并以化学成分分析测得若干 Si–Cr 配比下的碳溶解度。'),
    ('研究摘要 · 三元液相','模型拟合','实测数据用于调整 Si–Cr–C 三元液相相互作用参数，进而计算溶剂的热力学性质。'),
    ('研究摘要 · 计算域','变量与范围','Si₁₋ₓCrₓ 的计算覆盖 x 从 0 到 1、温度 1700 至 1850 ℃，研究给出较宽的高过饱和区。'),
    ('研究摘要 · 测量与计算的范围','证据边界（编者判断）','计算域内各点并非都经实测。单凭高过饱和区不能确定最高生长速率或最佳晶体质量，还需对应工况的生长和质量实测。'),
    ('文献标识','来源及整理范围','Zihai Li 等，郭中楠、袁文霞共同通讯。Crystal Growth & Design，2026，26，1840–1846。DOI '+CRYSTAL_TRAIN_DOI+'。本卡依据期刊公开摘要编写。')
]
CRYSTAL_HOLDOUT_ROWS = [
    ('研究摘要 · 同温对照','组成口径','在 1933 K 比较两种富 Cr 助溶剂；Cr–27.5 mol% Si 与 Cr–45 mol% Si 中的百分数均指 Si 的摩尔分数。'),
    ('研究摘要 · 生长实验','生长速率','在上述温度下，27.5 mol% Si 对应 1220 μm/h，45 mol% Si 对应 1310 μm/h。'),
    ('研究摘要 · 晶体观察','夹杂观察','使用 27.5 mol% Si 助溶剂所得晶体中，3C-SiC 夹杂比使用 45 mol% Si 时更少。'),
    ('研究摘要 · 指标对照','证据边界（编者判断）','此处生长较快的组别与夹杂较少的组别不同。两组实验只用于考查指标权衡，不能直接检验另一篇论文热力学模型的精度。'),
    ('文献标识','来源及整理范围','Sakiko Kawanishi 等，Journal of Crystal Growth，2020，549，125877。DOI '+CRYSTAL_HOLDOUT_DOI+'。本卡按独立研究的公开摘要整理。')
]


def record_bytes(rows):
    return ('原文定位\t证据项\t记录\n'+''.join('\t'.join(row)+'\n' for row in rows)).encode()


def register_card(ctx, key, title, split, rows, doi, url, citation, *, case=CASE, family='金属材料', category='双相钢'):
    raw = record_bytes(rows)
    resource = production.register_resource(ctx, {
        'title': title, 'filename': title+'.tsv', 'contentBase64': base64.b64encode(raw).decode('ascii'),
        'category':category, 'materialFamily':family, 'topic':'科学计算', 'split':split,
        'source':citation, 'license':'自写事实卡供课程与研究讨论使用，论文图表和全文版权归原权利人。',
        'notes':'本资源按所列文献位置整理数值及观察，以“编者判断”标明适用边界。原文 DOI '+doi+'。'
    })
    resource.update(seedKey=key, researchCase=case, provenance='public',
                    sourceLinks=[{'name':'期刊原文','url':url}], sourceDoi=doi)
    ctx.put('resources', resource)
    queued=production.queue_parse(ctx, resource, {'versionId':resource['activeVersion'], 'template':'auto'})
    job=ctx.require('jobs',queued['jobId'])
    result=production.run_job(ctx,job['kind'],job['payload'])
    job.update(status='completed', attempts=1, startedAt=job['createdAt'], finishedAt=now(), result=result)
    ctx.put('jobs',job)
    ctx.audit('job.completed',job['id'],job['kind'])
    parsed=ctx.require('resources', resource['id'])
    version=production.resolve_version(parsed)
    if [b['fields']['记录'] for b in version['blocks']] != [row[2] for row in rows]:
        raise ValueError('科研事实卡字段未忠实解析')
    return production.approve_resource(ctx,parsed,{'versionId':version['id'],'note':'事实卡入库校验，逐行比对内置整理稿；学术判断另由评审岗位办理。'})


def holdout_parts(resource, version):
    # Bind this published-data question to the exact curated revision. A later upload
    # must be authored and checked on its own evidence.
    if resource.get('seedKey')==CRYSTAL_HOLDOUT and version.get('sha256')==hashlib.sha256(record_bytes(CRYSTAL_HOLDOUT_ROWS)).hexdigest():
        question='在 1933 K，Cr–27.5 mol% Si 与 Cr–45 mol% Si 中的组成数字分别指什么？哪组生长更快、快多少，哪组的 3C-SiC 夹杂更少？这两项观察支持怎样的选择？'
        answer='百分数是 Si 的摩尔分数。两组生长速率分别为 1220 和 1310 μm/h；45 mol% Si 组快 90 μm/h，而 27.5 mol% Si 组的 3C-SiC 夹杂较少。两项目标需要权衡，不能据此给出普适的最优配方。'
        incorrect='数字表示 Cr 的摩尔分数。45 mol% 组的速率为 1310 μm/h，因此该组的 3C-SiC 夹杂一定更少，是两方面的最优方案。'
        rubric=[('组成、温度与速率',6,'识别 Si 摩尔分数与同温比较，正确对应两组速率并求得相差 90 μm/h。'),
                ('夹杂与可比边界',4,'指出 27.5 mol% Si 组夹杂较少，辨明速率与夹杂的权衡，不将结论外推为普适最优条件。')]
        return [('生长速率与夹杂权衡',question,answer,incorrect,version['blocks'][:4],rubric,
                 {'mode':'keywords','keywords':['摩尔分数','90','27.5','权衡'],'forbidden':[]})]
    if resource.get('seedKey')!=HOLDOUT or version.get('sha256')!=hashlib.sha256(record_bytes(HOLDOUT_ROWS)).hexdigest():
        return []
    answer='在指定工况下，DP00 的 Rm 增加 4.9 MPa，DP03 的 Rm 降低 26.0 MPa。两种钢的方向相反。这四条数据只能描述各钢在此温区两端的变化，无法证明 Nb 是差异的独立原因。'
    incorrect='DP00 和 DP03 的抗拉强度均随退火温度升高而上升，可以把这一趋势归因于 Nb。'
    rubric=[('工况与变化量',6,'同钢号、同过时效制度比较，DP00 增加 4.9 MPa，DP03 降低 26.0 MPa。'),
            ('趋势与归因边界',4,'说明两种钢变化方向相反，并指出四个观测值无法单独判定 Nb 的因果作用。')]
    return [('跨钢号趋势核查', HOLDOUT_QUESTION, answer, incorrect,version['blocks'][:4],rubric,
             {'mode':'keywords','keywords':['4.9','26.0','相反','独立原因'],'forbidden':[]})]


def seed(db, fresh_meeting=False):
    # Every native startup and browser update enters here within an IMMEDIATE transaction.
    db.execute('CREATE TABLE IF NOT EXISTS research_cases (id TEXT PRIMARY KEY, manifest TEXT NOT NULL)')
    manifests = {row[0]:json.loads(row[1]) for row in db.execute('SELECT id, manifest FROM research_cases')}
    editor=Context(db,{'username':'research-import','display':'文献事实卡导入','role':'operator'})
    steel=manifests.get(CASE, {})
    if not steel.get('contextResourceId'):
        if not steel:
            steel=seed_primary(editor)
        ref=register_card(editor,CONTEXT,CONTEXT_TITLE,'train',CONTEXT_ROWS,CONTEXT_DOI,CONTEXT_URL,
                          '任勇强等，北京科技大学材料科学与工程学院，2013',category='低碳多相钢')
        steel.update(contextResourceId=ref['id'],contextVersionId=ref['activeVersion'])
        db.execute('INSERT INTO research_cases VALUES (?,?) ON CONFLICT(id) DO UPDATE SET manifest=excluded.manifest',
                   (CASE,json.dumps(steel)))
    if CRYSTAL not in manifests:
        crystal=seed_crystal(editor)
        db.execute('INSERT INTO research_cases VALUES (?,?)',(CRYSTAL,json.dumps(crystal)))
    from practice_catalog import retire_practice
    retire_practice(db, fresh_meeting)


def seed_crystal(editor):
    metadata={'case':CRYSTAL,'family':'无机非金属材料','category':'碳化硅晶体'}
    train=register_card(editor,CRYSTAL_TRAIN,CRYSTAL_TRAIN_TITLE,'train',CRYSTAL_TRAIN_ROWS,CRYSTAL_TRAIN_DOI,
                        'https://pubs.acs.org/doi/'+CRYSTAL_TRAIN_DOI,'Zihai Li 等，Crystal Growth & Design，2026',**metadata)
    holdout=register_card(editor,CRYSTAL_HOLDOUT,CRYSTAL_HOLDOUT_TITLE,'holdout',CRYSTAL_HOLDOUT_ROWS,CRYSTAL_HOLDOUT_DOI,
                          'https://www.sciencedirect.com/science/article/pii/S0022024820304000','Kawanishi 等，Journal of Crystal Growth，2020',**metadata)
    return seed_task(editor,train,holdout,CRYSTAL_TRAIN_ROWS,'SiC 晶体生长 · 实测、计算与证据边界',CRYSTAL_QUESTION)


def seed_primary(editor):
    train=register_card(editor,TRAIN,TRAIN_TITLE,'train',TRAIN_ROWS,TRAIN_DOI,TRAIN_URL,'金光灿等，北京科技大学学报，2009')
    holdout=register_card(editor,HOLDOUT,HOLDOUT_TITLE,'holdout',HOLDOUT_ROWS,HOLDOUT_DOI,HOLDOUT_URL,'马快等，有色金属材料与工程，2024')
    return seed_task(editor,train,holdout,TRAIN_ROWS,'双相钢退火 · 工艺、组织与性能证据核查',QUESTION)


def seed_task(editor,train,holdout,rows,title,question):
    version=production.resolve_version(train)
    blocks=version['blocks'][:4]
    batch=production.new_batch(editor,{'title':title},train,version,'local','facts',1)
    rule={'type':'evidence-fields','label':'记录','blockIds':[b['id'] for b in blocks]}
    answer=''.join(b['fields']['记录'] for b in blocks)
    sample=production.save_candidate(editor,batch,question,answer,blocks,rule=rule)
    production.write_batch(editor,batch,[sample],'generated')
    if production.batch_quality(editor,batch)['samples'][0]['status']!='passed':
        raise ValueError('科研样本规则质检失败')
    editor.audit('生成科研问答',batch['id'],'经字段及证据规则核验，待标注与专家复核。')
    annotator=Context(editor.db,{'username':'annotator','display':'语料标注员（预置草稿）','role':'annotator'})
    annotation=expert.start_annotation(annotator,{'sampleId':sample['id']})
    steps=[{'kind':row[1].split('（')[0], 'text':row[2], 'blockIds':[block['id']]} for row,block in zip(rows,blocks)]
    steps[-1]['blockIds']=[b['id'] for b in (blocks[0],blocks[2],blocks[3])]
    annotation=expert.edit_annotation(annotator,annotation,'save',{'steps':steps})
    manifest={'resourceId':train['id'],'versionId':version['id'],'batchId':batch['id'],'sampleId':sample['id'],
              'annotationId':annotation['id'],'holdoutResourceId':holdout['id'],'holdoutVersionId':holdout['activeVersion']}
    return manifest


def handle(ctx,method,path,data):
    case_key={'/api/research-case':CASE,'/api/crystal-case':CRYSTAL}.get(path)
    if not case_key or method!='GET':
        return None
    if not ctx.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='research_cases'").fetchone():
        fail(404,'当前工作区尚未登记此研究案例')
    found=ctx.db.execute('SELECT manifest FROM research_cases WHERE id=?',(case_key,)).fetchone()
    if not found:
        fail(404,'当前工作区尚未登记此研究案例')
    result=json.loads(found[0])
    row=ctx.db.execute("SELECT id, json_extract(payload,'$.handoff.itemId') FROM benchmarks WHERE json_extract(payload,'$.handoff.annotationId')=?",(result['annotationId'],)).fetchone()
    return dict(result,caseKey=case_key,benchmarkId=row[0] if row else None,itemId=row[1] if row else None)
