"""Versioned corpus handoff, reader contracts and external model-service receipts."""

import csv
import hashlib
import io
import json
import math
import re
import time
from datetime import date, datetime, timezone

from core import fail, now

BASE = '/api/supply/v1/'
SCHEMA = 'materials.supply.v1'
FORMATS = {'messages': '对话 JSONL', 'instruction': '指令 JSONL', 'csv': '问答 CSV'}
PAGE_SIZE = 25
SERVICE_TYPES = ('OCR', 'Embedding', '多模态解析')
TECH = ('CPU', 'GPU', '国产加速卡', '其他')


def text_field(data, key, label, limit=120):
    value = data.get(key)
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > limit:
        fail(422, f'请填写{label}，最多 {limit} 字。')
    return value.strip()


def integer(value, low, high, label):
    if type(value) is not int or not low <= value <= high:
        fail(422, f'{label}须为 {low}–{high} 的整数。')
    return value


def valid_date(value, optional=False):
    if not value and optional:
        return ''
    try:
        return date.fromisoformat(value).isoformat()
    except (ValueError, TypeError):
        fail(422, '请填写有效日期。')


def today():
    return datetime.now(timezone.utc).date().isoformat()


def summary(row):
    return {k:v for k,v in row.items() if k not in ('rows', 'result')}


def sha(content):
    return hashlib.sha256(content.encode('utf-8')).hexdigest()


def compact(item):
    return json.dumps(item, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def make_file(view):
    items = view['rows']
    if view['format'] == 'csv':
        out = io.StringIO(newline='')
        writer = csv.DictWriter(out, list(items[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(items)
        return out.getvalue()
    return ''.join(compact(row)+'\n' for row in items)


def new_view(ctx, d):
    ids = d.get('releaseIds')
    if not isinstance(ids, list) or not 1 <= len(ids) <= 25 or any(not isinstance(v,str) for v in ids):
        fail(422, '请选择 1–25 个已发布的训练集版本。')
    ids = sorted(set(ids))
    quotas = d.get('quotas', {})
    if not isinstance(quotas, dict) or set(quotas) - set(ids):
        fail(422,'每个抽样配额须对应一个已选择的来源版本。')
    quotas = {k:integer(v, 1, 1000000, '来源版本配额') for k,v in quotas.items()}
    fmt = d.get('format')
    if fmt not in FORMATS:
        fail(422, '不支持该交付格式。')
    score = integer(d.get('minScore',0),0,100,'最低质检分')
    validation = integer(d.get('validationPercent',0),0,50,'验证占比')
    cot = d.get('onlyCot',False)
    if type(cot) is not bool:
        fail(422,'请选择有效的样本类型。')
    view = {'id':ctx.new_id('VIEW'),'schema':SCHEMA,'title':text_field(d,'title','交付视图名称'),
            'recipient':text_field(d,'recipient','授权接收方'),'purpose':text_field(d,'purpose','使用用途',300),
            'validUntil':valid_date(d.get('validUntil')),'releaseIds':ids,'format':fmt,
            'minScore':score,'quotas':quotas,'validationPercent':validation,'onlyCot':cot,'createdAt':now(),'owner':ctx.user['username']}
    if view['validUntil'] < today():
        fail(422,'授权截止日期已过。')
    rows = []
    seen = set()
    sources = []
    duplicate = 0
    for release_id in ids:
        rel = ctx.require('releases', release_id)
        if (rel['status'],rel['kind']) != ('published','training'):
            fail(409, '交付视图只接收已冻结的训练集版本。')
        source = {'releaseId':rel['id'],'version':rel['version'],'title':rel['title'],'selected':0,'quota':quotas.get(release_id)}
        sources.append(source)
        for sample in sorted(rel['snapshot']['items'],key=lambda r:r['id']):
            if source['quota'] and source['selected'] >= source['quota']:
                break
            quality = (sample.get('quality') or {}).get('score')
            if (cot and not sample.get('reasoning')) or (score and (quality is None or quality < score)):
                continue
            question, answer=sample['question'],sample['answer']
            key=(' '.join(question.casefold().split()),' '.join(answer.casefold().split()))
            if key in seen:
                duplicate+=1
                continue
            seen.add(key)
            rid,vid=sample['resourceId'],sample['versionId']
            # A source stays within a single internal split across releases and resource versions.
            split='validation' if int(sha(rid)[:8],16)%100 < validation else 'train'
            row={'itemId':sample['id'],'releaseId':rel['id'],'releaseVersion':rel['version'],
                 'sourceResourceId':rid,'sourceVersionId':vid,'split':split}
            if fmt=='messages':
                row['messages']=[{'role':'user','content':question},{'role':'assistant','content':answer}]
            elif fmt=='instruction':
                row.update(instruction=question,input='',output=answer)
            else:
                row.update(question=question,answer=answer)
            if cot:
                row['reasoning']=compact(sample['reasoning']) if fmt=='csv' else sample['reasoning']
            row['itemSha256'] = sha(compact(row))
            rows.append(row)
            source['selected'] += 1
    if not rows:
        fail(409, '当前选择规则没有可交付条目。请调整版本、质检分或标注条件。')
    view.update(sources=sources,rows=rows,itemCount=len(rows),skippedDuplicates=duplicate,
                trainCount=sum(r['split']=='train' for r in rows))
    value=make_file(view)
    view.update(contentSha256=sha(value),sizeBytes=len(value.encode('utf-8')))
    ctx.put('supply_views',view)
    ctx.audit('supply.view.created',view['id'],{'title':view['title'],'recipient':view['recipient'],'count':len(rows),'sha256':view['contentSha256']})
    return summary(view)


def read_view(ctx, rid):
    view=ctx.require('supply_views',rid)
    if view['validUntil'] < today():
        fail(403,'交付授权已到期，需重新登记授权范围。')
    return view


def reader_script(view, filename):
    # The returned adapter uses only the Python standard library and validates the actual delivered bytes.
    return f'''from pathlib import Path
import csv, hashlib, io, json

path = Path(__file__).with_name({filename!r})
def records():
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != {view["contentSha256"]!r}:
        raise ValueError("交付文件 SHA-256 校验失败")
    text = raw.decode("utf-8")
    if path.suffix == ".csv":
        yield from csv.DictReader(io.StringIO(text, newline=""))
    else:
        for line in text.splitlines():
            if line:
                yield json.loads(line)

if __name__ == "__main__":
    print("已校验条目数", sum(1 for _ in records()))
'''


def read_check(ctx, rid, download=False):
    start=time.perf_counter()
    view=read_view(ctx,rid)
    content=make_file(view)
    loaded=list(csv.DictReader(io.StringIO(content,newline=''))) if view['format']=='csv' else [json.loads(s) for s in content.splitlines()]
    digest=sha(content)
    if list(r['itemId'] for r in loaded)!=list(r['itemId'] for r in view['rows']) or digest!=view['contentSha256']:
        fail(409,'冻结交付视图的内容或顺序校验失败。')
    filename=rid+('.csv' if view['format']=='csv' else '.jsonl')
    result={'schema':SCHEMA,'viewId':rid,'format':view['format'],'count':len(loaded),'sha256':digest,
            'sizeBytes':view['sizeBytes'],'elapsedMs':round((time.perf_counter()-start)*1000,3),
            'recipient':view['recipient']}
    ctx.audit('supply.download' if download else 'supply.reader.checked',rid,result)
    if download:
        result.update(content=content,filename=filename,reader=reader_script(view,filename),manifest=summary(view))
    return result


def new_node(ctx,d):
    typ,resource=d.get('serviceType'),d.get('resourceType')
    if typ not in SERVICE_TYPES or resource not in TECH:
        fail(422,'请选择有效的服务和资源类型。')
    node={'id':ctx.new_id('NODE'),'title':text_field(d,'title','服务名称'),'modelVersion':text_field(d,'modelVersion','模型版本'),
          'pool':text_field(d,'pool','资源池标识'),'serviceType':typ,'resourceType':resource,
          'slots':integer(d.get('slots'),1,32,'并发配额'),'owner':ctx.user['username'],'createdAt':now()}
    if any((r['pool'],r['modelVersion'],r['serviceType'])==(node['pool'],node['modelVersion'],typ) for r in ctx.all('supply_nodes')):
        fail(409,'相同资源池、服务与模型版本已登记。')
    ctx.put('supply_nodes',node);ctx.audit('supply.node.created',node['id'],node['title'])
    return node


def new_request(ctx,d):
    node=ctx.require('supply_nodes',text_field(d,'nodeId','服务资源'))
    resource=ctx.require('resources',text_field(d,'resourceId','来源资料'))
    ver=next((v for v in resource.get('versions',[]) if v['id']==d.get('versionId')),None)
    if not ver or ver['status']!='approved' or resource.get('split')!='train':
        fail(409,'请选择已核准的训练资料版本。')
    priority=integer(d.get('priority',2),1,3,'优先级')
    active=sum(r['nodeId']==node['id'] and r['state']=='ready' for r in ctx.all('supply_requests'))
    r={'id':ctx.new_id('REQ'),'nodeId':node['id'],'serviceType':node['serviceType'],'modelVersion':node['modelVersion'],
       'resourceId':resource['id'],'versionId':ver['id'],'sourceSha256':ver['sha256'],'sourceTitle':resource['title'],
       'state':'ready' if active<node['slots'] else 'queued','priority':priority,'createdAt':now(),'owner':ctx.user['username']}
    ctx.put('supply_requests',r);ctx.audit('supply.request.created',r['id'],{'state':r['state'],'node':node['id']})
    return r


def close_request(ctx,r,d):
    if d.get('cancel') is True and r['state'] in ('ready','queued'):
        r['state']='cancelled'
    else:
        if r['state']!='ready':
            fail(409,'未获得配额或已结束的请求不能回填。')
        if (d.get('requestId'), d.get('modelVersion'), d.get('sourceSha256'))!=(r['id'],r['modelVersion'],r['sourceSha256']):
            fail(422,'回执的请求编号、模型版本或原文件校验值不匹配。')
        ok=d.get('ok')
        if type(ok) is not bool:fail(422,'回执 ok 必须为布尔值。')
        r['elapsedMs']=integer(d.get('elapsedMs'),0,604800000,'外部耗时（毫秒）')
        if ok:
            value=d.get('result')
            if r['serviceType']=='Embedding':
                if not isinstance(value,list) or not 1<=len(value)<=16384 or not all(type(i) in (int,float) and math.isfinite(i) for i in value):
                    fail(422,'Embedding 结果须为有效数值向量。')
                r['outputSummary']=f'{len(value)} 维向量'
            else:
                if not isinstance(value,str) or not value.strip() or len(value)>200000:fail(422,'识别结果须为含内容的文本，最多 20 万字。')
                r['outputSummary']=f'{len(value)} 字'
            r['result']=value;r['state']='succeeded'
        else:
            r['error']=text_field(d,'error','外部失败原因',500);r['state']='failed'
    r.update(closedAt=now(),closedBy=ctx.user['username'])
    ctx.put('supply_requests',r)
    ctx.audit('supply.request.'+r['state'],r['id'],{'node':r['nodeId'],'elapsedMs':r.get('elapsedMs')})
    queue=sorted([v for v in reversed(ctx.all('supply_requests')) if v['nodeId']==r['nodeId'] and v['state']=='queued'],key=lambda v:v['priority'])
    slots=ctx.require('supply_nodes',r['nodeId'])['slots']
    active=sum(v['nodeId']==r['nodeId'] and v['state']=='ready' for v in ctx.all('supply_requests'))
    for next_r in queue[:max(0,slots-active)]:
        next_r['state']='ready';ctx.put('supply_requests',next_r)
    return summary(r)


def handle(ctx,method,path,d):
    ctx.allow('operator')
    route=path[len(BASE):]
    if route=='views':
        if method=='GET':return [summary(r) for r in ctx.all('supply_views')]
        if method=='POST':return new_view(ctx,d)
    match=re.fullmatch(r'views/(VIEW-[A-F0-9]+)(?:/(check|download|pages/([1-9][0-9]{0,6})))?',route)
    if match:
        rid,op,num=match.groups()
        if method=='GET':
            v=read_view(ctx,rid)
            if not op:return summary(v)
            if num:
                page=int(num);start=(page-1)*PAGE_SIZE
                if start>=len(v['rows']):fail(404,'交付视图没有该页。')
                return {'schema':SCHEMA,'viewId':rid,'page':page,'pageSize':PAGE_SIZE,'total':v['itemCount'],
                        'sha256':v['contentSha256'],'items':v['rows'][start:start+PAGE_SIZE]}
        if method=='POST' and op in ('check','download'):return read_check(ctx,rid,op=='download')
    if route=='models':
        if method=='GET':return {'nodes':ctx.all('supply_nodes'),'requests':[summary(r) for r in ctx.all('supply_requests')]}
        if method=='POST':return new_node(ctx,d)
    if route=='requests' and method=='POST':return new_request(ctx,d)
    match=re.fullmatch(r'requests/(REQ-[A-F0-9]+)(/receipt)?',route)
    if match:
        r=ctx.require('supply_requests',match[1])
        if method=='GET' and not match[2]:return r
        if method=='POST' and match[2]:return close_request(ctx,r,d)
    if route=='monitor' and method=='GET':
        events=[dict(e) for e in ctx.db.execute("SELECT at,actor,action,target,detail FROM audit_log WHERE action LIKE 'supply.%' OR action IN ('release.delivered','training.registered','training.reported') ORDER BY seq DESC LIMIT 100")]
        req=ctx.all('supply_requests');views=ctx.all('supply_views')
        values=[x['elapsedMs'] for x in req if 'elapsedMs' in x]
        return {'events':events,'expiredViews':sum(r['validUntil']<today() for r in views),
                'queued':sum(x['state']=='queued' for x in req),'completed':sum(x['state']=='succeeded' for x in req),
                'failed':sum(x['state']=='failed' for x in req),'meanExternalMs':round(sum(values)/len(values),1) if values else None}
    fail(404,'数据供给接口不存在。')
