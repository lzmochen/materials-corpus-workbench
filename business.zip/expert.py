"""Evidence-bound annotation, independent expert review and benchmark publishing."""

import re
import unicodedata
from collections import Counter

from core import canonical_role, fail, now


ANNOTATION_EDITORS = ("annotator",)
BENCHMARK_EDITORS = ("expert",)
SUPERVISORS = ("expert",)


def field(data, key, limit, required=True):
    value = data.get(key, "")
    if not isinstance(value, str):
        fail(400, f"{key} 需填写文本")
    value = value.strip()
    if (required and not value) or len(value) > limit:
        fail(400, f"请检查 {key}，允许长度为 {'1' if required else '0'}–{limit} 字")
    return value


def entries(value, key, minimum, maximum):
    if not isinstance(value, list) or not minimum <= len(value) <= maximum:
        fail(400, f"{key} 需包含 {minimum}–{maximum} 项")
    if not all(isinstance(entry, dict) for entry in value):
        fail(400, f"{key} 中每项需包含结构化字段")
    return value


def normalized(value):
    return "".join(char for char in unicodedata.normalize("NFKC", value).casefold() if char.isalnum())


def event(ctx, action, note=""):
    return {"action": action, "username": ctx.user["username"], "display": ctx.user["display"], "note": note, "at": now()}


def save_event(ctx, table, record, action, note=""):
    stamp = event(ctx, action, note)
    record.setdefault("history", []).append(stamp)
    record["updatedAt"] = stamp["at"]
    ctx.put(table, record)
    ctx.audit(action, record["id"], note)


def get_source_version(ctx, resource_id, version_id, split):
    resource = ctx.require("resources", resource_id)
    if resource.get("split") != split:
        fail(409, "当前资源的数据分区不能用于这项任务")
    version = next((item for item in resource.get("versions", []) if item["id"] == version_id), None)
    if not version or version.get("status") != "approved":
        fail(409, "请选择已经核准的原始资料版本")
    return resource, version


def anchors(version, block_ids, required=True):
    valid_list = isinstance(block_ids, list) and len(block_ids) <= 12 and all(isinstance(key, str) for key in block_ids)
    if not valid_list or (required and not block_ids):
        fail(400, "请选择 1–12 个原文证据块")
    if len(set(block_ids)) != len(block_ids):
        fail(400, "同一步的证据块不可重复")
    source_blocks = {block["id"]: block for block in version.get("blocks", [])}
    if any(key not in source_blocks for key in block_ids):
        fail(409, "证据块不属于所选资源版本，请刷新后重选")
    return [
        {"blockId": key, "location": source_blocks[key].get("location", ""), "text": source_blocks[key].get("text", "")[:1800]}
        for key in block_ids
    ]


def can_edit_annotation(ctx, record):
    if ctx.user['role'] != 'annotator' or record['status'] not in ('draft', 'returned'):
        return False
    if record['author'] == ctx.user['username']:
        return True
    # Drafts created before the three-role model may belong to a data or review account.
    row = ctx.db.execute('SELECT role FROM users WHERE username=?', (record['author'],)).fetchone()
    role = canonical_role(row[0]) if row else None
    return role in ('operator', 'expert') or (row is None and record['author'] in ('operator', 'admin', 'lead'))


def annotation_view(ctx, record, reveal_blocks=False):
    result = dict(record, canEdit=can_edit_annotation(ctx, record))
    if reveal_blocks:
        _, version = get_source_version(ctx, record["resourceId"], record["versionId"], "train")
        result["availableBlocks"] = version.get("blocks", [])
    return result


def start_annotation(ctx, data):
    ctx.allow(*ANNOTATION_EDITORS)
    sample = ctx.require("samples", field(data, "sampleId", 80))
    if sample.get("status") != "passed":
        fail(409, "样本通过质检后才能建立标注")
    existing = next((record for record in ctx.all("annotations") if record["sampleId"] == sample["id"]), None)
    if existing:
        return annotation_view(ctx, existing, True)
    resource, version = get_source_version(ctx, sample["resourceId"], sample["versionId"], "train")
    references = {block["id"] for block in version.get("blocks", [])}
    initial_blocks = [item["blockId"] for item in sample.get("evidence", []) if item.get("blockId") in references]
    initial_blocks = list(dict.fromkeys(initial_blocks))[:12]
    topic = resource.get('topic', '')
    workflows = {
        '基础概念理解': ('术语定位', '定义与特征', '概念区分', '适用范围'),
        '标准技术规则识别': ('条款定位', '适用条件', '规则判定', '例外与结论'),
        '科学计算': ('数据与单位', '关系式选择', '计算与推导', '量纲和边界核对'),
    }
    steps = []
    for index, kind in enumerate(workflows.get(topic, ('证据提取',))):
        block_ids = initial_blocks if index == 0 else []
        steps.append({'kind': kind, 'text': '', 'blockIds': block_ids, 'evidence': anchors(version, block_ids, False)})
    record = {
        "id": ctx.new_id("ANN"), "sampleId": sample["id"], "resourceId": resource["id"],
        "versionId": version["id"], "resourceTitle": resource["title"], "question": sample["question"],
        "answer": sample["answer"], "author": ctx.user["username"], "status": "draft", "review": None,
        "steps": steps, "topic": topic,
        "createdAt": now(),
    }
    save_event(ctx, "annotations", record, "annotation.create", sample["id"])
    return annotation_view(ctx, record, True)


def material_criteria(version, values, submit):
    labels = {'comparisonConditions': '比较条件', 'applicability': '结论适用范围'}
    if not isinstance(values, dict) or set(values) - labels.keys():
        fail(400, '材料判据仅支持比较条件和结论适用范围')
    result = {}
    for key, value in values.items():
        if not isinstance(value, dict):
            fail(400, '材料判据需包含陈述和原文引用')
        text = field(value, 'text', 1000, False)
        blocks = value.get('blockIds', [])
        evidence = anchors(version, blocks, False)
        if not text and not evidence:
            continue
        if submit and (not text or not evidence):
            fail(400, f'“{labels[key]}”须同时填写陈述并引用原文')
        result[key] = {'text': text, 'blockIds': blocks, 'evidence': evidence}
    return result


def edit_annotation(ctx, record, action, data):
    ctx.allow(*ANNOTATION_EDITORS)
    if record["status"] not in ("draft", "returned"):
        fail(409, "当前状态不能改动标注")
    if not can_edit_annotation(ctx, record):
        fail(403, "仅经办标注员可修改或提交这份工单")
    submit = action == "submit"
    _, version = get_source_version(ctx, record["resourceId"], record["versionId"], "train")
    payload = data.get("steps", record["steps"])
    steps = []
    for index, step in enumerate(entries(payload, "steps", 2 if submit else 0, 20), 1):
        kind = field(step, "kind", 32)
        body = field(step, "text", 3000, submit)
        block_ids = step.get("blockIds", [])
        evidence = anchors(version, block_ids, submit)
        steps.append({"kind": kind, "text": body, "blockIds": block_ids, "evidence": evidence, "ordinal": index})
    criteria = material_criteria(version, data.get('materialCriteria', record.get('materialCriteria', {})), submit)
    if criteria or 'materialCriteria' in record:
        record['materialCriteria'] = criteria
    record["steps"] = steps
    if submit:
        sample = ctx.require("samples", record["sampleId"])
        if sample.get("status") != "passed":
            fail(409, "样本质检结果发生变化，请重新核查")
        record["status"] = "submitted"
    if record['author'] != ctx.user['username']:
        record['previousAuthor'] = record['author']
        record['author'] = ctx.user['username']
        save_event(ctx, 'annotations', record, 'annotation.handoff', record['previousAuthor'])
    save_event(ctx, "annotations", record, f"annotation.{action}")
    return annotation_view(ctx, record, True)


def review_annotation(ctx, record, action, data):
    ctx.allow("expert")
    if ctx.user['username'] in (record['author'], record.get('previousAuthor')):
        fail(403, "请由独立专家复核，标注人不能审定自己的记录")
    if record["status"] != "submitted":
        fail(409, "只有已提交的标注可复核")
    note = field(data, "note", 2000, action == "return")
    if action == "approve" and ctx.require("samples", record["sampleId"]).get("status") != "passed":
        fail(409, "样本质检结果发生变化，请退回标注")
    record["status"] = "approved" if action == "approve" else "returned"
    record["review"] = event(ctx, action, note)
    save_event(ctx, "annotations", record, f"annotation.{action}", note)
    return annotation_view(ctx, record, True)


def assert_holdout(ctx, resource_id, version_id, question):
    resource, version = get_source_version(ctx, resource_id, version_id, "holdout")
    source_hash = version.get("sha256")
    if not source_hash or not version.get("blocks"):
        fail(409, "留出版本缺少可核查的文件摘要或证据块")
    source_digest = version.get("contentDigest")
    for other in ctx.all("resources"):
        if other.get("split") != "train":
            continue
        shared_content = any(
            candidate.get("sha256") == source_hash or (source_digest and candidate.get("contentDigest") == source_digest)
            for candidate in other.get("versions", [])
        )
        if shared_content:
            fail(409, "留出文件与训练资源的任一版本重复，请更换资料")
    query = normalized(question)
    if any(normalized(sample.get("question", "")) == query for sample in ctx.all("samples") if sample.get("status") != "rejected"):
        fail(409, "评测题与训练候选问答重复，请重新编题")
    return resource, version


def validate_rubric(rubric):
    rendered = []
    for item in entries(rubric, "rubric", 1, 8):
        name = field(item, "name", 80)
        max_score = item.get("max")
        if type(max_score) is not int or not 1 <= max_score <= 100:
            fail(400, "评分项满分需为 1–100 的整数")
        rendered.append({"name": name, "max": max_score, "description": field(item, "description", 1000, False)})
    if len({normalized(item["name"]) for item in rendered}) != len(rendered):
        fail(400, "评分项名称需互不相同")
    return rendered


def find_item(benchmark, item_id):
    item = next((candidate for candidate in benchmark["items"] if candidate["id"] == item_id), None)
    if item is None:
        fail(404, "评测题不存在")
    return item


def draft_only(ctx, benchmark):
    ctx.allow(*BENCHMARK_EDITORS)
    if benchmark["status"] != "draft":
        fail(409, "送审后的题目和评分规则已锁定")


def compiled_by(benchmark, username):
    return benchmark['owner'] == username or any(
        entry['username'] == username and entry['action'] in
        ('benchmark.item.create', 'benchmark.item.update', 'benchmark.item.remove', 'benchmark.submit')
        for entry in benchmark.get('history', []))


def benchmark_view(ctx, benchmark):
    response = {key: value for key, value in benchmark.items() if key not in ("frozen", "items")}
    username = ctx.user['username']
    is_expert = ctx.user['role'] == 'expert'
    response['canEdit'] = is_expert and benchmark['status'] == 'draft'
    if ctx.user["role"] == "annotator":
        response["items"] = []
        response["history"] = []
        if benchmark.get("handoff"):
            response["handoff"] = {k: benchmark["handoff"][k] for k in
                                   ("annotationId", "sampleId", "resourceId", "versionId", "itemId")}
        return response
    completed = {i['id'] for i in benchmark['items'] if len(i['reviews']) >= 2}
    response["history"] = [e for e in benchmark.get("history", []) if e["action"] != "benchmark.review"
                           or e["username"] == username or (is_expert and e.get('note') in completed)]
    draft_author = compiled_by(benchmark, username)
    response["items"] = []
    for source in benchmark["items"]:
        item = {key: value for key, value in source.items() if key not in ("reviews", "autoRule")}
        reviews = source["reviews"]
        complete = len(reviews) >= 2
        visible = reviews if complete and is_expert else [
            review for review in reviews if review["username"] == ctx.user["username"]
        ]
        reviewed = any(review["username"] == username for review in reviews)
        independent = is_expert and not draft_author and not reviewed and benchmark['status'] == 'reviewing'
        item.update(reviewCount=len(reviews), reviews=visible, hasReviewed=reviewed,
                    blockedReviewer=draft_author, canReview=independent and item['reviewState'] == 'pending',
                    canArbitrate=independent and item['reviewState'] == 'conflict')
        response["items"].append(item)
    return response


def start_benchmark(ctx, data):
    ctx.allow(*BENCHMARK_EDITORS)
    record = {"id": ctx.new_id("BEN"), "owner": ctx.user["username"], "title": field(data, "title", 120),
              "description": field(data, "description", 2000, False), "version": None,
              "status": "draft", "items": [], "createdAt": now()}
    save_event(ctx, "benchmarks", record, "benchmark.create")
    return benchmark_view(ctx, record)


def set_benchmark_item(ctx, benchmark, data):
    draft_only(ctx, benchmark)
    item_id = field(data, "id", 80, False)
    if item_id and item_id == benchmark.get("handoff", {}).get("itemId"):
        fail(409, "已核对的移交题及其留出证据已锁定")
    previous = find_item(benchmark, item_id) if item_id else None
    if not previous and len(benchmark["items"]) >= 50:
        fail(400, "单个基准最多包含 50 道评测题")
    question = field(data, "question", 2000)
    source_id = field(data, "resourceId", 80)
    version_id = field(data, "versionId", 80)
    resource, version = assert_holdout(ctx, source_id, version_id, question)
    block_ids = data.get("blockIds")
    evidence = anchors(version, block_ids)
    duplicated = any(normalized(item["question"]) == normalized(question) and item["id"] != item_id for item in benchmark["items"])
    if duplicated:
        fail(409, "基准中已存在相同题目")
    candidates = [
        {"label": label, "answer": field(candidate, "answer", 6000)}
        for label, candidate in zip(("A", "B"), entries(data.get("candidates"), "candidates", 2, 2))
    ]
    if normalized(candidates[0]["answer"]) == normalized(candidates[1]["answer"]):
        fail(400, "两份候选回答应可区分")
    item = {"id": item_id or ctx.new_id("QST"), "resourceId": source_id, "versionId": version_id,
            "resourceTitle": resource["title"], "blockIds": block_ids, "evidence": evidence,
            "question": question, "answer": field(data, "answer", 6000), "category": field(data, "category", 80),
            "rubric": validate_rubric(data.get("rubric")), "candidates": candidates, "reviews": [],
            "reviewState": "pending", "result": None}
    if previous:
        benchmark["items"][benchmark["items"].index(previous)] = item
    else:
        benchmark["items"].append(item)
    save_event(ctx, "benchmarks", benchmark, "benchmark.item.update" if previous else "benchmark.item.create", item["id"])


def submit_benchmark(ctx, benchmark):
    draft_only(ctx, benchmark)
    if not benchmark["items"]:
        fail(409, "至少编制一道审核题后才可送审")
    if benchmark.get("handoff"):
        from benchmark_work import validate_handoff
        validate_handoff(ctx, benchmark)
    if benchmark.get("blueprint"):
        from benchmark_work import validate_linked
        validate_linked(ctx, benchmark)
    for item in benchmark["items"]:
        assert_holdout(ctx, item["resourceId"], item["versionId"], item["question"])
    benchmark["status"] = "reviewing"
    save_event(ctx, "benchmarks", benchmark, "benchmark.submit")


def checked_scores(item, scores):
    maxima = [rule["max"] for rule in item["rubric"]]
    if not isinstance(scores, list) or len(scores) != 2:
        fail(400, "请提交 A、B 两份回答的逐项评分")
    for row in scores:
        if not isinstance(row, list) or len(row) != len(maxima):
            fail(400, "评分项与题目评分规则不一致")
        if any(type(value) is not int or value < 0 or value > cap for value, cap in zip(row, maxima)):
            fail(400, "各项得分应为 0 至该项满分之间的整数")
    return scores


def ranking(totals):
    return (totals[0] > totals[1]) - (totals[0] < totals[1])


def combine_expert_reviews(item):
    first, second = [review["scores"] for review in item["reviews"]]
    totals = [[sum(row) for row in matrix] for matrix in (first, second)]
    maximum = sum(rule["max"] for rule in item["rubric"])
    rating_diff = max(abs(a - b) for a, b in zip(*totals))
    if ranking(totals[0]) != ranking(totals[1]) or rating_diff * 5 > maximum:
        item["reviewState"] = "conflict"
        return
    scores = [[(a + b) / 2 for a, b in zip(one, two)] for one, two in zip(first, second)]
    item["result"] = {"kind": "consensus", "scores": scores, "note": "两份独立打分取逐项均值"}
    item["reviewState"] = "accepted"


def score_benchmark(ctx, benchmark, item, data, arbitration=False):
    ctx.allow("expert")
    if benchmark["status"] != "reviewing":
        fail(409, "基准当前不接受评审")
    if compiled_by(benchmark, ctx.user["username"]):
        fail(403, "基准编制人与评审人需为不同账号")
    if item["reviewState"] != ("conflict" if arbitration else "pending"):
        fail(409, "评测题不在可执行该操作的阶段")
    if any(review["username"] == ctx.user["username"] for review in item["reviews"]):
        if arbitration:
            fail(403, "请由未参与本题双评的另一位评审专家裁定")
        fail(409, "每位专家只能提交一次独立盲评")
    scores = checked_scores(item, data.get("scores"))
    note = field(data, "note", 2000)
    if arbitration:
        item["result"] = {"kind": "arbitration", "scores": scores, "note": note, "at": now(), "username": ctx.user["username"]}
        item["reviewState"] = "accepted"
        save_event(ctx, "benchmarks", benchmark, "benchmark.arbitrate", item["id"])
    else:
        item["reviews"].append({**event(ctx, "review", note), "scores": scores})
        if len(item["reviews"]) == 2:
            combine_expert_reviews(item)
        # Independent scores and comments stay in the review record, outside the general activity log.
        save_event(ctx, "benchmarks", benchmark, "benchmark.review", item["id"])


def publish_benchmark(ctx, benchmark):
    ctx.allow(*SUPERVISORS)
    all_accepted = benchmark["items"] and all(item["reviewState"] == "accepted" for item in benchmark["items"])
    if benchmark["status"] != "reviewing" or not all_accepted:
        fail(409, "全部评测题通过双专家评审或完成仲裁后才能发布")
    if benchmark.get("handoff"):
        from benchmark_work import validate_handoff
        validate_handoff(ctx, benchmark)
    if benchmark.get("blueprint"):
        from benchmark_work import validate_linked
        validate_linked(ctx, benchmark)
    for item in benchmark["items"]:
        assert_holdout(ctx, item["resourceId"], item["versionId"], item["question"])
    benchmark.update({"status": "published", "version": "v1.0.0", "publishedAt": now(), "publishedBy": ctx.user["username"]})
    benchmark["frozen"] = {
        "id": benchmark["id"], "version": benchmark["version"], "title": benchmark["title"],
        "description": benchmark["description"], "publishedAt": benchmark["publishedAt"], "split": "holdout",
        "items": [{key: item[key] for key in ("id", "resourceId", "versionId", "evidence", "question", "answer", "category", "rubric", "result")} for item in benchmark["items"]],
    }
    if benchmark.get("blueprint") or benchmark.get("handoff"):
        from benchmark_work import freeze_design_items
        for key in ("blueprint", "handoff"):
            if key in benchmark:
                benchmark["frozen"][key] = benchmark[key]
        benchmark["frozen"]["items"] = freeze_design_items(benchmark)
    save_event(ctx, "benchmarks", benchmark, "benchmark.publish", benchmark["version"])


def create_feedback(ctx, data):
    ctx.allow("expert")
    benchmark = ctx.require("benchmarks", field(data, "benchmarkId", 80))
    if benchmark["status"] != "published":
        fail(409, "请在发布的基准版本上创建质量反馈")
    item = find_item(benchmark, field(data, "itemId", 80))
    training_id = field(data, "trainingResourceId", 80, False)
    sample_id = field(data, "trainingSampleId", 80, False)
    training_version = None
    if sample_id:
        sample = ctx.require("samples", sample_id)
        if sample.get("status") != "passed" or (training_id and sample["resourceId"] != training_id):
            fail(409, "关联样本需来自所选资源且通过质检")
        training_id, training_version = sample["resourceId"], sample["versionId"]
    if training_id:
        training = ctx.require("resources", training_id)
        if training.get("split") != "train":
            fail(409, "反馈任务只能关联训练资源")
        training_version = training_version or training.get("activeVersion")
    assignee = field(data, "assignee", 80, False)
    if assignee:
        account = ctx.db.execute("SELECT role FROM users WHERE username = ?", (assignee,)).fetchone()
        if not account or canonical_role(account[0]) not in ('expert', 'operator'):
            fail(400, "请选择已登记的数据管理员或评审专家账号")
    title = field(data, "title", 150)
    if any(entry["benchmarkId"] == benchmark["id"] and entry["itemId"] == item["id"]
           and normalized(entry["title"]) == normalized(title) and entry["status"] != "resolved" for entry in ctx.all("feedback")):
        fail(409, "这道题已有同名待处理任务")
    from guide_eval import checked_rule
    regression_rule = checked_rule(item["autoRule"]) if item.get("autoRule") else None
    record = {
        "id": ctx.new_id("FB"), "benchmarkId": benchmark["id"], "benchmarkVersion": benchmark["version"],
        "itemId": item["id"], "trainingResourceId": training_id or None, "trainingVersionId": training_version,
        "trainingSampleId": sample_id or None, "trainingBatchId": sample["batchId"] if sample_id else None, "assignee": assignee or None, "status": "open",
        "title": title, "description": field(data, "description", 3000), "createdAt": now(),
        "creator": ctx.user["username"], "resultBatchId": None, "requiresRegression": bool(regression_rule),
        "regressionRule": regression_rule,
    }
    save_event(ctx, "feedback", record, "feedback.create", item["id"])
    return record


def progress_feedback(ctx, record, data):
    ctx.allow("operator", "expert")
    status = field(data, "status", 30)
    valid = {"open": "in_progress", "in_progress": "resolved"}
    if valid.get(record["status"]) != status:
        fail(409, "反馈任务依次经过待受理、处理中与已解决")
    username = ctx.user["username"]
    if record["assignee"] and record["assignee"] != username and ctx.user["role"] not in SUPERVISORS:
        fail(403, "请由指派的经办人或评审专家处理该任务")
    if not record["assignee"]:
        record["assignee"] = username
    resolved = status == "resolved"
    if resolved and record.get("requiresRegression") and not record.get("regressions"):
        fail(409, "请先归档本工单的同题回归复验，再登记验收结果")
    note = field(data, "note", 3000, resolved)
    batch_id = field(data, "resultBatchId", 80, False)
    if batch_id:
        if not resolved:
            fail(400, "请在解决反馈时关联补充批次")
        batch = ctx.require("batches", batch_id)
        if batch.get("status") != "reviewed" or batch.get("counts", {}).get("passed", 0) <= 0:
            fail(409, "补充批次须至少有一条样本通过质检")
        if record.get("trainingResourceId") and batch.get("resourceId") != record["trainingResourceId"]:
            fail(409, "补充批次的来源与反馈关联的训练资源不匹配")
        original = ctx.get("samples", record["trainingSampleId"]) if record.get("trainingSampleId") else None
        if (original and original.get("batchId") == batch_id) or batch.get("createdAt", "") < record.get("createdAt", ""):
            fail(409, "请选择在本次反馈后生成并通过质检的补充批次")
        record["resultBatchId"] = batch_id
    record["status"] = status
    if resolved:
        record["resolution"] = note
        record["resolvedAt"] = now()
    save_event(ctx, "feedback", record, f"feedback.{status}", note)
    return record


def feedback_regression(ctx, method, record, data):
    from guide_eval import digest, history, regression_comparison, require_access
    benchmark = ctx.require('benchmarks', record['benchmarkId'])
    require_access(ctx, benchmark)
    can_file = (record['status'] in ('in_progress', 'resolved') and
                (ctx.user['role'] in SUPERVISORS or
                 (ctx.user['role'] == 'operator' and record.get('assignee') == ctx.user['username'])))
    checks = record.get('regressions', [])
    if method == 'GET':
        item = find_item(benchmark, record['itemId'])
        reports = [r for r in history(ctx, benchmark['id']) if r['benchmarkVersion'] == record['benchmarkVersion']]
        return {'ticketId': record['id'], 'title': record['title'], 'itemId': item['id'], 'question': item['question'],
                'benchmarkId': benchmark['id'], 'benchmarkVersion': record['benchmarkVersion'],
                'status': record['status'], 'rule': record.get('regressionRule'),
                'canFile': can_file, 'canRun': ctx.user['role'] in BENCHMARK_EDITORS,
                'reports': reports, 'checks': checks}
    action = field(data, 'action', 20)
    if action not in ('preview', 'file'):
        fail(400, '请选择核对报告或归档复验')
    if action == 'file':
        ctx.allow('operator', 'expert')
        if record['status'] == 'open':
            fail(409, '请先受理该工单，再归档复验')
        if not can_file:
            fail(403, '请由工单处理人或评审专家归档复验')
    before = field(data, 'beforeId', 80)
    after = field(data, 'afterId', 80)
    result = regression_comparison(ctx, record, benchmark, before, after)
    signature = digest(result)
    old = next((c for c in checks if c['beforeId'] == before and c['afterId'] == after), None)
    if old and signature != old['signature']:
        fail(409, '报告内容与工单归档时的证据不一致')
    if action == 'file' and not old:
        check = {'id': ctx.new_id('RGR'), 'beforeId': before, 'afterId': after, 'signature': signature,
                 'deltas': result['deltas'], 'filedAt': now(), 'filedBy': ctx.user['username']}
        record.setdefault('regressions', []).append(check)
        save_event(ctx, 'feedback', record, 'feedback.regression', f"{check['id']} · {before} → {after}")
        old = check
    return {'comparison': result, 'filed': old, 'canFile': can_file}


def handle(ctx, method, path, data):
    """Route annotation, benchmark and feedback API requests inside the server transaction."""
    if path == "/api/annotations":
        if method == "GET":
            return [annotation_view(ctx, record) for record in ctx.all("annotations")]
        if method == "POST":
            return start_annotation(ctx, data)
    annotation_path = re.fullmatch(r"/api/annotations/([^/]+)(?:/(save|submit|return|approve|export))?", path)
    if annotation_path:
        record_id, action = annotation_path.groups()
        record = ctx.require("annotations", record_id)
        if method == "GET" and not action:
            return annotation_view(ctx, record, True)
        if method == "GET" and action == "export":
            ctx.allow("operator", "expert")
            if record["status"] != "approved":
                fail(409, "标注须经独立专家审定后才可导出")
            return record
        if method == "POST" and action in ("save", "submit"):
            return edit_annotation(ctx, record, action, data)
        if method == "POST" and action in ("return", "approve"):
            return review_annotation(ctx, record, action, data)
    if path == "/api/benchmarks":
        if method == "GET":
            return [benchmark_view(ctx, record) for record in ctx.all("benchmarks")]
        if method == "POST":
            return start_benchmark(ctx, data)
    benchmark_path = re.fullmatch(r"/api/benchmarks/([^/]+)(?:/(items|remove-item|submit|review|arbitrate|publish|export))?", path)
    if benchmark_path:
        record_id, action = benchmark_path.groups()
        record = ctx.require("benchmarks", record_id)
        if method == "GET" and not action:
            return benchmark_view(ctx, record)
        if method == "GET" and action == "export":
            ctx.allow("operator", "expert")
            if record["status"] != "published":
                fail(409, "只有发布的冻结版本可导出")
            return record["frozen"]
        if method == "POST" and action not in (None, "export"):
            if action == "items":
                set_benchmark_item(ctx, record, data)
            elif action == "remove-item":
                draft_only(ctx, record)
                item = find_item(record, field(data, "itemId", 80))
                if item["id"] == record.get("handoff", {}).get("itemId"):
                    fail(409, "已核对的移交题不可移除")
                record["items"].remove(item)
                save_event(ctx, "benchmarks", record, "benchmark.item.remove", item["id"])
            elif action == "submit":
                submit_benchmark(ctx, record)
            elif action in ("review", "arbitrate"):
                score_benchmark(ctx, record, find_item(record, field(data, "itemId", 80)), data, action == "arbitrate")
            elif action == "publish":
                publish_benchmark(ctx, record)
            return benchmark_view(ctx, record)
    if path == "/api/feedback":
        if method == "GET":
            return ctx.all("feedback")
        if method == "POST":
            return create_feedback(ctx, data)
    feedback_path = re.fullmatch(r"/api/feedback/([^/]+)(?:/(progress|regression))?", path)
    if feedback_path:
        record_id, action = feedback_path.groups()
        if method == "GET" and not action:
            return ctx.require("feedback", record_id)
        if method in ("GET", "POST") and action == "regression":
            return feedback_regression(ctx, method, ctx.require("feedback", record_id), data)
        if method == "POST" and action == "progress":
            return progress_feedback(ctx, ctx.require("feedback", record_id), data)
    return None
