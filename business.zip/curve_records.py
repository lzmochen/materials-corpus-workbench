"""Version-bound scientific curve annotations, review and spreadsheet delivery."""
import base64
import csv
import io
import json
import math
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from core import fail, now
from production import resolve_version, resource_access, store_resource, upload, value

TABLE = 'curve_records'
IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp'}


def finite(v):
    return type(v) in (int, float) and -1e308 <= v <= 1e308


def validated_state(data):
    state = data.get('state')
    if not isinstance(state, dict):
        fail(422, '缺少曲线标注数据')
    width, height = state.get('width'), state.get('height')
    if not all(finite(n) and n > 0 for n in (width, height)):
        fail(422, '缺少有效的原图尺寸')
    roi = state.get('roi')
    if not isinstance(roi, dict) or not all(finite(roi.get(k)) for k in ('left','right','top','bottom')):
        fail(422, '请确定绘图区')
    if not (0 <= roi['left'] < roi['right'] <= width and 0 <= roi['top'] < roi['bottom'] <= height):
        fail(422, '绘图区超出原图或没有面积')
    axes, series = state.get('axes'), state.get('series')
    if not isinstance(axes, dict) or not isinstance(series, list):
        fail(422, '请确认坐标轴和曲线系列')
    for key in ('x', 'y', 'y2'):
        a = axes.get(key)
        if key == 'y2' and not a:
            continue
        if not isinstance(a, dict) or not all(finite(a.get(n)) for n in ('min','max')) or a['max'] <= a['min']:
            fail(422, '坐标轴上下限无效')
        if a.get('scale','linear') not in ('linear','log') or a.get('scale') == 'log' and a['min'] <= 0:
            fail(422, '对数坐标轴的范围必须为正数')
    for s in series:
        if not isinstance(s, dict) or not isinstance(s.get('points'), list):
            fail(422, '曲线点集格式无效')
        if s.get('side') == 'right' and not axes.get('y2'):
            fail(422, '请先标定右侧 Y 轴')
        for p in s['points']:
            if not isinstance(p, dict) or not all(finite(p.get(k)) for k in ('px','py')):
                fail(422, '数据点缺少有效的原图像素坐标')
            if not (0 <= p['px'] <= width and 0 <= p['py'] <= height):
                fail(422, '数据点超出原图')
    try:
        size = len(json.dumps(state, allow_nan=False, separators=(',',':')))
    except (ValueError, TypeError):
        fail(422, '曲线记录包含无效数值')
    if size > 12 * 1024 * 1024:
        fail(413, '曲线记录过大，请降低采样点数再保存')
    return state


def source_info(ctx, source, original=None):
    if not isinstance(source, dict):
        fail(422, '请选择来源图像')
    if source.get('resourceId'):
        res = ctx.require('resources', value(source, 'resourceId', 100))
        resource_access(ctx, res)
        v = resolve_version(res, value(source,'versionId',100))
        if Path(v['filename']).suffix.lower() not in IMAGE_EXTENSIONS:
            fail(422, '所选资源版本不是曲线图像')
        return dict(resourceId=res['id'], versionId=v['id'], filename=v['filename'], sha256=v['sha256'], split=res['split'])
    if original and not source.get('contentBase64') and source.get('sha256') == original['sha256']:
        return original
    name, raw = upload(source, IMAGE_EXTENSIONS)
    if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff') or raw[:4] == b'RIFF' and raw[8:12] == b'WEBP'):
        fail(422, '源文件不是可识别的 PNG、JPEG 或 WebP 图像')
    return dict(filename=name, sha256=ctx.store_blob(raw),split='train',
                sourceNote=str(source.get('sourceNote',''))[:400])


def allowed(ctx, r):
    if r['source'].get('split') == 'holdout' and ctx.user['role'] == 'annotator':
        return False
    return (ctx.user['role']=='operator' or r['owner']==ctx.user['username'] or
            r['status']=='approved' or ctx.user['role']=='expert' and r['status']=='submitted')


def response(ctx, r, details=False):
    result = {k:v for k,v in r.items() if k!='state'}
    editor = ctx.user['role']=='operator' or ctx.user['role']=='annotator' and r['owner']==ctx.user['username']
    edit = editor and r['status'] in ('draft','returned')
    result.update(canEdit=edit,canSubmit=edit,canReview=ctx.user['role']=='expert' and r['status']=='submitted',
                  canPublish=ctx.user['role']=='operator' and r['status']=='approved')
    if details:
        result['state'] = r['state']
        if not r['source'].get('resourceId'):
            result['source'] = dict(r['source'],contentBase64=base64.b64encode(ctx.read_blob(r['source']['sha256'])).decode())
    return result


def physical(n, axis):
    if axis.get('reverse'):
        n = 1-n
    low, high = axis['min'], axis['max']
    if axis.get('scale') == 'log':
        return math.exp(math.log(low) + n * (math.log(high)-math.log(low)))
    return low+n*(high-low)


def curve_rows(state):
    axes, r = state['axes'], state['roi']
    yield ['曲线','纵轴','点序','X','Y','原图 X (px)','原图 Y (px)','X 轴名称','Y 轴名称']
    for seq in state['series']:
        right = seq.get('side') == 'right'
        axis = axes['y2'] if right else axes['y']
        for i,p in enumerate(seq['points'],1):
            x = physical((p['px']-r['left'])/(r['right']-r['left']),axes['x'])
            y = physical((r['bottom']-p['py'])/(r['bottom']-r['top']),axis)
            yield [str(seq.get('name','')), '右' if right else '左',i,x,y,p['px'],p['py'],
                   axes['x'].get('label',''),axis.get('label','')]


def workbook(sheets):
    # Inline strings keep worksheet labels literal; measurements are numeric cells.
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    pkg='http://schemas.openxmlformats.org/package/2006/relationships'
    files=io.BytesIO()
    with zipfile.ZipFile(files,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('_rels/.rels',f'<Relationships xmlns="{pkg}"><Relationship Id="rId1" Type="{rel}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        links=[];tabs=[];types=['<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>']
        for i,(name,rows) in enumerate(sheets,1):
            tabs.append(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"/>')
            links.append(f'<Relationship Id="rId{i}" Type="{rel}/worksheet" Target="worksheets/sheet{i}.xml"/>')
            types.append(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>')
            with z.open(f'xl/worksheets/sheet{i}.xml','w') as out:
                out.write(f'<worksheet xmlns="{ns}"><sheetData>'.encode())
                for rownum,row in enumerate(rows,1):
                    cells=[]
                    for col,val in enumerate(row):
                        ref=chr(ord('A')+col)+str(rownum)
                        if finite(val):
                            cells.append(f'<c r="{ref}"><v>{val:.15g}</v></c>')
                        else:
                            s=escape(re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]','',str(val)))
                            cells.append(f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{s}</t></is></c>')
                    out.write((f'<row r="{rownum}">'+''.join(cells)+'</row>').encode())
                out.write(b'</sheetData></worksheet>')
        z.writestr('xl/workbook.xml',f'<workbook xmlns="{ns}" xmlns:r="{rel}"><sheets>'+''.join(tabs)+'</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels',f'<Relationships xmlns="{pkg}">'+''.join(links)+'</Relationships>')
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'+''.join(types)+'</Types>')
    return files.getvalue()


def handle(ctx, method, path, data):
    if path == '/api/curve-export' and method == 'POST':
        state = validated_state(data)
        src = data.get('source') or {}
        if not isinstance(src,dict):
            fail(422,'来源格式无效')
        title = value(data,'title',180)
        fields=[['字段','值'],['标题',title],['源文件',src.get('filename','')],['资源编号',src.get('resourceId','')],
                ['版本编号',src.get('versionId','')],['原图校验值',src.get('sha256','')],['来源说明',src.get('sourceNote','')]]
        for k,ax in state['axes'].items():
            if isinstance(ax,dict) and k in ('x','y','y2'):
                fields.append([k+' 轴标定',json.dumps(ax,ensure_ascii=False)])
        raw=workbook([('曲线数据',curve_rows(state)),('来源与标定',fields)])
        return dict(filename=re.sub(r'[/\\:*?"<>|]','_',title)+'.xlsx',contentBase64=base64.b64encode(raw).decode())
    match = re.fullmatch(r'/api/curve-records(?:/(CUR-[A-Z0-9]+)(?:/(submit|review|catalog))?)?', path)
    if not match:
        return None
    key, action = match.groups()
    if not key and method=='GET':
        rows=ctx.db.execute("SELECT json_remove(payload,'$.state') FROM curve_records ORDER BY rowid DESC")
        records=(json.loads(row[0]) for row in rows)
        return [response(ctx,r) for r in records if allowed(ctx,r)]
    if not key and method == 'POST':
        ctx.allow('operator','annotator')
        state=validated_state(data);title=value(data,'title',180)
        if data.get('id'):
            rec=ctx.require(TABLE,value(data,'id',100))
            if not allowed(ctx,rec) or not response(ctx,rec)['canEdit']:
                fail(403,'当前岗位或记录状态不允许修改')
            if data.get('revision') != rec['revision']:
                fail(409,'记录已更新，请重新打开后再保存')
            src=source_info(ctx,data.get('source'),rec['source'])
            if any(src.get(k)!=rec['source'].get(k) for k in ('resourceId','versionId','sha256')):
                fail(409,'已保存记录的原图不可替换，请另存新记录')
        else:
            src=source_info(ctx,data.get('source'))
            rec=dict(id=ctx.new_id('CUR'),owner=ctx.user['username'],createdAt=now(),status='draft',revision=0,source=src)
        rec.update(title=title,state=state,revision=rec['revision']+1,updatedAt=now())
        ctx.put(TABLE,rec);ctx.audit('保存曲线标注',rec['id'],src['filename'])
        return response(ctx,rec,True)
    if not key: return None
    rec=ctx.require(TABLE,key)
    if not allowed(ctx,rec):
        fail(403,'当前岗位无权访问此曲线记录')
    if method=='GET' and not action:
        return response(ctx,rec,True)
    if method!='POST' or not action: return None
    caps=response(ctx,rec)
    if action=='catalog':
        if not caps['canPublish']:fail(403,'已通过专家复核的记录方可由数据管理员入库')
        if rec.get('catalog'):return rec['catalog']
        parent=ctx.require('resources',rec['source']['resourceId']) if rec['source'].get('resourceId') else {}
        origin=rec['source']
        stream=io.StringIO(newline='');writer=csv.writer(stream)
        for row in curve_rows(rec['state']):writer.writerow(row)
        res=store_resource(ctx,dict(title=rec['title']+' · 曲线数据',category='科研曲线数据',source=origin['filename'],
            license=parent.get('license',''),notes=f"曲线复核记录 {key}，来源版本 {origin.get('versionId','')}，原图 SHA-256 {origin['sha256']}。{origin.get('sourceNote','')}",
            split=origin['split'],materialFamily=parent.get('materialFamily',''),topic=parent.get('topic','科学计算')),
            key+'.csv',stream.getvalue().encode('utf-8-sig'),'curve-review')
        rec['catalog']=dict(resourceId=res['id'],versionId=res['activeVersion'])
    else:
        if data.get('revision')!=rec['revision']:fail(409,'记录已更新，请重新打开')
        if action=='submit':
            if not caps['canSubmit']:fail(403,'当前岗位或记录状态不允许提交')
            if rec['state'].get('confirmed') is not True:fail(422,'请在提交前确认坐标标定')
            if not any(s['points'] for s in rec['state']['series']):fail(422,'请先提取或标注曲线数据点')
            rec['status']='submitted'
        elif action=='review':
            if not caps['canReview']:fail(403,'待复核记录须由评审专家办理')
            decision=data.get('decision')
            if decision not in ('approve','return'):fail(422,'请选择通过或退回')
            rec.update(status='approved' if decision=='approve' else 'returned',reviewer=ctx.user['username'],
                       reviewNote=value(data,'note',1000,decision=='return'))
    rec.update(revision=rec['revision']+1,updatedAt=now())
    ctx.put(TABLE,rec);ctx.audit({'catalog':'曲线结果入库','submit':'提交曲线复核','review':'专家复核曲线'}[action],key,rec['status'])
    return rec['catalog'] if action=='catalog' else response(ctx,rec,True)
