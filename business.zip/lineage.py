"""Read the business records derived from one authorized source version."""
import re

import production


def handle(ctx, method, path, data):
    match = re.fullmatch(r'/api/resources/([\w-]+)/lineage/([\w-]+)', path)
    if method != 'GET' or not match:
        return None
    resource_id, version_id = match.groups()
    resource = ctx.require('resources', resource_id)
    production.resource_access(ctx, resource)
    version = production.resolve_version(resource, version_id)
    nodes = {}
    edges = set()

    def add(kind, record, title, status, meta='', owner=None):
        ident = record['id']
        nodes[ident] = dict(id=ident, kind=kind, title=title or ident, status=status or '',
                            meta=meta or '', ownerId=owner)
        return ident

    def same(record):
        return record.get('resourceId') == resource_id and record.get('versionId') == version_id

    add('version', version, version['filename'], version['status'], resource['title'], resource_id)
    tasks = [task for task in ctx.all('extractions') if same(task)]
    for task in tasks:
        ident = add('extraction', task, task['title'], task['status'], task.get('templateName'))
        edges.add((version_id, ident))
    if resource['split'] == 'train':
        batches = [b for b in ctx.all('batches') if same(b)]
        for batch in batches:
            ident = add('batch', batch, batch['title'], batch['status'])
            parents = [t['id'] for t in tasks if t['id'] == batch.get('extractionId') or t.get('batchId') == ident]
            edges.update((parent, ident) for parent in parents or [version_id])
        for sample in ctx.all('samples'):
            if same(sample):
                ident = add('sample', sample, sample['question'], sample['status'])
                parent = sample.get('batchId')
                edges.add((parent if nodes.get(parent, {}).get('kind') == 'batch' else version_id, ident))
        for ann in ctx.all('annotations'):
            parent = ann.get('sampleId')
            if nodes.get(parent, {}).get('kind') == 'sample' and all(
                not ann.get(key) or ann[key] == expected for key, expected in
                [('resourceId', resource_id), ('versionId', version_id)]
            ):
                ident = add('annotation', ann, ann.get('question') or nodes[parent]['title'],
                            ann.get('status'), ann.get('author'))
                edges.add((parent, ident))
        for benchmark in ctx.all('benchmarks'):
            link = benchmark.get('handoff', {})
            if not same(link) or link.get('annotationId') not in nodes:
                continue
            bench = add('benchmark', benchmark, benchmark['title'], benchmark['status'])
            if ctx.user['role'] == 'annotator':
                edges.add((link['annotationId'], bench))
                continue
            item = next((row for row in benchmark['items'] if row['id'] == link['itemId']), None)
            if item:
                question = add('question', item, item['question'], item['reviewState'], item['category'], bench)
                edges.update([(link['annotationId'], question), (question, bench)])
    else:
        for benchmark in ctx.all('benchmarks'):
            for item in benchmark.get('items', []):
                if same(item):
                    bench = add('benchmark', benchmark, benchmark['title'], benchmark['status'], benchmark.get('owner'))
                    question = add('question', item, item['question'], item.get('reviewState'), item.get('category'), bench)
                    edges.update([(version_id, question), (question, bench)])
    return dict(resourceId=resource_id, versionId=version_id,
                versions=[{key: v[key] for key in ('id', 'number', 'filename')} for v in resource['versions']],
                nodes=list(nodes.values()), edges=[{'from': a, 'to': b} for a, b in sorted(edges)])
